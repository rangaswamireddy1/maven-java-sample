
var getTaskListQuery = (projectsForFilter, taskLblFilter, taskIdFilter, environment) =>{
  var projectFilter  = '(';
  if (projectsForFilter)
  {
    projectsForFilter.forEach((project) => {
      projectFilter = projectFilter + ",'" + project.project_name.trim() + "'";
    });
    projectFilter = projectFilter.replace(",", "") + ")"
  }
  return `
  ;With tasks as (SELECT t.id,
  p.label AS ProjectLabel,
  t.label AS Tasklabel,
  t.status,
  t.errorstatus,
  t.description,

  t.idquartzjob,
  t.active,
  CAST(t.lastrundate AS VARCHAR(19)),
  t.idquartzjob as job_name
  FROM "[SCHEMA_NAME]".executiontask t
  INNER JOIN "[SCHEMA_NAME]".project p
  	ON p.id = t.project_project_id
  ), triggers as (
  SELECT 	t_tr.id,
  	t_tr.active,
  	t_tr.idquartztrigger,
  	t_tr.label,
  	t_tr.talendtrigger_executiontriggerable_e_id,
  	q_tr.trigger_state,
  	TO_TIMESTAMP(q_tr.next_fire_time/1000) AS next_fire_time,
  	q_tr.start_time
  FROM "[SCHEMA_NAME]".talendtrigger t_tr
  INNER JOIN "[SCHEMA_NAME]".qrtz_triggers q_tr
  	ON q_tr.trigger_name = CAST(t_tr.idquartztrigger AS varchar(255))
  WHERE q_tr.job_group = 'JOB_CONDUCTOR'
  )

  SELECT '${environment}'	AS env,
    t.id,
  	t.ProjectLabel,
  	t.Tasklabel,
  	t.status,
  	t.errorstatus,
  	t.description,
  	t.lastrundate,
  	CAST(MIN(tr.next_fire_time) AS varchar(19)) AS nextrundate,
  	COUNT(DISTINCT f_tr.trigger_name) AS blockedtriggers

  FROM tasks t
  LEFT JOIN triggers tr
  	ON tr.talendtrigger_executiontriggerable_e_id = t.id
  LEFT JOIN "[SCHEMA_NAME]".qrtz_fired_triggers f_tr
  	ON f_tr.job_name = CAST(t.job_name AS VARCHAR(255))
  	AND f_tr.state != 'EXECUTING'
  WHERE 1=1
  ${projectsForFilter ? `AND ProjectLabel IN ${projectFilter}` : ""}
  ${taskLblFilter ? `AND upper(TaskLabel) LIKE upper('%${taskLblFilter}%')` : ""}
  ${taskIdFilter ? `AND  t.id = ${taskIdFilter}` : ""}
  GROUP BY t.id,
  	t.ProjectLabel,
  	t.Tasklabel,
  	t.status,
  	t.errorstatus,
  	t.description,
  	t.lastrundate;`;
};

var getEsbListQuery = (projectsForFilter,reqProjectCodes, esbLblFilter, esbIdFilter, environment) =>{
  var projectFilter  = '(';
  if (projectsForFilter)
  {
    projectsForFilter.forEach((project) => {
      projectFilter = projectFilter + ",'" + project.project_name.trim() + "'";
    });
    projectFilter = projectFilter.replace(",", "") + ")"
  }
  return `
  ;With esbs as (SELECT t.id,
  t.label AS Esblabel,
  t.status,
  t.featureversion AS Version,
  t.applicationtype AS TYPE,
  t.applicationgroup AS ProjectCODE
  FROM "[SCHEMA_NAME]".executiontask t
	where applicationtype in ('ROUTE', 'SERVICE')
  and applicationgroup like '%${reqProjectCodes}%'
  )
  

  SELECT '${environment}'	AS env, *
  FROM esbs t
  ${esbLblFilter ? `AND upper(EsbLabel) LIKE upper('%${esbLblFilter}%')` : ""}
  ${esbIdFilter ? `AND  t.id = ${esbIdFilter}` : ""}
  GROUP BY t.id,
  t.ProjectCODE,
  t.Esblabel,
  t.status,
  t.TYPE,
  t.Version`;
};

var getTacListQuery = (envFilter) => {
  return `
  SELECT  "dbURL",
          "dbUserRO" AS "dbUser",
          "dbPasswordRO" AS "dbPassword",
          "env",
          "hostDNS",
          "portHTTP",
          "portHTTPS",
          "applicationContext",
          COALESCE("tacUser", '') AS "tacUser",
          COALESCE("tacPassword", '') AS "tacPassword"
  FROM "[SCHEMA_NAME]".tac
  WHERE COALESCE("dbUserRO", '') <> ''
  AND COALESCE("dbPasswordRO", '') <> ''
  AND COALESCE("dbURL", '') <> ''
  AND COALESCE(env, '') <> ''
  ${envFilter ? `AND env LIKE '%${envFilter}%'` : ""}
  AND env NOT LIKE '%4'
  AND "isActive" = true;
  `;
};

module.exports = {
  getTaskListQuery,
  getEsbListQuery,
  getTacListQuery
};
