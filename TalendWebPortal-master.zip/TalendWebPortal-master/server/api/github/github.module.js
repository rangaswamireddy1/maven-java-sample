'use strict'

const request = require('request');
const _ = require('lodash');
const express = require('express');
const passport = require('passport');
const httpsProxyAgent = require('https-proxy-agent');


/**
 * This module encapsulates all access to Gitlab
 *
 * @param {*} configuration the global system configuration
 */
module.exports = (configuration) => {
  const router = express.Router();

  const githubEnvironmentConfiguration = configuration[process.env.NODE_ENV || "production"].github;

  const proxyURL = 'http://'+githubEnvironmentConfiguration.proxyUser+':'+githubEnvironmentConfiguration.proxyPassword+'@'+githubEnvironmentConfiguration.proxyUrl+':'+githubEnvironmentConfiguration.proxyPort;
  //console.log(proxyURL);
  const agent = new httpsProxyAgent(proxyURL);

  router.get("/configuration.properties", passport.authenticate('jwt', {session: false}), (req,res) => {
    console.log("Get configuration.properties");
    console.log(1);
    const projectName = req.query.projectName;
   const githubRequestUrl = githubEnvironmentConfiguration.baseUrl+"/"+projectName+"_coreconfig/master/DEV/configuration.properties";
   console.log(projectName + " - " + githubRequestUrl);
   if( !_.isEmpty(projectName) ) {
      console.log("Request from Github");
      console.log(githubEnvironmentConfiguration.token);
    var axios = require('axios');

    var config = {
    method: 'get',
    url: githubRequestUrl,
    httpsAgent: agent,
    headers: { 
    'strict-ssl': 'false', 
    'Proxy-Authorization': 'Basic '+githubEnvironmentConfiguration.token, 
    'Authorization': 'Bearer '+githubEnvironmentConfiguration.token
  }
};
    axios(config)
          .then(function (response) {
            //console.log(response.data);
            res.send(response.data);
            res.end();
           })
           .catch(function (error) {
            console.log(error);
});
    } else {
      helpers.errorCallback(res, {"message": "Invalid request"});
    }
  });
  
  return router;
}