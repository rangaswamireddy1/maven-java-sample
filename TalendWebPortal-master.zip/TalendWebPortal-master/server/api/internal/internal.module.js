'use strict'

const express = require('express');
const fs = require('fs');
const router = express.Router();
const _ = require('lodash');
const helpers = require('../../common/express.helpers.module');
const passport = require('passport');
const axios = require('axios');

const permission_helper = require('../permission/permission_helper');
const permission_configuration = require('../permission/permissions.json').TalendConfigurationApi;
const internal_queries = require('./internal.queries.js');
const pgHelper = require('../../postgres/pgHelper');

const getDataSourceForProject = async (projectCode, selectedDb, loopback) => {
  var queryString = internal_queries.getCtxPostgresQuery(projectCode, selectedDb);
  //console.log(queryString);
  var res = await pgHelper.executeQuery(queryString);
  if (res instanceof Error || res.length == 0)
  {
    console.error(`Error occured during datasource creation for ${projectCode}`, res);
    return;
  }
  console.log(`dsConfig for ${projectCode}`, res);

  var dsConfig = {
    connector: require('loopback-connector-postgresql'),
    host: res[0].dbHostname,
    port: res[0].dbPort ? res[0].dbPort : 5432,
    database: res[0].dbInstance,
    password: res[0].dbPassword,
    user: res[0].dbUser
  };
  if(res[0].instanceName.includes("8")){
    dsConfig.ssl=true;
    dsConfig.sslmode="require";
  }
  var dataSource = loopback.dataSource(`talendProjectsList_${projectCode}`, dsConfig);
  dataSource.on('error', function (error) {
    console.error('HERE IS AN ERROR!' ,error);
    dataSource.disconnect();
    return;
  });
  return dataSource;

};
const getEncryptionServiceURL = ()=>{
var configFile = '';
switch (process.env.NODE_ENV)
{
  case 'development':
    configFile = '../../config.json';
    break;
  case 'staging':
    configFile = '../../config.staging.json';
  break;
  case 'evaluation':
    configFile = '../../config.eval.json';
  break;
  case 'production':
    configFile = '../../config.production.json';
    break;
  default:
    break;
}
const encryptionService = require(configFile).encryptionServiceRootURL;
return encryptionService;
}

/**
 * The applications internal API
 *
 * @param {*} loopback
 */
module.exports = (loopback) => {

  router.get("/", (req,res) => {
    res.send("Internal API Documentation" +
             "\n[GET] /version" +
             "\n[DELETE] /loopback/configuration" +
             "\n[POST] /loopback/schema-model");
    res.end();
  });

  router.get("/version", passport.authenticate('jwt', {session: false}), (req, res) => {
    //check if git_tag_version.json exists

    console.log("VERSION CALLED!");
    console.log(req.user);

    if( fs.existsSync("./git_tag_version.json") ) {
      fs.readFile("./git_tag_version.json", (err, content) => {
        const GIT_BRANCH = JSON.parse(content).git_version;
        helpers.successCallback(res, {
          "version": GIT_BRANCH.startsWith("refs/tags/") ? GIT_BRANCH.substring(11) : GIT_BRANCH,
          "environment": process.env.NODE_ENV
        });
      });
    } else {
      helpers.successCallback(res, {
        "version": "Development Version",
        "environment": process.env.NODE_ENV
      });
    }
  });

  router.get("/file", passport.authenticate('jwt', {session: false}), (req,res) => {

    fs.readFile(req.query.filepath, (err, content) => {
      res.send(content);
    });

  });

  router.get("/local-structure", passport.authenticate('jwt', {session: false}), (req, res) => {

    fs.readdir("./", (err, items) => {
      helpers.successCallback(res, items);
    });

  });

  router.post("/encryptPassword", passport.authenticate('jwt', {session: false}), async (req, res) => {
    try {
      var environment=req.body.environment;
      var projectName=req.body.projectName;
      var plainText= req.body.plainText;
      // var x = `https://esbp5.eaoo.talend.intranet.cnb:41025/services/TalendEncryptionService/${environment}/${projectName}/encrypt`
      // console.log(x)
      //var encryptionResult = await axios.post('https://by0xaw.bayer.cnb:41025/services/TalendEncryptionService/encrypt', req.body);
      var encryptionServiceURL = getEncryptionServiceURL();
      var encryptionResult = await axios.post(`${encryptionServiceURL}TalendEncryptionService/${environment}/${projectName}/encrypt`, plainText);
      //console.log({environment,projectName,projectName});
      //console.log(encryptionResult.data)
      //var encryptionResult = await axios.post('https://esbp5.eaoo.talend.intranet.cnb:41025/services/TalendEncryptionService/Qa/DDDD/encrypt', req.body);
      // console.log(req.body)
      // console.log(encryptionResult.data)
      res.send(encryptionResult.data);
    } catch (e) {
      console.error('Exception caught while requesting password encryption', e);
      if(e.response)
      {
        res.status(e.response.status).send(e.response.data);
      }
      else
      {
        res.status(500).send(e.Error);
      }
    }
  });

  /**
   * create loopback models
   */
  router.post("/loopback/schema-model", passport.authenticate('jwt', {session: false}), async (req, res) => {

    const projectSchema = ['DEV','QA','PROD'];
    const reqEnv = req.body.project_code;
    const reqDb = req.body.selectedDb;
    const dbDs = await getDataSourceForProject(reqEnv, reqDb, loopback);
    if (!dbDs)
    {
      return helpers.errorCallback(res, {
        "result": "failure"
      });
    }
    const modelCommonProperties = require('./taskcontextvariables.model');
    _.forEach(projectSchema, (schema) => {
      var schemaModelName = _.toLower(reqEnv + '_' + schema);
      //console.log(reqEnv);
      if(reqEnv=="MM4B" && schema=="PROD")
      {
      var schemaName = 'MM4B_PROD_T8';
      }
      else{
      var schemaName = reqEnv + '_' + schema;
      }
      //console.log(schemaName)
      var modelConfig =  {
        "name": schemaModelName,
        "plural": schemaModelName,
        "base": "PersistedModel",
        "idInjection": true,
        "options": {
          "validateUpsert": true,
          "postgresql": {
            "schema": schemaName,
            "table": "taskcontextvariables"
          }
        },
        "properties": modelCommonProperties
      };
      var createModel =  dbDs.createModel(modelConfig.name, modelConfig.properties, modelConfig.options);
      createModel.beforeRemote('**', async function (ctx, modelInstance) {
        var urlPattern = new RegExp('^\/api\/([A-z0-9]+)_([A-z]+)$');
        var extrValues = urlPattern.exec(ctx.req.baseUrl);
        console.log("ctx.req.baseUrl " + ctx.req.baseUrl);
        var projectCode = extrValues[1].toUpperCase();
        var env = extrValues[2].toUpperCase();
        var authorizedRoles;
        var errUnAuth = new Error();
        errUnAuth.status = 401;
        errUnAuth.message = 'Authorization Required';
        errUnAuth.code = 'AUTHORIZATION_REQUIRED';
        var isAuthenicated = false;
        if (ctx.req.route.methods.put  ||
            ctx.req.route.methods.post ||
            ctx.req.route.methods.patch ||
            ctx.req.route.methods.del)
        {
          if (env !== 'DEVS')
          {
            throw errUnAuth;
          }
          isAuthenicated = await permission_helper.isAuthenicated(projectCode, undefined, env, permission_configuration.write, ctx.req.headers.authorization.substring(7));
          console.log('======================',projectCode, env);
        }
        else
        {
          isAuthenicated = await permission_helper.isAuthenicated(projectCode, undefined, env, permission_configuration.read, ctx.req.headers.authorization.substring(7));
          console.log('----------------------',projectCode, env);
        }
        if (!isAuthenicated)
        {
          throw errUnAuth;
        }
        return;
      });

      loopback.model(createModel);
    });
    helpers.successCallback(res, {
      "result": "success"
    });
  });

  /**
   * remove model from loopback configuration
   */

  router.delete("/loopback/configuration", passport.authenticate('jwt', {session: false}), (req, res) => {
    var modelName = req.body.modelName;
    var where = req.body.where;
    if(modelName) {
      app.models[modelName].destroyAll(where, (err, info) => {
        if (err) {
          helpers.errorCallback(err);
        } else {
          helpers.successCallback({
            result: 'success'
          });
        }
      });
    }
  });

  return router;
};
