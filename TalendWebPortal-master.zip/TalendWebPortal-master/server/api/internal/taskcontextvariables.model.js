/**
 * The loopback data model for the Postgres Task Context Variables table
 */
module.exports = {
  "env": {
    "type": "string",
    "id": true
  },
  "variable_name": {
    "type": "string",
    "postgresql": {
      "columnName": "variableName",
      "dataType": "character varying"
    }
  },
  "scope": {
    "type": "string"
  },
  "active": {
    "type": "boolean"
  },
  "job_name": {
    "type": "string",
    "postgresql": {
      "columnName": "jobName",
      "dataType": "character varying"
    }
  },
  "variable_value": {
    "type": "string",
    "postgresql": {
      "columnName": "variableValue",
      "dataType": "character varying"
    }
  },
  "created_by": {
    "type": "string",
    "postgresql": {
      "columnName": "createdBy",
      "dataType": "character varying"
    }
  },
  "created": {
    "type": "date",
    "postgresql": {
      "columnName": "createdDate",
      "dataType": "timestamp without time zone"
    }
  },
  "modified_by": {
    "type": "string",
    "postgresql": {
      "columnName": "updatedBy",
      "dataType": "character varying"
    }
  },
  "modified": {
    "type": "date",
    "postgresql": {
      "columnName": "updatedDate",
      "dataType": "timestamp without time zone"
    }
  }
}
