
var getCtxPostgresQuery = (projectCodeFilter, db) =>{

  return `
  SELECT
  	p.code,
    	p.name,
      ctx."instanceName",
    	ctx."dbHostname",
    	ctx."dbInstance",
    	ctx."dbUserPromotion" AS "dbUser",
    	ctx."dbPasswordPromotion" AS "dbPassword",
    	ctx."dbPort"
    FROM "[SCHEMA_NAME]"."projectDBCTX" ctx
    LEFT JOIN "[SCHEMA_NAME]"."projects" p
    	ON p.id = ctx.project_id
    WHERE COALESCE(ctx."dbHostname", '') <> ''
    AND COALESCE(ctx."dbInstance", '') <> ''
    AND COALESCE(ctx."dbUserPromotion", '') <> ''
    AND COALESCE(ctx."dbPasswordPromotion", '') <> ''
    AND ((ctx."isEnvDefault" AND p.code = '${projectCodeFilter}')
  	OR ctx."instanceName"='${db}')
    ORDER BY CASE WHEN ctx."isEnvDefault" THEN 0 ELSE 1 END
    ;`;
};

module.exports = {
  getCtxPostgresQuery
};
