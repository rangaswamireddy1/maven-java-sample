const pg = require('pg');

var dataSourceConfigFile = '';
switch (process.env.NODE_ENV)
{
  case 'development':
    dataSourceConfigFile = '../datasources.json';
    break;
  case 'staging':
    dataSourceConfigFile = '../datasources.staging.json';
  break;
  case 'evaluation':
    dataSourceConfigFile = '../datasources.eval.json';
  break;
  case 'production':
    dataSourceConfigFile = '../datasources.production.json';
    break;
  default:
    break;
}
const talendEnterpriseDbConfig = require(dataSourceConfigFile).postgres;


const executeQuery = async (queryString, dbConfig, schemaName) => {
  if (!dbConfig)
  {
    dbConfig = talendEnterpriseDbConfig;
  }
  if (!schemaName)
  {
    schemaName = talendEnterpriseDbConfig.schema;
  }
  queryString = queryString.replace(/\[SCHEMA_NAME\]/g, schemaName);
  try {
    var pgClient = new pg.Client(dbConfig);
    pgClient.connect().catch((e)=>{
      console.error('Error while connecting to DB.', e);
      return new Error(e);
    });
    var res = await pgClient.query(queryString);
    await pgClient.end();
    return res.rows;

  } catch (e) {
    console.error('Exception caught while loading tasks from DB', e);
    return new Error(e);
  }
};


module.exports = {
  executeQuery
};
