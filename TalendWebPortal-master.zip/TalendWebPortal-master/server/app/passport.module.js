'use strict'

const jwt = require('jsonwebtoken');
const passport = require('passport');
const JwtStrategy = require('passport-jwt').Strategy;
const ExtractJwt = require('passport-jwt').ExtractJwt;

const _ = require('underscore');

module.exports = (app, configuration) => {
    const PassportConfigurator = require('../common/passport-configurator.module');
    const passportConfigurator = new PassportConfigurator(app, configuration);

    // Load the provider configurations
    let config = {};
    try {
        config = require('../../providers.json');
    } catch (err) {
        console.error('Please configure your passport strategy in `providers.json`.');
        console.error('Copy `providers.json.template` to `providers.json` and replace the clientID/clientSecret values with your own.');
        console.trace(err);
        process.exit(1);
    }

    // Initialize passport
    passportConfigurator.init();

    //We need flash messages to see passport errors
    //app.use(flash());

    // Set up related models
    passportConfigurator.setupModels({
        userModel: app.models.user,
        userIdentityModel: app.models.UserIdentity,
        userCredentialModel: app.models.UserCredential,
    });

    // Configure passport strategies for third party auth providers
    for (var s in config) {
        var c = config[s];
        c.session = c.session !== false;
        passportConfigurator.configureProvider(s, c);
    }

    const opts = {};

    opts.jwtFromRequest = ExtractJwt.fromAuthHeaderAsBearerToken();
    opts.secretOrKey = configuration[process.env.NODE_ENV]['jwt']['secret'];

    passport.use(new JwtStrategy(opts, function(user, done) {
        done(null, user);
    }));

    // Set passport as authentication middleware for /api
    app.use("/api", passport.authenticate('jwt', {session: false}), (req, res, next) => {
      next();
    });
}
