
That is not a proper readme. This will need to be deleted adjusted.
(testing TEA-3580)

TEA-3580 review test from GHE UI edit


## Project setup Steps
#### Git global setup
```
git config --global user.name "Firstname Lastname"
git config --global user.email "...@bayer.com"
```
#### Existing folder
```
cd existing_folder
git init
git remote add origin git@by-gitlab.de.bayer.cnb:EMEXR/pushnotification-ui.git
git add .
git commit -m "Initial commit"
git push -u origin master`
```
#### Existing Git repository
```
cd existing_repo
git remote rename origin old-origin
git remote add origin git@by-gitlab.de.bayer.cnb:EMEXR/pushnotification-ui.git
git push -u origin --all
git push -u origin --tags
```
    
