'use strict';

app.factory('AuthService', ['User', '$q', '$rootScope', 'LoopBackAuth', 'Restangular', '$state', '$mdDialog', 'AppTableService', 'AppDropDownsService', '_',
function(User, $q, $rootScope, LoopBackAuth, Restangular, $state, $mdDialog, AppTableService, AppDropDownsService, _) {

  function storeJwt(jsonWebToken) {
    $rootScope.jwt = jsonWebToken;
    Restangular.setDefaultHeaders({Authorization: "Bearer " + jsonWebToken});
  }

  function getJwt() {
    return $rootScope.jwt;
  }

  function showAlertDialog(errorTitle, errorMessage) {
    $mdDialog.show(
      $mdDialog.alert()
      .title(errorTitle)
      .ariaLabel(errorTitle)
      .textContent(errorMessage)
      .ok('Ok')
    );
  }

  function setCurrentUser(user) {
    console.log(user);
    if(!_.isEmpty(user.email)) {
      var usernameParts = user.email.split(/[.@]+/);
      $rootScope.currentUser = {
        id:  LoopBackAuth.currentUserId,
        tokenId: LoopBackAuth.accessTokenId,
        firstName: usernameParts[0].toUpperCase(),
        lastName: usernameParts[1].toUpperCase(),
        email: user.email,
        cwid: user.cwid
      };
	    // get verison of app
	    var versionPromise = Restangular.one('internal/version').get();
	    versionPromise.then(function(response){
	      $rootScope.version = response['version'];
        $rootScope.environment = response['environment'];
        console.log($rootScope.currentUser);
        $rootScope.userFullyValidated = true;
	    }, function(response) {
	      AppTableService.defaultErrorHandling(response);
        console.log($rootScope.currentUser);
        $rootScope.userFullyValidated = true;
	    });

    }else{
      $rootScope.userFullyValidated = false;
      logout();
      $state.go('app.login');
    }
  }

  function login(username, password) {
    return User.login({username: username, password: password}, function(loginResponse) {
      storeJwt(loginResponse.jwt);
      validateUser(username, loginResponse.user);
    }).$promise;
  }

  function logout() {
    LoopBackAuth.clearUser();
    LoopBackAuth.clearStorage();
    $rootScope.userFullyValidated = false;
    $rootScope.currentUser = null;
    $rootScope.cwid = null;
    $rootScope.jwt = null;

    return User
    .logout()
    .$promise;

  }

  function register(email, password) {
    return User
    .create({
      email: email,
      password: password
    })
    .$promise;
  }

  function isAuthenticated() {
    return User.isAuthenticated();
  }

  function getCurrentUser() {
    return User.getCurrent();
  }

  function getUserAccount() {
    return Restangular.all('auth').get('account');
  }

  function validateUser(username, user) {
    if(_.isString(user)) {
      user = JSON.parse(user);
    }
    user['cwid'] = $rootScope.cwid ? $rootScope.cwid : username;
    $rootScope.employee = user;
    $rootScope.cwid = user.cwid;
    setCurrentUser(user);
  }

  function reValidateUser() {
    var user = getCurrentUser();
    validateUser(user.username, user);
  }

  function loopbackUserData() {
    return LoopBackAuth.currentUserId;
  }

  return {
    setCurrentUser: setCurrentUser,
    login: login,
    logout: logout,
    register: register,
    isAuthenticated: isAuthenticated,
    getCurrentUser: getCurrentUser,
    getUserAccount: getUserAccount,
    validateUser: validateUser,
    reValidateUser: reValidateUser,
    loopbackUserData: loopbackUserData,
    storeJwt: storeJwt,
    getJwt: getJwt
  };
}
]);
