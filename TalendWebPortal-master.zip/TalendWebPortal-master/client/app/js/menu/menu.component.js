'use strict';

var menuList = angular.module('menuList', []);

menuList.component('menuList', {
    templateUrl: 'js/menu/menu.template.html',

    controller: ['Restangular', '$mdEditDialog', '$q', '$timeout', '$mdDialog', '_', 'AppTableService', 'AppDropDownsService', '$rootScope', '$mdToast',
        function MenuListController(Restangular, $mdEditDialog, $q, $timeout, $mdDialog, _, AppTableService, AppDropDownsService, $rootScope, $mdToast) {
            var self = this;

            // Loopback model for component
            self.tableName = 'Menus';

            self.modelName = 'menus';

            self.primaryKey = 'id';

            self.displayField = 'menu_title';

            self.name = {
                singular: 'Menu',
                plural: 'Menus',
                title: 'Menus'
            };
            self.name.singularLcase = self.name.singular.toLowerCase();

            // Load rules via REST
            self.tableRecords = [];

            self.selected = [];

            self.selectedCriteria = [];

            self.fieldValidators = {
                'menu_title': { 'required': true },
                'menu_link': { 'required': true },
                'menu_permission_name': { 'required': true },
                'menu_order': { 'required': true }
            };

            self.predefinedDropdowns = {
            };

            self.dependantDropdowns = {};

            self.getUpdateDependantDropdown = AppTableService.getUpdateDependantDropdown;

            // Table options
           self.limitOptions =[10,20,50];

            self.options = {
                rowSelection: true,
                multiSelect: false,
                autoSelect: true,
                decapitate: false,
                largeEditDialog: false,
                boundaryLinks: false,
                limitSelect: true,
                pageSelect: true
            };

            // Search Filters
            self.filteredCollection = {};

            self.filterToggle = {
                state: false,
                tooltipText: {
                    false: 'Show Filter',
                    true: 'Hide Filter'
                }
            };

            self.query = {
                filter: {},
                order: 'menu_order',
                orderDesc: false,
                limit: 15,
                page: 1,
                where: {
                  menu_parent_id: null
                }
            };

            self.tableRecords = [];

            self.loadTableRecords = AppTableService.loadTableRecords;

            $rootScope.$watch('userFullyValidated', function (newValue, oldValue) {
                if ((oldValue !== newValue) && newValue) {
                    self.$onInit();
                }
            });

            self.$onInit = function () {
                if ($rootScope.userFullyValidated) {
                    var permissionName = 'SCREEN_' + self.name.title.toUpperCase().replace(/\s/g, '_');
                    self.permission = $rootScope.getPermission(permissionName);
                    self.loadTableRecords();
                }
            };

            // onOpenGetFilterValues: Gets unique and non-empty values for the filter dropdown of column on open
            self.onOpenGetFilterValues = AppTableService.onOpenGetFilterValues;

            // getFilterValues: Gets unique and non-empty values for the filter dropdown of column
            self.getFilterValues = AppTableService.getFilterValues;

            self.resetFilter = AppTableService.resetFilter;

            self.clearFilter = AppTableService.clearFilter;

            self.filterDate = {};

            self.handleDateFilter = AppTableService.handleDateFilter;

            // Table toolbar buttons
            self.reloadTableData = AppTableService.reloadTableData;

            self.clearRowSelection = function () {
                self.selected = [];
                self.menuChildren = [];
            };

            // Row actions
            self.selectRow = function(row) {
                self.menuChildrenPromise = Restangular.one(self.modelName, row.id).getList('children');
                self.menuChildrenPromise.then(function(records) {
                    self.menuChildren = records;
                });
            };

            self.refillRelatedDropDowns = function (row, fieldName) {
                var elementOpts = [];

                elementOpts = self.predefinedDropdowns[fieldName];

                return elementOpts;
            };

            self.editField = AppTableService.editField;

            self.editFieldAfterSave = function () {
                $rootScope.$emit('menuDataUpdated');
            };

            self.deleteRow = AppTableService.deleteRow;

            self.statusUpdate = AppTableService.statusUpdate;

            self.duplicateRow = AppTableService.duplicateRow;

            // Pagination
            self.toggleLimitOptions = AppTableService.toggleLimitOptions;

            self.logOrder = AppTableService.logOrder;

            self.logPagination = AppTableService.logPagination;

            self.showFullName = AppTableService.showFullName;

            // Add row
            function addRowDialogController($mdDialog, Restangular, $rootScope) {
                var addSelf = this;

                addSelf.name = self.name;

                // Form pre submit default values
                addSelf.row = {};

                addSelf.today = new Date();

                if (!_.isEmpty(addSelf.opts.addDefaults)) {
                    addSelf.row = _.clone(addSelf.opts.addDefaults);
                }

                addSelf.hide = function () {
                    $mdDialog.hide();
                };

                addSelf.cancel = function () {
                    $mdDialog.cancel();
                };

                addSelf.updatePermissionName = function (event) {
                    addSelf.row.menu_link = addSelf.row.menu_title.replace(/\s/g, '-').toLowerCase();
                    addSelf.row.menu_permission_name = 'MENU_' + addSelf.row.menu_title.replace(/\s/g, '_').toUpperCase();
                }

                addSelf.predefinedDropdowns = {
                    parentMenus: []
                };

                addSelf.loadPredefinedDropdowns = function () {
                    addSelf.predefinedDropdowns.parentMenus = _.clone(addSelf.parent.tableRecords);
                };
                addSelf.loadPredefinedDropdowns();

                addSelf.saveRow = function () {
                    addSelf.item.form.$setSubmitted();

                    if (addSelf.item.form.$valid) {
                        // Set defaults
                        addSelf.row.created = new Date();
                        addSelf.row.is_active = true;
                        addSelf.row.created_by = $rootScope.employee.cwid;
                        var saveRuleRest = Restangular.all(self.modelName);
                        addSelf.promise = saveRuleRest.customPOST(addSelf.row);
                        addSelf.promise.then(function (response) {
                            $mdDialog.hide();

                            $rootScope.$broadcast('menuDataUpdated');

                            $mdToast.show(
                                $mdToast.simple()
                                .position($rootScope.mdToastPosition)
                                .textContent('New ' + self.name.singular + ' added')
                                .hideDelay(3000)
                                .action('x')
                            );

                            if (!_.isEmpty(self.selected)) {
                                self.promise = self.selectRow(self.selected[0]);
                            } else {
                                self.loadTableRecords();
                            }

                        }, function (response) {
                            AppTableService.defaultErrorHandling(response, addSelf);
                        });
                    }
                };
            }

            self.addRow = function (opts) {
                opts = opts || {};

                $mdDialog.show({
                    // controller: angular.noop,
                    controller: addRowDialogController,
                    controllerAs: '$ctrl',
                    bindToController: true,
                    locals: { parent: self, opts: opts },
                    templateUrl: 'js/menu/menu.add.template.html',
                    preserveScope: true,
                    clickOutsideToClose: true,
                    focusOnOpen: false
                });
            };
        }
    ]
});
