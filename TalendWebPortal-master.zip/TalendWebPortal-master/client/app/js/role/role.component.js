'use strict';

var role = angular.module('role', []);

role.component('role', {
    templateUrl: 'js/role/role.template.html',

    controller: ['Restangular', '$mdEditDialog', '$q', '$timeout', '$mdDialog', '_', 'AppTableService', 'AppDropDownsService', '$rootScope', '$mdToast',
        function WhiteBlackListController(Restangular, $mdEditDialog, $q, $timeout, $mdDialog, _, AppTableService, AppDropDownsService, $rootScope, $mdToast) {
            var self = this;

            // Loopback model for component
            self.tableName = 'Roles';

            self.modelName = 'roles';

            self.primaryKey = 'id';

            //self.displayField = 'code';

            self.name = {
                singular: 'Role',
                plural: 'Roles',
                title: 'Roles'
            };
            self.name.singularLcase = self.name.singular.toLowerCase();

            // Load rules via REST
            self.tableRecords = [];

            self.selected = [];

            self.selectedCriteria = [];

            self.fieldValidators = {
                'code': { 'required': true },
                'name': { 'required': true }
            };

            self.predefinedDropdowns = {
            };

            self.dependantDropdowns = {};

            self.getUpdateDependantDropdown = AppTableService.getUpdateDependantDropdown;

            // Table options
            self.limitOptions =[10,20,50];

            self.options = {
                rowSelection: false,
                multiSelect: false,
                autoSelect: false,
                decapitate: false,
                largeEditDialog: false,
                boundaryLinks: false,
                limitSelect: true,
                pageSelect: true
            };

            // Search Filters
            self.filteredCollection = {};

            self.filterToggle = {
                state: false,
                tooltipText: {
                    false: 'Show Filter',
                    true: 'Hide Filter'
                }
            };

            self.query = {
                filter: {},
                order: 'name',
                orderDesc: false,
                limit: 15,
                page: 1,
                where: {}
            };

            self.tableRecords = [];

            self.loadTableRecords = AppTableService.loadTableRecords;

            self.$onInit = function () {
                if ($rootScope.userFullyValidated) {
                    var permissionName = 'SCREEN_' + self.name.title.toUpperCase().replace(/\s/g, '_');
                    self.permission = $rootScope.getPermission(permissionName);
                    self.loadTableRecords();
                }
            };

            // onOpenGetFilterValues: Gets unique and non-empty values for the filter dropdown of column on open
            self.onOpenGetFilterValues = AppTableService.onOpenGetFilterValues;

            // getFilterValues: Gets unique and non-empty values for the filter dropdown of column
            self.getFilterValues = AppTableService.getFilterValues;

            self.resetFilter = AppTableService.resetFilter;

            self.clearFilter = AppTableService.clearFilter;

            self.filterDate = {};

            self.handleDateFilter = AppTableService.handleDateFilter;

            // Table toolbar buttons
            self.reloadTableData = AppTableService.reloadTableData;

            self.clearRowSelection = AppTableService.clearRowSelection;

            // Row actions
            self.selectRow = function (rule) {

            };

            self.refillRelatedDropDowns = function (row, fieldName) {
                var elementOpts = [];

                elementOpts = self.predefinedDropdowns[fieldName];

                return elementOpts;
            };

            self.editField = AppTableService.editField;

            self.deleteRow = AppTableService.deleteRow;

            self.statusUpdate = AppTableService.statusUpdate;

            self.duplicateRow = AppTableService.duplicateRow;

            // Pagination
            self.toggleLimitOptions = AppTableService.toggleLimitOptions;

            self.logOrder = AppTableService.logOrder;

            self.logPagination = AppTableService.logPagination;

            self.showFullName = AppTableService.showFullName;

            // Add row
            function addRowDialogController($mdDialog, Restangular, $rootScope) {
                var addSelf = this;

                addSelf.name = self.name;

                // Form pre submit default values
                addSelf.row = {};

                addSelf.today = new Date();

                addSelf.hide = function () {
                    $mdDialog.hide();
                };

                addSelf.cancel = function () {
                    $mdDialog.cancel();
                };

                addSelf.saveRow = function () {
                    addSelf.item.form.$setSubmitted();

                    if (addSelf.item.form.$valid) {

                        var saveRuleRest = Restangular.all(self.modelName);
                        addSelf.promise = saveRuleRest.customPOST(addSelf.row);
                        addSelf.promise.then(function (response) {
                            $mdDialog.hide();

                            self.reloadTableData();
                            $mdToast.show(
                                $mdToast.simple()
                                .position($rootScope.mdToastPosition)
                                .textContent('New ' + self.name.singular + ' added')
                                .hideDelay(3000)
                                .action('x')
                            );
                        }, function (response) {
                            AppTableService.defaultErrorHandling(response, addSelf);
                        });
                    }
                };
            }

            self.addRow = function () {
                $mdDialog.show({
                    // controller: angular.noop,
                    controller: addRowDialogController,
                    controllerAs: '$ctrl',
                    bindToController: true,
                    locals: { parent: self },
                    templateUrl: 'js/role/role.add.template.html',
                    preserveScope: true,
                    clickOutsideToClose: true,
                    focusOnOpen: false
                });
            };

            // Manage Row
            function manageRolePermissionDialogController($mdDialog, Restangular, AppTableService, $rootScope, AuthService) {
                var roleManageSelf = this;

                roleManageSelf.tableName = 'RolePermission';

                roleManageSelf.modelName = 'rolePermissions';

                roleManageSelf.primaryKey = 'id';

              //  roleManageSelf.displayField = 'Code';

                roleManageSelf.name = {
                    singular: 'Role Permission',
                    plural: 'Role Permissions',
                    title: 'Role Permissions for ' +
                        '#' + roleManageSelf.currentRow[roleManageSelf.parent.primaryKey] + ', '
                        //roleManageSelf.currentRow[roleManageSelf.parent.displayField]
                };

                roleManageSelf.hide = function () {
                    $mdDialog.hide();
                };

                roleManageSelf.cancel = function () {
                    $mdDialog.cancel();
                };

                roleManageSelf.tableRecords = [];

                // Table options
                roleManageSelf.limitOptions = [5, 10];

                roleManageSelf.options = {
                    rowSelection: false,
                    multiSelect: false,
                    autoSelect: false,
                    decapitate: false,
                    largeEditDialog: false,
                    boundaryLinks: false,
                    limitSelect: true,
                    pageSelect: true
                };

                roleManageSelf.filterToggle = roleManageSelf.parent.filterToggle;

                // Search Filters
                roleManageSelf.filteredCollection = {};

                roleManageSelf.query = {
                    filter: {
                        Permission: 'MENU_'
                    },
                    where: {
                        RoleId: roleManageSelf.currentRow[roleManageSelf.parent.primaryKey]
                    },
                    order: 'Permission',
                    limit: 10,
                    page: 1
                };

                roleManageSelf.loadTableRecords = function () {
                    roleManageSelf.clearRowSelection();

                    roleManageSelf.tableRecords = [];

                    var param = AppTableService.buildQuery(roleManageSelf.query, roleManageSelf);

                    roleManageSelf.promise = Restangular.all(roleManageSelf.modelName + param).getList();
                    roleManageSelf.promise.then(function (rolePermissions) {

                        roleManageSelf.promise = Restangular.all('Permissions').getList();
                        roleManageSelf.promise.then(function (permissions) {

                            _.each(permissions, function (permission) {
                                var rolePermission = {
                                    RoleId: roleManageSelf.currentRow[roleManageSelf.parent.primaryKey],
                                    Permission: permission.Title,
                                    PermissionId: permission.Id,
                                    Read: false,
                                    Create: false,
                                    Update: false,
                                    Delete: false
                                };

                                var permissionAttachedWithRole = _.find(rolePermissions, {
                                    PermissionId: permission.Id
                                });

                                if (permissionAttachedWithRole) {
                                    rolePermission.Id = permissionAttachedWithRole.Id;
                                    rolePermission.Read = permissionAttachedWithRole.Read;
                                    rolePermission.Create = permissionAttachedWithRole.Create;
                                    rolePermission.Update = permissionAttachedWithRole.Update;
                                    rolePermission.Delete = permissionAttachedWithRole.Delete;
                                }

                                roleManageSelf.checkAllSet(rolePermission);

                                roleManageSelf.tableRecords.push(rolePermission);
                            });

                        }, function (response) {
                            AppTableService.defaultErrorHandling(response, roleManageSelf);
                        });
                    }, function (response) {
                        AppTableService.defaultErrorHandling(response, roleManageSelf);
                    });
                };

                roleManageSelf.clearRowSelection = AppTableService.clearRowSelection;

                roleManageSelf.loadTableRecords();

                roleManageSelf.changeCB = function (event, changeRow) {
                    var rowRest;

                    var row = _.clone(changeRow);
                    var permissionName = row.Permission;
                    delete row.Permission;
                    delete row.All;

                    var isPost = false;

                    if (row.Id) {
                        rowRest = Restangular.one(roleManageSelf.modelName + '(' + row.Id + ')');
                        roleManageSelf.promise = rowRest.customPATCH(row);
                    } else {
                        rowRest = Restangular.all(roleManageSelf.modelName);
                        roleManageSelf.promise = rowRest.customPOST(row);
                        isPost = true;
                    }

                    roleManageSelf.promise.then(function (response) {
                        row.Permission = permissionName;
                        changeRow = _.clone(row);
                        roleManageSelf.checkAllSet(changeRow);

                        if (isPost) {
                            changeRow.Id = response.Id;
                        }

                        // Update Menu if a permission of Menu is changed for the current user's role
                        if (($rootScope.employee.Role.Code === roleManageSelf.currentRow.Code) && (row.Permission.match(/MENU_/))) {
                            AuthService.reValidateUser();
                        }
                    }, function (response) {
                        AppTableService.defaultErrorHandling(response, roleManageSelf);
                    });
                };

                roleManageSelf.setAll = function (event, row) {
                    row.Read = row.All;

                    if (row.Permission.indexOf('MENU') !== 0) {
                        row.Create = row.All;
                        row.Update = row.All;
                        row.Delete = row.All;
                    }

                    roleManageSelf.changeCB(event, row);
                };

                roleManageSelf.checkAllSet = function (row) {
                    if (row.Permission.indexOf('MENU') === 0) {
                        if (row.Read) {
                            row.All = true;
                        } else {
                            row.All = false;
                        }
                    } else {
                        if (row.Read && row.Create && row.Update && row.Delete) {
                            row.All = true;
                        } else {
                            row.All = false;
                        }
                    }
                };

                // Pagination
                roleManageSelf.toggleLimitOptions = AppTableService.toggleLimitOptions;

                roleManageSelf.logOrder = AppTableService.logOrder;

                roleManageSelf.logPagination = AppTableService.logPagination;
            }

            self.manageRolePermission = function (event, row) {
                $mdDialog.show({
                    // controller: angular.noop,
                    controller: manageRolePermissionDialogController,
                    controllerAs: '$ctrl',
                    bindToController: true,
                    locals: { parent: self, currentRow: row },
                    templateUrl: 'js/role/manage-role-permission.template.html',
                    preserveScope: true,
                    clickOutsideToClose: true,
                    focusOnOpen: false
                });
            };
        }
    ]
});
