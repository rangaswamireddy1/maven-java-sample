'use strict';

var projectJobDescriptions = angular.module('projectJobDescriptions', []);

projectJobDescriptions.component('projectJobDescriptions', {
  templateUrl: 'js/project-job-descriptions/project-job-descriptions.template.html',

  controller: ['Restangular', '$state', '$stateParams', '$mdEditDialog', '$filter', '$http', '$timeout', '$mdDialog', '_', 'AppTableService', '$mdToast', '$rootScope', 'AppDropDownsService', '$mdConstant', 'moment',
  function ProjectJobDescriptionsController(Restangular, $state, $stateParams, $mdEditDialog, $filter, $http, $timeout, $mdDialog, _, AppTableService, $mdToast, $rootScope, AppDropDownsService, $mdConstant, moment) {
    var self = this;

    // Loopback model for component
    self.tableName = 'runtimes';

    self.modelName = 'runtimes';

    self.go = $state.go;

    self.name = {
      tableName: 'Global Address Book',
      title: ''
    };

    self.hide = function () {
      $mdDialog.hide();
    };

    self.cancel = function () {
      $mdDialog.cancel();
    };

    self.selected = self.tableRecords = [];

    self.row = {};

    self.filterToggle = {
      state: false,
      tooltipText: {
        false: 'Show Filter',
        true: 'Hide Filter'
      }
    };

    // Table options
     self.limitOptions =[10,20,50];

    self.options = {
      rowSelection: false,
      multiSelect: false,
      autoSelect: true,
      decapitate: false,
      largeEditDialog: false,
      boundaryLinks: false,
      limitSelect: true,
      pageSelect: true
    };

    self.clearRowSelection = function (row) {
      self.selected = [];
    };

    self.clearFilter = AppTableService.clearFilter;

    self.query = {
        filter: {},
        order: '',
        orderDesc: false,
        limit: 15,
        page: 1,
        where: {}
    };

    self.$onInit = function () {
      if (!_.isUndefined($stateParams.id)){
          //get project name from id
          // self.promise = Restangular.one(self.modelName, $stateParams.id).get();
          // self.promise.then(function (results) {
            var projectName  = $stateParams.id;
            self.name.title = 'Job List for Project, ' + projectName;
            self.promise = Restangular.one('talend/job').get();
            self.promise.then(function (response) {
              var response = JSON.parse(response);
              self.tableRecords = _.filter(response.result, {projectName: projectName});
            });
          // },function(err){
          // });
      }
    };
  }
]
});
