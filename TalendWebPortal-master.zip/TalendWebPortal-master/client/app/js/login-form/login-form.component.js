'use strict';

var loginForm = angular.module('loginForm', []);

loginForm.component('loginForm', {
    templateUrl: 'js/login-form/login-form.template.html',
    controller: ['$state', '$mdDialog', '$rootScope', 'AuthService', 'AppTableService', '$stateParams', '_', '$location', 'RestService',
    function LoginFormController($state, $mdDialog, $rootScope, AuthService, AppTableService, $stateParams, _, $location, RestService) {
        var self = this;

        self.appName = $rootScope.appName;

        self.loginForm = {};

        var port = $location.port();
        
        self.afterLoginHomepage = 'app.projects';

        self.params = $stateParams;
        self.$onInit = function () {
/*
          // Used to autologin while development/testing
            var username = '';
            var password = '';
            AuthService.login(
                username,
                password
            );
*/
            // If user is already logged in, redirect to homepage
            if(AuthService.isAuthenticated() && AuthService.loopbackUserData() !== null) {
                $state.go(self.afterLoginHomepage);
            }
        };

        self.showAlertDialog = function(errorTitle, errorMessage) {
            $mdDialog.show(
                $mdDialog.alert()
                .title(errorTitle)
                .ariaLabel(errorTitle)
                .textContent(errorMessage)
                .ok('Ok')
            );
        };

        self.login = function() {
            self.loginForm.form.$setSubmitted();

            if(self.loginForm.form.$valid) {
                // console.log(self.loginForm.data);
                var errorTitle, errorMessage;

                var username = self.loginForm.data.username;
                var password = self.loginForm.data.password;

                AuthService.login(
                    username,
                    password
                )
                .then(function(loginReponse) {
                }, function(response) {
                    self.loginForm.form.$submitted = false;

                    // console.log(response);
                    switch (response.status) {
                        case 401:
                            errorTitle = 'Invalid credentials';
                            errorMessage = 'Please enter correct credentials';
                            self.showAlertDialog(errorTitle, errorMessage);
                        break;
                        default:
                            AppTableService.defaultErrorHandling(response);
                    }
                });
            }
        };

        $rootScope.$watch('userFullyValidated', function(newValue, oldValue) {
            if((oldValue !== newValue) && newValue) {
                // If loginRedirect is found, redirect user to
                // loginRedirect else to homepage
                if(!_.isEmpty($stateParams.loginRedirect)) {
                    $state.go($stateParams.loginRedirect);
                } else {
                    $state.go(self.afterLoginHomepage);
                }
            }
        });
    }
]
});
