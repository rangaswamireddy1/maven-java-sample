'use strict';

var httpErrors = angular.module('httpErrors', []);
