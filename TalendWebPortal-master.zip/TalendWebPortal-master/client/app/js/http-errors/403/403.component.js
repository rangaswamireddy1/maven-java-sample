'use strict';

httpErrors.component('error403', {
    templateUrl: 'js/http-errors/403/403.template.html',

    controller: ['Restangular', '$mdEditDialog', '$q', '$timeout', '$mdDialog', '_',
        function SimulationsController(Restangular, $mdEditDialog, $q, $timeout, $mdDialog, _) {
            var self = this;

        }
    ]
});
