'use strict';

runtimes.component('jobList', {
    templateUrl: 'js/runtimes/job-list/job-list.template.html',

    bindings: {
        promise: '<',
        tableRecords: '<',
    },

    require: {
        runtimesCtrl: '^runtimes'
    },

    controller: ['Restangular', '$state', '$stateParams', '$mdEditDialog', '$filter', '$http', '$timeout', '$mdDialog', '_', 'AppTableService', '$mdToast', '$rootScope', 'AppDropDownsService', '$mdConstant', 'moment',
    function JobListController(Restangular, $state, $stateParams, $mdEditDialog, $filter, $http, $timeout, $mdDialog, _, AppTableService, $mdToast, $rootScope, AppDropDownsService, $mdConstant, moment) {
            var self = this;

            // Loopback model for component
            self.modelName = 'runtimes';

            self.name = {
                singular: 'Job List',
                plural: 'Job Lists',
                title: 'Job Lists'
            };
            self.name.singularLcase = self.name.singular.toLowerCase();

            self.selected = [];

            self.tableRecords = [];

            self.selectedCriteria = [];

            self.fieldValidators = {};

            self.predefinedDropdowns = {};

            self.dependantDropdowns = {};

            self.getUpdateDependantDropdown = AppTableService.getUpdateDependantDropdown;

            // Table options
          self.limitOptions =[10,20,50];

            self.options = {
                rowSelection: false,
                multiSelect: false,
                autoSelect: false,
                decapitate: false,
                largeEditDialog: false,
                boundaryLinks: false,
                limitSelect: true,
                pageSelect: true
            };

            // Search Filters
            self.filteredCollection = {};

            self.filterToggle = {
              state: false,
              tooltipText: {
                false: 'Show Filter',
                true: 'Hide Filter'
              }
            };

            self.query = {
                filter: {},
                order: '',
                orderDesc: false,
                limit: 5,
                page: 1,
                where: {}
            };

            self.loadTableRecords = AppTableService.loadTableRecords;

            $rootScope.$watch('userFullyValidated', function(newValue, oldValue) {
                //if((oldValue !== newValue) && newValue) {
                    self.$onInit();
                //}
            });

            self.$onInit = function() {

            };

            // getFilterValues: Gets unique and non-empty values for the filter dropdown of column
            self.getFilterValues = AppTableService.getFilterValues;

            self.resetFilter = AppTableService.resetFilter;

            self.clearFilter = AppTableService.clearFilter;

            // Table toolbar buttons
            //self.reloadTableData = AppTableService.reloadTableData;

            self.clearRowSelection = AppTableService.clearRowSelection;

            self.filterDate = {};

            self.handleDateFilter = AppTableService.handleDateFilter;

            self.exportTableData = function() {
                // var selectedObjectFieldId  = self.runtimesCtrl.selectedObjectField[0].id;
                // $window.open($rootScope.baseServerApiUrl + '/' + self.modelName + '/exportGlobalCodes/' + selectedObjectFieldId, '_blank');
            };

            self.$onChanges = function (changesObj) {
                // console.log(changesObj);
                if (changesObj.tableRecords) {
                    self.parentSelectionText = '';

                    if (!_.isEmpty(self.runtimesCtrl.selected)) {
                        self.parentSelectionText = ' for, ' + self.runtimesCtrl.selected[0].projet_name;
                    } else {
                        delete self.query.where;
                    }

                    self.clearRowSelection();
                    // self.clearFilter();
                }
            };

            // Row actions
            self.selectRow = function(rule) {

            };
            //this function will execute the job when user clicks on respective job's Execute button in respective environment
            self.executeJob =function(row, env){
                    //get jobId
                    let jobId = row.id;
                    var data = {
                                jobId: row.id,
                                environment: env.toLowerCase()
                            }
                     //post jobId as parameter to executeJob service
                     var promise = Restangular.one('talend/job/run').customPOST(data);;

                     promise.then(function (response) {
                         //if success show alert box with given message
                         $mdDialog.show(
                             $mdDialog.alert()
                             .title()
                             .ariaLabel(row.label +":"+ response.message)
                             .textContent( row.label +":"+ response.message)
                             .ok('Ok')
                         );
                  }, function(response) {
                      // Error
                      AppTableService.defaultErrorHandling(response);
                  });

                }

            function displayDialogController($mdDialog, Restangular, $rootScope, opts) {
                var addSelf = this;
                addSelf.name = {
                    tableName: 'Additional Information for, ' + opts.label,
                    title: 'Additional Information'
                };

                addSelf.hide = function () {
                    $mdDialog.hide();
                };

                addSelf.cancel = function () {
                    $mdDialog.cancel();
                };
                addSelf.tableRecords = opts;
            }

            self.displayJobInfo = function (opts) {
                 var opts = opts || {};

                  $mdDialog.show({
                      // controller: angular.noop,
                      controller: displayDialogController,
                      controllerAs: '$ctrl',
                      bindToController: true,
                      locals: { parent: self, opts: opts },
                      templateUrl: 'js/runtimes/job-list/job-details.template.html',
                      preserveScope: true,
                      clickOutsideToClose: true,
                      focusOnOpen: false
                  });
              };

            self.editField = AppTableService.editField;

            self.deleteRow = AppTableService.deleteRow;

            self.duplicateRow = AppTableService.duplicateRow;

            // Pagination
            self.toggleLimitOptions = AppTableService.toggleLimitOptions;

            self.logOrder = AppTableService.logOrder;

            self.logPagination = AppTableService.logPagination;
        }
    ]
});
