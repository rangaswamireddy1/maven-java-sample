'use strict';

var runtimes = angular.module('runtimes', []);

runtimes.component('runtimes', {
    templateUrl: 'js/runtimes/runtimes.template.html',

    controller: ['Restangular', '$state', '$mdEditDialog', '$q', '$timeout', '$mdDialog', '_', 'AppTableService', '$mdToast', '$rootScope', 'moment', '$window',
    function RuntimesController(Restangular, $state, $mdEditDialog, $q, $timeout, $mdDialog, _, AppTableService, $mdToast, $rootScope, moment, $window) {
        var self = this;

        self.tableName = 'runtimes';

        self.modelName = 'runtimes';

        self.name = {
            singular: 'Project Overview',
            plural: 'Project Overview',
            title: 'Project Overview'
        };
        self.name.singularLcase = self.name.singular.toLowerCase();

        // Load rules via REST
        self.tableRecords = [];

        self.selected = [];

        self.jobListOneTime =[];

        self.selectedObjectField = [];

        self.fieldValidators = {};

        self.predefinedDropdowns = {
            EnvType: {
                DEV: "D1",
                QA: "Q2",
                PROD: "P2"
            },
            envDisplayRank:{
                D1 : 1,
                E1 : 2,
                Q2 : 3,
                I1 : 4,
                P2 : 5
            }
        };

        self.dependantDropdowns = {};

        self.loadData = 0;

        self.getUpdateDependantDropdown = AppTableService.getUpdateDependantDropdown;

        // Table options
         self.limitOptions =[5,10,20,50];

        self.options = {
            rowSelection: true,
            multiSelect: false,
            autoSelect: false,
            decapitate: false,
            largeEditDialog: false,
            boundaryLinks: false,
            limitSelect: true,
            pageSelect: true
        };

        // Search Filters
        self.filteredCollection = {};

        self.filterToggle = {
            state: false,
            tooltipText: {
                false: 'Show Filter',
                true: 'Hide Filter'
            }
        };

        self.query = {
            filter: {},
            order: false,
            orderDesc: false,
            limit: 10,
            page: 1,
            where: {
                active: true,
                version: 641
            },
            contains: {
                relation: 'activemqs',
                scope: {
                    where: {
                        active: true,
                        version: 641
                    }
                }
            }
        };

        $rootScope.$watch('userFullyValidated', function(newValue, oldValue) {
            if((oldValue !== newValue) && newValue) {
                self.$onInit();
            }
        });

        $rootScope.$on('vCountrySwitched', function(event, data) {
            self.$onInit();
        });

        self.loadTableRecords = AppTableService.loadTableRecords;

        self.deleteRow = AppTableService.deleteRow;

        // Pagination
        self.toggleLimitOptions = AppTableService.toggleLimitOptions;

        self.logOrder = AppTableService.logOrder;

        self.logPagination = AppTableService.logPagination;

        self.clearRowSelection = function() {
            self.selected = [];
            self.jobList = [];
            self.globalCodes = [];
        };

        self.$onInit = function(reloadTableData) {
            if($rootScope.userFullyValidated) {
                if(!reloadTableData) {
                    reloadTableData = false;
                }
                var queryParams =  {
                    where:{
                        is_active: true,
                        env_name:"ALL",
                        module_type:"ELK",
                        is_default:true,
                        env_type: {
                            inq: ["PROD", "DEV"]
                        }
                    }
                };
                var params = AppTableService.buildQuery(queryParams, {});
                self.promise = Restangular.one('software_modules').get(params);
                self.promise.then(function(response) {
                    if(!_.isEmpty(response)){
                        var data = response.plain();
                        var linkToKibanaDev = _.find(data, ['env_type', 'DEV']);
                        var linkToKibanaProd = _.find(data, ['env_type', 'PROD']);
                        var param = AppTableService.buildQuery(self.query, self);
                        self.promise = Restangular.all(self.modelName).getList(param);
                        self.promise.then(function(records) {
                            var projects = [];
                            _.forEach(_.groupBy(records, 'project_code'), function(key, value) {
                                //sort by created date
                                key = _.sortBy(key, function(dateObj) {
                                    return new Date(dateObj.creation_date);
                                });
                                _.reverse(key);
                                var orderyEnv =  _.sortBy(key, function(element){
                                    var rank = self.predefinedDropdowns.envDisplayRank;
                                    return rank[element['env']];
                                });

                                var linkToKibana = [];
                                var env = self.predefinedDropdowns.EnvType;
                                _.forEach(env, function(obj, env) {
                                    if(env === 'PROD' || env === 'QA'){
                                        linkToKibana.push({env : obj, link : linkToKibanaProd.url + self.linkToKibana(key[0]['project_name'], env)});
                                    }else{
                                        linkToKibana.push({env : obj, link : linkToKibanaDev.url + self.linkToKibana(key[0]['project_name'], env)});
                                    }
                                });

                                var coreconfigProperties = [];
                                _.forEach(env, function(obj, env) {
                                  if(env === 'DEV'){
                                    coreconfigProperties.push({env : env});
                                  }
                                });

                                //activemqs
                                var activemqs = _.without(_.map(orderyEnv, 'activemqs'), undefined)[0];
                                if(!_.isEmpty(activemqs)){
                                    //sort by created date
                                    activemqs = _.sortBy(activemqs, function(dateObj) {
                                        return new Date(dateObj.creation_date);
                                    });
                                    _.reverse(activemqs);
                                    var activemqsData =  _.sortBy(activemqs, function(element){
                                        var rank = self.predefinedDropdowns.envDisplayRank;
                                        return rank[element['env']];
                                    });
                                }
                                projects.push({id : key[0]['id'],projet_code : value, projet_name : key[0]['project_name'], env:_.uniqBy(orderyEnv, 'env'), activemqsData:_.uniqBy(activemqsData, 'env'), linkToKibana:linkToKibana, coreconfigProperties:coreconfigProperties});
                            });
                            self.tableRecords = projects;
                            if(reloadTableData){
                                var tabelName = self.name.title;
                                if(_.isUndefined(tabelName)){
                                    tabelName = self.name.plural;
                                }
                                var msgContent = tabelName +' table ';
                                $mdToast.show(
                                    $mdToast.simple()
                                    .position($rootScope.mdToastPosition)
                                    .textContent(msgContent + 'data refreshed')
                                    .hideDelay(3000)
                                    .action('x')
                                );
                            }

                        });
                    }
                },function(response){
                    AppTableService.defaultErrorHandling(response, self);
                });
            }
        };

        // getFilterValues: Gets unique and non-empty values for the filter dropdown of column
        self.getFilterValues = AppTableService.getFilterValues;

        self.resetFilter = AppTableService.resetFilter;

        self.clearFilter = AppTableService.clearFilter;

        self.linkToKibana = function(project_name, envKibana){
            var linkTokibana = '';
			
			var dashboardID = "";
			var indexId="";
			if (envKibana === 'DEV')
			  {
				dashboardID = "13976330-11a3-11e8-bed9-e53afa493bd5";
			    indexId="AWFRfSnsVsJkw7Un4Vsv";
			  }
			if (envKibana === 'PROD' || envKibana === 'QA')
			  {
				dashboardID = "13976330-11a3-11e8-bed9-e53afa493bd5";
			    indexId="applog-*";
			  }
            linkTokibana +="/app/kibana#/dashboard/"+dashboardID ;
			//_g
			linkTokibana +="?_g=(filters:!(";
			linkTokibana +="('$state':(store:globalState),meta:(alias:!n,disabled:!f,index:'"+indexId+"',key:project,negate:!f,type:phrase,value:"+project_name+"),query:(match:(project:(query:"+project_name+",type:phrase))))";
			linkTokibana +=",";
			linkTokibana +="('$state':(store:globalState),meta:(alias:!n,disabled:!f,index:'"+indexId+"',key:environment,negate:!f,type:phrase,value:"+envKibana+"),query:(match:(environment:(query:"+envKibana+",type:phrase))))";
			linkTokibana +="),refreshInterval:(display:Off,pause:!f,value:0),time:(from:now-24h,mode:quick,to:now))";
			//_a
			linkTokibana +="&_a=(filters:!(),query:(query_string:(analyze_wildcard:!t,query:'*')),viewMode:view)";

            return linkTokibana;
        }

        // Table toolbar buttons
        self.reloadTableData = function(){
            self.$onInit(true);
        };

        self.coreconfigProperties = function(event, row, env){
            if(!_.isEmpty(row) && !_.isEmpty(env)){
                event.stopPropagation(); // in case autoselect is enabled
                var projectName  = row.projet_name;
                var env  = env;
                $window.open($rootScope.baseServerApiUrl + 'gitlab/configuration.properties?projectName=' + projectName, '_blank');
            }
        }

        // Row actions
        self.selectRow = function(row) {
            self.jobList = [];
            var projectName = row.projet_name;
            if(self.loadData === 0){
                //self.name.title = 'Job List for Project, ' + projectName;
                self.jobListPromise = Restangular.one('talend/job').get();
                self.jobListPromise.then(function (response) {
                    var response = JSON.parse(response);
                    self.jobList = _.filter(response.result, {projectName: projectName});
                    self.jobListOneTime = response.result;
                    self.loadData ++;
                }, function(response) {
                    // Error
                    AppTableService.defaultErrorHandling(response);
                });
            }else{
                self.jobList = _.filter(self.jobListOneTime, {projectName: projectName});
            }
        };

        self.displayProjectConfiguration = function (event, row) {
          //$state.go('app.configuration', { project_code: row.projet_code });
          var url = $state.go('app.configuration', { id: row.id });
         // $window.open(url,'_blank');
        };

    }
]
});
