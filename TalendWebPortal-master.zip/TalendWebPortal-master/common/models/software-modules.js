'use strict';

module.exports = function(Softwaremodules) {

};
