module.exports = function(User) {

    User.login = function(profile) {
        console.log(profile);
    }
};
