'use strict';

module.exports = function(Rolepermissions) {

};
