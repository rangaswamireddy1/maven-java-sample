const configuration = require('./../../server/configuration.module');
const permission_configuration = require('./../../server/api/permission/permissions.json').TalendConfigurationApi;
const groupExpression = new RegExp(configuration.regExLdapGroups);

const applyFilterToExistingQuery = (existingFilter, newFilter) => {
	for (var key in existingFilter)
	{
		if (key === 'where')
		{
			existingFilter[key] = {
				and:
				[
					existingFilter[key],
					newFilter
				]
			};
		}
		else if (typeof existingFilter[key] === 'object')
		{
			existingFilter[key] = applyFilterToExistingQuery(existingFilter[key], newFilter);
		}
	}
	return existingFilter;
};

const applyProjectPermissionsToProjectFilter = (projectFilter, projectPermissions) => {
	projectPermissions.forEach((projectPermission) => {
			var regexp = '^\\s*'+projectPermission.project_code+'\\s*$';
			projectFilter.or.push({
				project_code:  {regexp: regexp}
		});
	});
	return projectFilter;
};


const applyProjectGroupFilterToQuery = (existingFilter, projectPermissions) => {
	var projectFilter = {or:[]};
	if (!existingFilter){
		existingFilter = {where:{}};
	}
	projectFilter = applyProjectPermissionsToProjectFilter(projectFilter, projectPermissions);
	return applyFilterToExistingQuery(existingFilter, projectFilter);
};

module.exports = {
	applyFilterToExistingQuery,
	applyProjectGroupFilterToQuery,
	groupExpression
};
