'use strict';

module.exports = function(secondaryReference) {

};
