'use strict';


var tbutton = angular.module('tbutton', []);
tbutton.component('tbutton', {
    templateUrl: 'js/tbutton/tbutton.template.html',
    controller: ['Restangular', '$state', '$mdDialog', '$rootScope', 'AuthService', 'AppTableService', '$stateParams', '_', '$location', 'RestService', '$window',
    function LoginFormController(Restangular, $state, $mdDialog, $rootScope, AuthService, AppTableService, $stateParams, _, $location, RestService, $window) {
        var self = this;

        self.exec =function(row, env)
        {
            var host = self.test1.form.host;
            var url = self.test1.form.url1;
            var port = self.test1.form.port1;
            var options = self.test1.form.option;
            var command1 ='ping'
            //var SSH = require('simple-ssh');

            var promise = Restangular.one('exessh/rssh/run?host='+host+'&url='+url+'&port='+port+'&command1='+command1+'&options='+options).customPOST();
            promise.then(function (response) {
                console.log(response);
                $mdDialog.show({
                    controller: function($scope, $mdDialog, data) {
                      $scope.passedAsLocals = response;
                      $scope.close = function(){
                        $mdDialog.hide();
                      }  
                    },
                    locals:{"data":"This value comes from outside dialog box using locals option"},
                    templateUrl: 'js/tbutton/dialog1.tmpl.html',
                    //targetEvent: event
                  });
              });
        }

        self.exec1 =function(row, env)
        {
            var host = self.test1.form.host;
            var url = self.test1.form.url1;
            var port = self.test1.form.port1;
            var command1='telnet'
            //var SSH = require('simple-ssh');

            var promise = Restangular.one('exessh/rssh/run?host='+host+'&url='+url+'&port='+port+'&command1='+command1).customPOST();
            promise.then(function (response) {
                console.log(response);
                $mdDialog.show({
                    controller: function($scope, $mdDialog, data) {
                      $scope.passedAsLocals = response;
                      $scope.close = function(){
                        $mdDialog.hide();
                      }  
                    },
                    locals:{"data":"This value comes from outside dialog box using locals option"},
                    templateUrl: 'js/tbutton/dialog1.tmpl.html',
                    //targetEvent: event
                  });
              });
        }

        self.exec2 =function(row, env)
        {
            var host = self.test1.form.host;
            var url = self.test1.form.url1;
            var port = self.test1.form.port1;
            var command1='dig'
            //var SSH = require('simple-ssh');

            var promise = Restangular.one('exessh/rssh/run?host='+host+'&url='+url+'&port='+port+'&command1='+command1).customPOST();
            promise.then(function (response) {
                console.log(response);
                $mdDialog.show({
                    controller: function($scope, $mdDialog, data) {
                      $scope.passedAsLocals = response;
                      $scope.close = function(){
                        $mdDialog.hide();
                      }  
                    },
                    locals:{"data":"This value comes from outside dialog box using locals option"},
                    templateUrl: 'js/tbutton/dialog1.tmpl.html',
                    //targetEvent: event
                  });
              });
        }


        self.exec3 =function(row, env)
        {
            var host = self.test1.form.host;
            var url = self.test1.form.url1;
            var port = self.test1.form.port1;
            var command1='netstat'
            //var SSH = require('simple-ssh');

            var promise = Restangular.one('exessh/rssh/run?host='+host+'&url='+url+'&port='+port+'&command1='+command1).customPOST();
            promise.then(function (response) {
                console.log(response);
                $mdDialog.show({
                    controller: function($scope, $mdDialog, data) {
                      $scope.passedAsLocals = response;
                      $scope.close = function(){
                        $mdDialog.hide();
                      }  
                    },
                    locals:{"data":"This value comes from outside dialog box using locals option"},
                    templateUrl: 'js/tbutton/dialog1.tmpl.html',
                    //targetEvent: event
                  });
              });
        }

        self.exec4 =function(row, env)
        {
            var host = self.test1.form.host;
            var url = self.test1.form.url1;
            var port = self.test1.form.port1;
            var command1='nmap'
            //var SSH = require('simple-ssh');

            var promise = Restangular.one('exessh/rssh/run?host='+host+'&url='+url+'&port='+port+'&command1='+command1).customPOST();
            promise.then(function (response) {
                console.log(response);
                $mdDialog.show({
                    controller: function($scope, $mdDialog, data) {
                      $scope.passedAsLocals = response;
                      $scope.close = function(){
                        $mdDialog.hide();
                      }  
                    },
                    locals:{"data":"This value comes from outside dialog box using locals option"},
                    templateUrl: 'js/tbutton/dialog1.tmpl.html',
                    //targetEvent: event
                  });
              });

              
        
    }

    self.exec5 =function(row, env)
    {
        var host = self.test1.form.host;
        var url = self.test1.form.url1;
        var port = self.test1.form.port1;
        var command1='traceroute'
        //var SSH = require('simple-ssh');

        var promise = Restangular.one('exessh/rssh/run?host='+host+'&url='+url+'&port='+port+'&command1='+command1).customPOST();
        promise.then(function (response) {
            console.log(response);
            $mdDialog.show({
                controller: function($scope, $mdDialog, data) {
                  $scope.passedAsLocals = response;
                  $scope.close = function(){
                    $mdDialog.hide();
                  }  
                },
                locals:{"data":"This value comes from outside dialog box using locals option"},
                templateUrl: 'js/tbutton/dialog1.tmpl.html',
                //targetEvent: event
              });
          });
    }


    self.exec6 =function(row, env)
    {
        var host = self.test1.form.host;
        var url = self.test1.form.url1;
        var port = self.test1.form.port1;
        var command1='nping'
        //var SSH = require('simple-ssh');

        var promise = Restangular.one('exessh/rssh/run?host='+host+'&url='+url+'&port='+port+'&command1='+command1).customPOST();
        promise.then(function (response) {
            console.log(response);
            $mdDialog.show({
                controller: function($scope, $mdDialog, data) {
                  $scope.passedAsLocals = response;
                  $scope.close = function(){
                    $mdDialog.hide();
                  }  
                },
                locals:{"data":"This value comes from outside dialog box using locals option"},
                templateUrl: 'js/tbutton/dialog1.tmpl.html',
                //targetEvent: event
              });
          });
    }
        
        
    }
]});
