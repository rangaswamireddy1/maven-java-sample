
'use strict';

app.run(['$rootScope', '$location', 'Restangular', '$state', '$stateParams', '_', 'AuthService', 'LoopBackAuth',
    function ($rootScope, $location, Restangular, $state, $stateParams, _, AuthService, LoopBackAuth) {
        // Get the current host & port information from where the app is loaded
        var protocol = $location.protocol();
        var host = $location.host();
        var port = $location.port();

        $rootScope.appName = 'Testing';

        $rootScope.mdToastPosition = 'top right';

        $rootScope.titleStateParams = '';

        $rootScope.baseServerUrl = protocol + '://' + host + ':' + port;

        $rootScope.baseServerApiUrl = protocol + '://' + host + ':' + port + '/api/';

        // Rest api base url, to be used in the application
        Restangular.setBaseUrl($rootScope.baseServerApiUrl);

        // Login authentication check
        $rootScope.currentUser = null;
        $rootScope.userFullyValidated = null;
        $rootScope.employee = null;

        // Top Menu
        $rootScope.headerNavMenuItems = [];

        $rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams) {
          // redirect to login page if not logged in
          if (toState.authenticate && !AuthService.isAuthenticated()) {
            event.preventDefault(); //prevent current page from loading
            // console.log('No Auth Redirect to login');
            $state.go('app.login', {
              errorMessage: 'Please login to continue',
              loginRedirect: toState.name
            });
          } else {
            // console.log('State Change');
            if(fromState.url !== '^') {
              $rootScope.validateState(event, toState);
            }
          }
        });



        $rootScope.$state = $state;
        $rootScope.$stateParams = $stateParams;

        $rootScope.validateState = function(event, toState) {
          if (toState.name !== 'app.login' && !$rootScope.user)
          {
              $state.go('app.login');
          }

            // if(_.isNull($rootScope.employee)){
            //     $state.go('app.login');
            // }else{
            //     // console.log(toState);
            //     var ignoreStates = ['forbidden', 'app.login', 'app.dashboard'];
            //     // console.log(toState.name);
            //     if(ignoreStates.indexOf(toState.name) < 0) {
            //
            //         var statePermissionName = 'MENU_' + toState.name.replace('app.', '')
            //             .replace(/-/g, '_').toUpperCase();
            //
            //         if(toState.authenticate) {
            //             var statePermission = $rootScope.getPermission(statePermissionName);
            //             // console.log(statePermissionName);
            //             // console.log(statePermission.READ);
            //             // console.log(toState.name);
            //
            //             if(!statePermission.read) {
            //                 if(event) {
            //                     event.preventDefault();
            //                 }
            //                 $state.go('forbidden');
            //             }
            //         }
            //             // return true;
            //     }
            // }
        };

        $rootScope.getPermission = function (permission, isStrict) {
            if (_.isUndefined(isStrict)) {
                isStrict = false;
            }

            var employee = $rootScope.employee;
            var permissionSplit = permission.split('_');
            var permissionArea = permissionSplit[0];
            var permissionDepth = permission.split('_').slice(1);

            var selectedPermission = {
                read: false,
                create: false,
                update: false,
                delete: false
            };

            var depthIterated, selectedPermissionFound  = {};

            // Check for Role based permission
            if (employee && !_.isEmpty(employee.RolePermissions)) {
                if (isStrict) {
                    selectedPermissionFound = _.find(employee.RolePermissions, {Permission: {Title: permission}});
                }  else {
                    depthIterated = [];
                    _.each(permissionDepth, function (depth) {
                        depthIterated.push(depth);
                        var whereTitle = [permissionArea, depthIterated.join('_')].join('_');

                        _.each(employee.RolePermissions, function (rolePermission) {
                            if (rolePermission.Permission && (rolePermission.Permission.Title === whereTitle)) {
                                selectedPermissionFound = _.clone(rolePermission);
                            }
                        });
                    });
                }

                if(!_.isEmpty(selectedPermissionFound)) {
                    selectedPermission = _.clone(selectedPermissionFound);
                }
            }

            return selectedPermission;
        };

    }
]);
