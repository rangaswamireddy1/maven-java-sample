'use strict';


var taskList = angular.module('task-list', []);

taskList.component('taskList', {
    templateUrl: 'js/task-list/task-list.template.html',

    controller: ['Restangular', '$state', '$mdEditDialog', '$q', '$timeout', '$mdDialog', '_', 'AppTableService', '$mdToast', '$rootScope', 'moment', '$window',
    function TaskListController(Restangular, $state, $mdEditDialog, $q, $timeout, $mdDialog, _, AppTableService, $mdToast, $rootScope, moment, $window) {
        var self = this;

        self.tableName = 'runtimes';

        self.modelName = 'runtimes';

        self.name = {
            singular: 'DI-Job Overview',
            plural: 'DI-Job Overview',
            title: 'DI-Job Overview'
        };
        self.name.singularLcase = self.name.singular.toLowerCase();

        // Load rules via REST
        self.tableRecords = [];

        self.selected = [];

        self.jobListOneTime =[];

        self.selectedObjectField = [];

        self.fieldValidators = {};

        self.dependantDropdowns = {};

        self.loadData = 0;

        self.getUpdateDependantDropdown = AppTableService.getUpdateDependantDropdown;

        // Table options
         self.limitOptions =[10,20,50,100,500];

        self.options = {
            rowSelection: false,
            multiSelect: false,
            autoSelect: false,
            decapitate: false,
            largeEditDialog: false,
            boundaryLinks: false,
            limitSelect: true,
            pageSelect: true
        };

        // Search Filters
        self.filteredCollection = {};

        self.filterToggle = {
            state: false,
            tooltipText: {
                false: 'Show Filter',
                true: 'Hide Filter'
            }
        };

        self.selectedProject = 'Select Project...'

        self.projectNames = {"Select Project...":"Select Project..."};

        self.projectPermissions = [];

        self.setPermissions = function() {
          console.debug('task-list-permissions: Start setting permissions');
          console.debug('task-list-permissions: Authorized roles: ' + self.startStopAuthorizedRoles);
          console.debug('task-list-permissions: Project permissions: ' + JSON.stringify(self.projectPermissions));
          self.enabledEnvs = {};
          var currProject = self.projectPermissions.find(function (project) {
            return project.project_code == self.selectedProject;
          });
          console.debug('task-list-permissions: Current project identified: ' + JSON.stringify(currProject));
          if (currProject)
          {
            console.debug('task-list-permissions: Start filtering environments');
            currProject.environments.forEach(function (env){
              console.debug('task-list-permissions: process environment: ' + JSON.stringify(env));
              if (env.roles.some(function (role){
                console.debug('task-list-permissions: contains authorized role / enable environment: ' + (self.startStopAuthorizedRoles.indexOf(role) > 0));
                return self.startStopAuthorizedRoles.indexOf(role) > 0;
              }))
              {
                self.enabledEnvs[env.env] = true;
              }
            });
          }
        };

        self.getEnvEnabled = function(env){
          return self.enabledEnvs[env[0]];
        };

        $rootScope.$watch('userFullyValidated', function(newValue, oldValue) {
            if((oldValue !== newValue) && newValue) {
                self.$onInit();
            }
        });

        $rootScope.$on('vCountrySwitched', function(event, data) {
            self.$onInit();
        });

        self.loadTableRecords = AppTableService.loadTableRecords;

        self.deleteRow = AppTableService.deleteRow;

        // Pagination
        self.toggleLimitOptions = AppTableService.toggleLimitOptions;

        self.logOrder = AppTableService.logOrder;

        self.logPagination = AppTableService.logPagination;

        self.clearRowSelection = function() {
            self.selected = [];
            self.jobList = [];
            self.globalCodes = [];
        };

        self.query = {
            filter: {},
            order: false,
            orderDesc: false,
            limit: 10,
            page: 1,
            where: {
                //project_code: 'CFL'
            },
            contains: []
        };

        self.startStopAuthorizedRoles = [];
        var param = AppTableService.buildQuery(self.query, self);
        self.promise = Restangular.all('permission/apis?name=TalendApi&action=startStopTask').getList(param);
        self.promise.then(function(records) {
          self.startStopAuthorizedRoles = records;
        });

        self.$onInit = function(reloadTableData) {
            if($rootScope.userFullyValidated) {
                if(!reloadTableData) {
                    reloadTableData = false;
                }
                var param = AppTableService.buildQuery(self.query, self);
                self.promise = Restangular.all('permission').getList(param);
                self.promise.then(function(records) {
                    var projects = [];
                    _.forEach(records, function(key, value) {
                       // projects[key['project_code']] = key['project_code'];
                       projects.push({ data:key['project_code']});
                    });
                    console.log("projects",projects)
                    self.projectNames = projects;
                    console.log(self.projectNames)
                    self.projectPermissions = records;
                });
            }
        };

        // getFilterValues: Gets unique and non-empty values for the filter dropdown of column
        self.getFilterValues = AppTableService.getFilterValues;

        self.resetFilter = AppTableService.resetFilter;

        self.clearFilter = AppTableService.clearFilter;


        self.reloadTaskList = function () {
          self.setPermissions();
          self.tableRecords = [];
          self.promise = Restangular.one('talend/tasks?projectCodes=["EAOO"]').get();
          self.promise.then(function(response) {
            if(!_.isEmpty(response)){
              self.tableRecords = response;
            }
            $mdToast.show(
              $mdToast.simple()
              .position($rootScope.mdToastPosition)
              .textContent(msgContent + 'data refreshed')
              .hideDelay(3000)
              .action('x')
            );
          },function(response){
            AppTableService.defaultErrorHandling(response, self);
          });
        }
        // Table toolbar buttons
        self.reloadTableData = function(){
            self.reloadTaskList();
        };

        self.onProjectChange = function(){
          self.reloadTaskList();
        };


        self.executeTask =function(row, env)
        {
          var promise = Restangular.one('talend/task/run?taskId='+env.id+'&env='+env.env).customPOST();
          promise.then(function (response) {
                console.log(response);
                self.reloadTaskList();
                 $mdDialog.show(
                     $mdDialog.alert()
                     .title()
                     .ariaLabel(row.tasklabel +": started")
                     .textContent( row.tasklabel +": started")
                     .ok('Ok')
                 );
              }, function(response) {
                  // Error
                  AppTableService.defaultErrorHandling(response);
                  $mdDialog.show(
                      $mdDialog.alert()
                      .title()
                      .ariaLabel("Could not start task: "+row.tasklabel)
                      .textContent("Could not start task: "+row.tasklabel)
                      .ok('Ok')
                  );
              });
        }

        self.stopTask =function(row, env)
        {
          var promise = Restangular.one('talend/task/stop?taskId='+env.id+'&env='+env.env).customPOST();
          promise.then(function (response) {
                console.log(response);
                self.reloadTaskList();
                 $mdDialog.show(
                     $mdDialog.alert()
                     .title()
                     .ariaLabel(row.tasklabel +": stopped")
                     .textContent( row.tasklabel +": stopped")
                     .ok('Ok')
                 );
              }, function(response) {
                  // Error
                  AppTableService.defaultErrorHandling(response);
              });
        }

    }
]
});
