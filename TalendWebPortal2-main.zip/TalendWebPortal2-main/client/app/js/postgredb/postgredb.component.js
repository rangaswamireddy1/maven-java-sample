'use strict';

var test = angular.module('postgredb', []);
test.component('postgredb', {
    templateUrl: 'js/postgredb/postgredb.template.html',
    controller: ['Restangular', '$state', '$mdDialog', '$rootScope', 'AuthService', 'AppTableService', '$stateParams', '_', '$location', 'RestService',
    function LoginFormController(Restangular, $state, $mdDialog, $rootScope, AuthService, AppTableService, $stateParams, _, $location, RestService) {
        var self = this;

        self.projectCode = 'EAOO';
        var taskD;

        self.executeTask =function(row, env)
        {
            console.log(env);
          var ctxvalues = new Array();
          ctxvalues = [self.pgdb.form.database, self.pgdb.form.server, self.pgdb.form.schema, self.pgdb.form.port, self.pgdb.form.usern, self.pgdb.form.passwd,  self.pgdb.form.jdbcs];
          console.log(ctxvalues)
          var promise = Restangular.one('talend/task/pgdbTaskIdbyName?taskId=100000000000000000&env='+env).customPOST();
          promise.then(function (response) {
                console.log(response);
                taskD = response.taskId;
                var promise = Restangular.one('talend/task/pgdbrun?taskId='+taskD+'&env='+env+'&client='+ctxvalues).customPOST();
                promise.then(function (response) {
                console.log(response);
                var ExecId = response.execRequestId;
                console.log(ExecId);
                
                /*setTimeout(function() {
                    console.log('This printed after about 40 second');
                 
                var promise = Restangular.one('talend/esb/start?esbId='+taskD+'&env='+env).customPOST();
                promise.then(function (response) {
                console.log(response);
                console.log(response.result)
                $mdDialog.show(
                     $mdDialog.alert()
                     .title()
                     .ariaLabel(": started")
                     .textContent(response.result)
                     .ok('Ok')
                 );
              }) }, 40000); */
                    //self.reloadTaskList();
                 $mdDialog.show(
                     $mdDialog.alert()
                     .title()
                     .ariaLabel(": started")
                     .textContent(response.execBasicStatus)
                     .ok('Ok')
                 );
              })
              }, function(response) {
                  // Error
                  AppTableService.defaultErrorHandling(response);
                  $mdDialog.show(
                      $mdDialog.alert()
                      .title()
                      .ariaLabel("Could not start task: "+row.tasklabel)
                      .textContent("Could not start task: "+row.tasklabel)
                      .ok('Ok')
                  );
              });
          //console.log(c)
          /*, function(response) {
                  // Error
                  AppTableService.defaultErrorHandling(response);
                  $mdDialog.show(
                      $mdDialog.alert()
                      .title()
                      .ariaLabel("Could not start task: "+row.tasklabel)
                      .textContent("Could not start task: "+row.tasklabel)
                      .ok('Ok')
                  );
              });*/
        }
 } ]})
