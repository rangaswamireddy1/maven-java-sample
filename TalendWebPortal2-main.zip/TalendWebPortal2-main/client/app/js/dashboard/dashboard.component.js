'use strict';

var dashboard = angular.module('dashboard', []);

dashboard.component('dashboard', {
    templateUrl: 'js/dashboard/dashboard.template.html',
    controller: ['Restangular', '$state', '$mdDialog', '$rootScope', 'AppTableService', '$stateParams', '_', '$location',
        function LoginFormController(Restangular, $state, $mdDialog, $rootScope, AppTableService, $stateParams, _, $location) {
            var self = this;

            self.appName = $rootScope.appName;
            var port = $location.port();
            self.buildName = (port === 8682) ? ' - QA' : '';

            self.$onInit = function () {
            };
        }
    ]
});
