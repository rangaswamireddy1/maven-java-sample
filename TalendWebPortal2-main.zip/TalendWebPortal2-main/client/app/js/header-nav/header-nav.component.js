'use strict';

var headerNav = angular.module('headerNav', []);

headerNav.component('headerNav', {
    templateUrl: 'js/header-nav/header-nav.template.html',
    controller: ['$state', '$rootScope', 'Restangular', 'AppDropDownsService', '_', '$location', 'AppTableService', '$mdToast', 'AuthService',
        function HeaderNavController($state, $rootScope, Restangular, AppDropDownsService, _, $location, AppTableService, $mdToast, AuthService) {
            var self = this;

            self.appName = $rootScope.appName;

            var port = $location.port();
            self.buildName = ($rootScope.environment === 'production') ? '' : ' - ' + $rootScope.environment;

            self.go = $state.go;
            //self.version = $rootScope.version;

            self.currentUser = $rootScope.currentUser;

            $rootScope.$watch('userFullyValidated', function(newValue, oldValue) {
              if((oldValue !== newValue) && newValue) {
                self.currentUser = $rootScope.currentUser;
                self.loadMenu();
              }
            });

            // Listen to the $emit sent from the Menu component
            $rootScope.$on('menuDataUpdated', function (event) {
                self.loadMenu();
            });

            self.$onInit = function() {
              if($rootScope.userFullyValidated) {

                // Load only if the menuLists is empty
                if(_.isEmpty(self.menuLists)) {
                  self.loadMenu();
                }
              }
            };

            self.logout = function() {
              AuthService.logout();
              $state.go('app.login');
            };

            self.getLink = function (s) {
              return s.replace(
                /\.?([A-Z]+)/g,
                function (x, y) {
                  return '-' + y.toLowerCase();
                }
              ).replace(/^-/, '');
            };

            self.loadDependantSubMenus = function () {
                self.loadMenu();
            };

            self.sapgo =function(){
              $state.go('app.test');
            }

            self.netgo =function(){
              $state.go('app.tbutton');
            }

            self.pggo =function(){
              $state.go('app.postgredb');
            }

            self.mssqlgo =function(){
              $state.go('app.mssqldb');
            }

            self.oraclego =function(){
              $state.go('app.oracledb');
            }

            self.loadMenu = function () {
                var queryParams = {
                    where: {
                         menu_parent_id: null,
                         is_active: true
                    },
                    contains: ['children']
                };
                var params = AppTableService.buildQuery(queryParams, {});

                Restangular.all('menus').getList(params).then(function (records) {
                    var menuLists = records.plain();
                    _.each(menuLists, function(menu, index) {
                        menu.menu_link = 'app.' + menu.menu_link;

                        menu.children = _.sortBy(menu.children, 'menu_order');

                        _.each(menu.children, function(child, childIndex) {
                            if(child.menu_permission_name) {
                                child.permission = $rootScope.getPermission(child.menu_permission_name);
                            }
                            child.menu_link = 'app.' + child.menu_link;
                        });

                        menu.permission = $rootScope.getPermission(menu.menu_permission_name);
                    });

                    $rootScope.headerNavMenuItems = menuLists;
                    self.menuLists = menuLists;
                }, function(response) {
                    AppTableService.defaultErrorHandling(response)
                });
            }
        }
    ]
});
