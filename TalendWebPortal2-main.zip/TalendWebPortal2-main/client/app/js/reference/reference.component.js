'use strict';

var reference = angular.module('reference', []);

// reference.filter('maskSecrets', function() {
//   return function(text) {
//     console.log(text)
//     if (!text)
//     {
//       return '';
//     }
//     return text.match(/ENC\(.+\)/i) ? '********' : text;
//   };
// })

reference.component('reference', {
    templateUrl: 'js/reference/reference.template.html',
    controller: ['Restangular', '$state', '$mdEditDialog', '$q', '$timeout', '$mdDialog', '_', 'AppTableService', '$mdToast', '$rootScope', 'moment', '$stateParams', '$window', 'RestService',
    function ConfigurationsController(Restangular, $state, $mdEditDialog, $q, $timeout, $mdDialog, _, AppTableService, $mdToast, $rootScope, moment, $stateParams, $window, RestService) {
        var self = this;
        self.tableName = 'secondaryReference';

        self.modelName = 'secondaryReference';

        self.name = {
            singular: 'Project Reference',
            plural: 'Project References',
            title: 'Project Reference'
        };
        self.name.singularLcase = self.name.singular.toLowerCase();

        // Load rules via REST
        self.tableRecords = [];

        self.selected = [];

        self.jobListOneTime =[];

        self.selectedObjectField = [];

        self.fieldValidators = {};

        self.predefinedDropdowns = {
            EnvType: {
                DEV: "D1",
                QA: "Q2",
                PROD: "P2"
            },
            envDisplayRank:{
                D1 : 1,
                E1 : 2,
                Q2 : 3,
                I1 : 4,
                P2 : 5
            }
        };

        self.dependantDropdowns = {};

        self.loadData = 0;

        self.getUpdateDependantDropdown = AppTableService.getUpdateDependantDropdown;

        // Table options
         self.limitOptions =[5,10,20,50];

        self.options = {
            rowSelection: true,
            multiSelect: false,
            autoSelect: false,
            decapitate: false,
            largeEditDialog: false,
            boundaryLinks: false,
            limitSelect: true,
            pageSelect: true
        };

        // Search Filters
        self.filteredCollection = {};

        self.filterToggle = {
            state: false,
            tooltipText: {
                false: 'Show Filter',
                true: 'Hide Filter'
            }
        };
        self.projectId = parseInt($stateParams.project_id);
        //  console.log("id", self.projectId);
        var ID = self.projectId;
        self.query = {
            filter: {},
            order: false,
            orderDesc: false,
            limit: 10,
            page: 1,
            where: {
                project_id: ID
            },
            contains: [
              {
                relation: 'activemqs'
              },
              {
                relation: 'runtimes'
              }
            ]
        };

        $rootScope.$watch('userFullyValidated', function(newValue, oldValue) {
            if((oldValue !== newValue) && newValue) {
                self.$onInit();
            }
        });
        //console.log('id', $stateParams.id);
        self.loadTableRecords = AppTableService.loadTableRecords;

        self.deleteRow = AppTableService.deleteRow;

        // Pagination
        self.toggleLimitOptions = AppTableService.toggleLimitOptions;

        self.logOrder = AppTableService.logOrder;

        self.logPagination = AppTableService.logPagination;

        self.clearRowSelection = function() {
            self.selected = [];
            self.jobList = [];
            self.globalCodes = [];
        };
        self.$onInit = function(reloadTableData) {
                if($rootScope.userFullyValidated) {
                    if(!reloadTableData) {
                        reloadTableData = false;
                    }
                        var param = AppTableService.buildQuery(self.query, self);
                        //console.log("param", param);
                        console.log('query', self.query);
                        self.promise = Restangular.all('secondaryReference').getList(param);
                        self.promise.then(function(records) {
                            //console.log(records);
                            var secondaryRefer = [];
                            _.forEach(records, function(key, value) {

                                //activemqs
                                var activemqs = key['activemqs'];
                                if(!_.isEmpty(activemqs)){
                                    var activemqsData =  _.sortBy(activemqs, function(element){
                                        var rank = self.predefinedDropdowns.envDisplayRank;
                                        return rank[element['env']];
                                    });
                                }

                                //runtimes
                                var runtimes = key['runtimes'];
                                if (!_.isEmpty(runtimes))
                                {
                                  var runtimeData = _.sortBy(runtimes, function (element) {
                                    var rank = self.predefinedDropdowns.envDisplayRank;
                                    return rank[element['env']];
                                  });
                                }

                                // var linkToKibana = [];
                                // var env = self.predefinedDropdowns.EnvType;
                                // _.forEach(env, function(obj, env) {
                                //     if(env === 'PROD' || env === 'QA'){
                                //         linkToKibana.push({
                                //           env : obj,
                                //           link : linkToKibanaProd.url + self.linkToKibana(key['project_name'],
                                //           env)});
                                //     }else{
                                //         linkToKibana.push({
                                //           env : obj,
                                //           link : linkToKibanaDev.url + self.linkToKibana(key['project_name'],
                                //           env)});
                                //     }
                                // });

                                // var coreconfigProperties = [];
                                // _.forEach(env, function(obj, env) {
                                //   if(env === 'DEV'){
                                //     coreconfigProperties.push({env : env});
                                //   }
                                // });

                                secondaryRefer.push({
                                  project_id :  key['project_id'],
                                  project_code: key['project_code'],
                                  project_name: key['project_name'],
                                  runtimes: _.uniqBy(runtimeData, 'env'),
                                  activemqsData: _.uniqBy(activemqsData, 'env'),
                                  });
                            });
                            self.tableRecords = secondaryRefer;
                            if(reloadTableData){
                                var tabelName = self.name.title;
                                if(_.isUndefined(tabelName)){
                                    tabelName = self.name.plural;
                                }
                                var msgContent = tabelName +' table ';
                                $mdToast.show(
                                    $mdToast.simple()
                                    .position($rootScope.mdToastPosition)
                                    .textContent(msgContent + 'data refreshed')
                                    .hideDelay(3000)
                                    .action('x')
                                );
                            }

                        });
                      }
                    },function(response){
                      console.log('error', response);
                        AppTableService.defaultErrorHandling(response, self);
            }

        // getFilterValues: Gets unique and non-empty values for the filter dropdown of column
        self.getFilterValues = AppTableService.getFilterValues;

        self.resetFilter = AppTableService.resetFilter;

        self.clearFilter = AppTableService.clearFilter;

        // Table toolbar buttons
        self.reloadTableData = function(){
            self.$onInit(true);
        };
    }
]
});
