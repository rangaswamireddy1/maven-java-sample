'use strict';

var configuration = angular.module('configuration', []);

configuration.filter('maskSecrets', function() {
  return function(text) {
    if (!text)
    {
      return '';
    }
    return text.match(/ENC\(.+\)/i) ? '********' : text;
  };
})

configuration.component('configuration', {
    templateUrl: 'js/configuration/configuration.template.html',
    controller: ['Restangular', '$state', '$mdEditDialog', '$q', '$timeout', '$mdDialog', '_', 'AppTableService', '$mdToast', '$rootScope', 'moment', '$stateParams', '$window', 'RestService',
    function ConfigurationsController(Restangular, $state, $mdEditDialog, $q, $timeout, $mdDialog, _, AppTableService, $mdToast, $rootScope, moment, $stateParams, $window, RestService) {
        var self = this;

        self.projectCode = '';

        self.tableName = '';

        self.modelName = '';

        self.name = {}

        self.name.singularLcase = '';

        self.selectedEnv = 'Select Env...';

        self.selectedDb = 'Select Db...';

        self.promoteDb = 'CPP2DE';

        self.promoteEnv = 'QA';

        self.buttonDisable = false;

        // Load rules via REST
        self.tableRecords = [];

        self.selected = [];

        self.fieldValidators = {};

        self.dependantDropdowns = {};

        self.row = {};

        self.projectDetail = {};

        self.getUpdateDependantDropdown = AppTableService.getUpdateDependantDropdown;

        // Table options
        self.limitOptions = [10, 20, 50];

        self.options = {
            rowSelection: false,
            multiSelect: false,
            autoSelect: false,
            decapitate: false,
            largeEditDialog: false,
            boundaryLinks: false,
            limitSelect: true,
            pageSelect: true
        };

        // Search Filters
        self.filteredCollection = {};

        self.filterToggle = {
            state: false,
            tooltipText: {
                false: 'Show Filter',
                true: 'Hide Filter'
            }
        };

        self.query = {
            filter: {},
            order: 'variable_name',
            orderDesc: false,
            limit: 15,
            page: 1,
            where: {}
        };

        self.dbQueryParams =  {
            filter: {},
            where:{
                is_active: true,
                isEnvDefault: false
            }
        };
        console.log(self.query.filter.env);

        self.dbOptions = {"Select Db..." : "Select Db..."};
            var dbParam = AppTableService.buildQuery(self.dbQueryParams, self);
            self.promise = Restangular.all('projectDBCTX').getList(dbParam);
                self.promise.then(function(records) {
                    var Instances = [];
                        _.forEach(records, function(key, value){
                            Instances.push({
                            instanceName: key['instanceName']
                            });
                        })
                        self.dbOptions = Instances;
                });

        self.editAuthorizedRoles = [];
        var param = AppTableService.buildQuery(self.query, self);
        self.promise = RestService.queryOne('permission/apis?name=TalendConfigurationApi&action=write');
        self.promise.then(function(records) {
          self.editAuthorizedRoles = records;
        });

        self.promoteAuthorizedRoles = [];
        var param = AppTableService.buildQuery(self.query, self);
        self.promise = RestService.queryOne('permission/apis?name=TalendConfigurationApi&action=promote');
        self.promise.then(function(records) {
          self.promoteAuthorizedRoles = records;
        });

        self.deployBootstrapperConfigAuthorizedRoles = [];
        var param = AppTableService.buildQuery(self.query, self);
        self.promise = RestService.queryOne('permission/apis?name=TalendConfigurationApi&action=deployBootstrapperConfig');
        self.promise.then(function(records) {
          self.deployBootstrapperConfigAuthorizedRoles = records;
        });

        self.disablePromoteTo = true;
        self.disableDeployBootstrapper = true;
        self.disableEdit = true;

        $rootScope.$watch('userFullyValidated', function(newValue, oldValue) {
            if((oldValue !== newValue) && newValue) {
                self.$onInit();
            }
        });

        $rootScope.$on('vCountrySwitched', function(event, data) {
          self.$onInit();
        });

        self.loadTableRecords = AppTableService.loadTableRecords;

        self.setPermissions = function() {
          self.disablePromoteTo = true;
          self.disableDeployBootstrapper = true;
          self.disableEdit = true;

          var currEnv = self.projectDetail.environments.find(function (env) {
            return env.env === self.selectedEnv[0];
          });
          self.disableEdit = !currEnv.roles.some(function (role)
          {
            return self.editAuthorizedRoles.indexOf(role) >= 0;
          });
          if (self.promoteEnv)
          {
            var promoteToEnv = self.projectDetail.environments.find(function (env) {
              return env.env === self.promoteEnv[0];
            });
            if (promoteToEnv)
            {
              self.disablePromoteTo = !promoteToEnv.roles.some(function (role) {
                return self.promoteAuthorizedRoles.indexOf(role) >= 0;
              });

              self.disableDeployBootstrapper = !promoteToEnv.roles.some(function (role) {
              return self.deployBootstrapperConfigAuthorizedRoles.indexOf(role) >= 0;
              });
            }
          }
        };
        self.dbOnInits = function () {
            //console.log(self.selectedDb);
            if (!_.isUndefined($stateParams.project_code)){
                self.promise = RestService.queryOne('permission?projectCodes=["'+$stateParams.project_code+'"]');

                self.promise.then(function (record) {
                    self.projectDetail = _.first(record);
                    self.row.project_code =  self.projectDetail.project_code;
                    self.row.selectedDb = self.selectedDb;
                    //console.log("selectdb", self.row);
                    self.promise = RestService.postOne('internal/loopback/schema-model', self.row);
                    self.promise.then(function (response) {
                        self.projectCode = self.projectDetail.project_code;
                        self.tableName = _.toLower(self.projectCode + '_DEVS');
                        self.modelName = _.toLower(self.projectCode + '_DEVS');
                        self.name = {
                            singular: 'Configuration',
                            plural: 'Configuration for ' + self.projectCode,
                            title: 'Configuration for ' + self.projectCode,
                        };
                        self.name.singularLcase = self.name.singular.toLowerCase();

                        self.setPermissions();
                        self.loadTableRecords();
                        if(_.isEmpty(self.tableRecords)){
                            self.promise = false;
                        }
                    },function(response){
                        AppTableService.defaultErrorHandling(response);
                    });
                },function(record){
                    AppTableService.defaultErrorHandling(record);
                });
            }
        };
        self.EnvType = function(){
            var envOption;
            switch (self.selectedDb)
                {
                    case 'CPP2DE':
                         envOption = {
                            "DEV": "DEV",
                            "QA": "QA",
                            "PROD": "PROD"
                        };
                            break;
                    case 'CZI8DE':
                         envOption = {
                            "DEV": "DEV"
                        };
                            break;
                    case 'CZE8DE':
                        envOption = {
                            "DEV": "DEV"
                        };
                            break;
                    case 'CZQ8DE':
                         envOption = {
                            "QA": "QA"
                        };
                            break;
                    case 'CZP8DE':
                         envOption = {
                            "PROD": "PROD"
                        };
                            break;
                    case 'CZQ8DE-FLEX':
                         envOption = {
                            "DEV": "DEV",
                            "QA": "QA"
                        };
                            break;
                    case 'CZP8DE-FLEX':
                         envOption = {
                            "PROD": "PROD"
                        };
                            break;
                    case 'CZI8DE-FLEX2':
                         envOption = {
                            "DEV": "DEV"
                        };
                            break;
                    case 'CZQ8DE-FLEX2':
                         envOption = {
                            "QA": "QA"
                        };
                            break;
                    case 'CZP8DE-FLEX2':
                         envOption = {
                            "PROD": "PROD"
                        };
                            break;
                    default:
                            break;
            }
            //console.log(envOption);
            return envOption;
        }
    
    self.onDbChange = function(){
        self.dbOnInits();
        if(self.selectedDb!=undefined){
            self.selectedEnv = "Select..."
        }
        self.EnvType.envOption = self.EnvType();
        

        self.predefinedDropdowns = {
                EnvType: {
                    "DEV": "DEV",
                    "QA": "QA",
                    "PROD": "PROD"
                },
                FromEnvToEnv: {
                    "DEV": "QA",
                    "QA": "PROD"
                },
                PromoteEnv:{
                    "DEV": "QA",
                    "QA": "PROD"
                },
                Active:{
                    "Yes" : true,
                    "No" : false
                }
    
            };
        self.onEnvChange = function(){
            //console.log('selecteddb', self.selectedDb);
            self.tableName = _.toLower(self.projectCode + '_' + self.selectedEnv + 'S');
            self.modelName = _.toLower(self.projectCode + '_' + self.selectedEnv + 'S');
            self.tableRecords = [];
            self.query = {
                filter: {},
                order: 'variable_name',
                orderDesc: false,
                limit: 15,
                page: 1
            };
            self.promoteEnv = self.predefinedDropdowns.FromEnvToEnv[self.selectedEnv];
            if(self.selectedDb === 'CZI8DE' || self.selectedDb === 'CZE8DE'){
                self.promoteDb = 'CZQ8DE';
            }
            else if(self.selectedDb === 'CZQ8DE'){
                self.promoteDb = 'CZP8DE';
            }
            else if(self.selectedDb === 'CZQ8DE-FLEX' && self.selectedEnv === 'DEV'){
                self.promoteDb = 'CZQ8DE-FLEX';
            }
            else if(self.selectedDb === 'CZQ8DE-FLEX'){
                self.promoteDb = 'CZP8DE-FLEX';
            }
            else if(self.selectedDb === 'CZI8DE-FLEX2'){
                self.promoteDb = 'CZQ8DE-FLEX2';
            }
            else if(self.selectedDb === 'CZQ8DE-FLEX2' && this.projectCode == 'CDIP'){
                self.promoteDb = 'CZP8DE-FLEX';
            //    console.log(self.promoteDb);
            }
            else if(self.selectedDb === 'CZQ8DE-FLEX2'){
                self.promoteDb = 'CZP8DE-FLEX2';
            }
            self.setPermissions();
            self.reloadTableData();
        };
        self.promoteToJenkins = function(){
            self.buttonDisable = true;
            var data = {
                projectCode: self.projectCode,
                promotedEnv: self.predefinedDropdowns.PromoteEnv[self.selectedEnv],
                selectedDb: self.selectedDb,
                selectedEnv: self.selectedEnv,
                promoteDb: self.promoteDb
            };
            self.promise = RestService.postOne('jenkins/configuration/promote',data);
            self.promise.then(function(response) {
              console.log('success');
                self.buttonDisable = false;
                $mdToast.show(
                    $mdToast.simple()
                    .position('bottom left')
                    .textContent(self.projectDetail.project_code + ' Promote to ' + self.promoteEnv + ' successfully.')
                    .hideDelay(3000)
                    .action('x')
                );
            },
            function(response) {
              console.log('failure');
                self.buttonDisable = false;
                AppTableService.defaultErrorHandling(response, self);
            });
        };
    };
    
        self.$onInit = function () {
            if (!_.isUndefined($stateParams.project_code)){
                self.promise = RestService.queryOne('permission?projectCodes=["'+$stateParams.project_code+'"]');

                // self.promise.then(function (record) {
                //     self.projectDetail = _.first(record);
                //     self.row.project_code =  self.projectDetail.project_code;
                //     self.promise = RestService.postOne('internal/loopback/schema-model', self.row);

                //     self.promise.then(function (response) {
                //         self.projectCode = self.projectDetail.project_code;
                //         self.tableName = _.toLower(self.projectCode + '_DEVS');
                //         self.modelName = _.toLower(self.projectCode + '_DEVS');
                //         self.name = {
                //             singular: 'Configuration',
                //             plural: 'Configuration for ' + self.projectCode,
                //             title: 'Configuration for ' + self.projectCode,
                //         };
                //         self.name.singularLcase = self.name.singular.toLowerCase();

                //         self.setPermissions();
                //         self.loadTableRecords();
                //         if(_.isEmpty(self.tableRecords)){
                //             self.promise = false;
                //         }
                //     },function(response){
                //         AppTableService.defaultErrorHandling(response);
                //     });
                // },function(record){
                //     AppTableService.defaultErrorHandling(record);
                // });
            }
        };

        // getFilterValues: Gets unique and non-empty values for the filter dropdown of column
        self.getFilterValues = AppTableService.getFilterValues;

        self.resetFilter = AppTableService.resetFilter;

        self.clearFilter = AppTableService.clearFilter;

        // Table toolbar buttons
        self.reloadTableData = AppTableService.reloadTableData;

        self.clearRowSelection = function() {
            self.selected = [];
        };

        self.editWhereFilter = function(row, fieldName, whereFilter) {
            if(!_.isEmpty(row) && !_.isEmpty(fieldName)){
                whereFilter = {
                    where: {
                        env: row.env,
                        variable_name: row.variable_name,
                        scope: row.scope,
                        job_name: row.job_name
                    }
                };
            }
            return whereFilter;
        };

        self.editField = AppTableService.editField;

        self.statusUpdate = AppTableService.statusUpdate;

        // Row actions
        self.selectRow = function(row) {};

        self.deleteRow = function (event, row) {
            if (!_.isUndefined($stateParams.id)){
                $mdDialog.show(
                    $mdDialog.confirm()
                    .clickOutsideToClose(true)
                    .title('Delete ' + self.name.singularLcase + ' #'+ row.env)
                    .textContent('Are you sure you want to delete ' + self.name.singularLcase + ' #' + row.env)
                    .ariaLabel('Delete ' + self.name.singularLcase + ' #' + row.env)
                    .ok('Yes')
                    .cancel('No')
                    .targetEvent(event)
                ).then(function() {
                    var modelName = self.modelName;
                    var queryParams = {
                        where: {
                            env: row.env,
                            variable_name: row.variable_name,
                            scope: row.scope,
                            job_name: row.job_name
                        },
                        modelName: modelName.substring(0, modelName.length - 1)
                    };
                    self.promise = RestService.postOne('deleteConfiguration', queryParams);
                    self.promise.then(function() {

                        self.reloadTableData();
                        $mdToast.show(
                            $mdToast.simple()
                            .position('bottom left')
                            .textContent('Selected ' + self.name.singularLcase + ' records deleted')
                            .hideDelay(3000)
                            .action('x')
                        );
                    },
                    function(response) {
                        AppTableService.defaultErrorHandling(response, self);
                    });
                }, function () {
                    //
                });
            }
        };

        // Pagination
        self.toggleLimitOptions = AppTableService.toggleLimitOptions;

        self.logOrder = AppTableService.logOrder;

        self.logPagination = AppTableService.logPagination;

        // Add or edit row
        function addRowDialogController($mdDialog, RestService, $rootScope) {
            var addSelf = this;

            addSelf.name = addSelf.parent.name;

            addSelf.isAdd = _.isEmpty(addSelf.editRow);
            addSelf.row = {};
            addSelf.hide = function () {
                $mdDialog.hide();
            };

            addSelf.cancel = function () {
                $mdDialog.cancel();
            };

            addSelf.predefinedDropdowns = addSelf.parent.predefinedDropdowns;
            addSelf.predefinedDropdowns.EnvType = {
                    "*": "*",
                    "DEV": "DEV",
                    "QA": "QA",
                    "PROD": "PROD"
                };
            addSelf.queryParams = {};
            //addSelf.dbOptions=addSelf.parent.dbOptions;

            addSelf.$onInit = function () {
                // Form default values
                if (!addSelf.isAdd) {
                    var whereConditionData = addSelf.editRow;
                    addSelf.queryParams = {
                        where: {
                            env: whereConditionData.env,
                            variable_name: whereConditionData.variable_name,
                            scope: whereConditionData.scope,
                            job_name: whereConditionData.job_name
                        }
                    };

                    var params = AppTableService.buildQuery(addSelf.queryParams, {});
                    addSelf.promise = RestService.queryOne(self.modelName, params);
                    addSelf.promise.then(function (record) {
                        addSelf.row = _.first(record);
                        addSelf.row.encrypt = addSelf.row.variable_value.startsWith('ENC(') && addSelf.row.variable_value.endsWith(')');
                    });
                }
            };

            addSelf.$onInit();

            addSelf.validateCombinations = function() {
              addSelf.item.form.encrypt.$setValidity('environmentError', true);
              addSelf.item.form.encrypt.$setValidity('noValueError', true);
              if (addSelf.row.encrypt && !addSelf.row.variable_value)
              {
                addSelf.item.form.encrypt.$setValidity('noValueError', false);
              }
              else if (addSelf.row.encrypt && addSelf.row.env === '*')
              {
                addSelf.item.form.encrypt.$setValidity('environmentError', false);
              }
            };

            addSelf.saveRow = function () {
                if (addSelf.item.form.$valid) {
                    addSelf.item.form.$setSubmitted();
                    if (addSelf.row.encrypt)
                    {
                      addSelf.promise = RestService.postOne('/internal/encryptPassword',
                      {
                        "projectName":  self.projectDetail.project_name,
                        "environment": addSelf.row.env,
                        "plainText": addSelf.row.variable_value
                      });
                    }
                    else
                    {
                      addSelf.promise = new Promise(function(resolve, reject) {resolve();});
                    }

                    addSelf.promise.then(function (response) {
                      if (addSelf.row.encrypt)
                      {
                        addSelf.row.variable_value = 'ENC('+response+')';
                        console.log(response)
                      }
                      var message = '';
                      var mdToastMsg = addSelf.isAdd ? 'New ' + self.name.singular + ' ' + 'added' : self.name.singular + ' ' + ' updated';
                      if (addSelf.isAdd) {
                          addSelf.row.created = new Date();
                          addSelf.row.created_by = $rootScope.employee.cwid;
                          addSelf.promise = RestService.postAll(self.modelName,addSelf.row);
                          message = 'New ' + self.name.singular + ' added';
                      } else {
                          addSelf.row.modified = new Date();
                          addSelf.row.modified_by = $rootScope.employee.cwid;
                          addSelf.promise = RestService.postOne(self.modelName, addSelf.row, 'update', addSelf.queryParams, {});
                          message = 'data updated successfully';
                      }
                      addSelf.promise.then(function (response) {
                          $mdDialog.hide();

                          self.reloadTableData();
                          $mdToast.show(
                              $mdToast.simple()
                              .position($rootScope.mdToastPosition)
                              .textContent(message)
                              .hideDelay(3000)
                              .action('x')
                          );
                      }, function (response) {
                          AppTableService.defaultErrorHandling(response, addSelf);
                      });
                    }, function (response) {
                      if (response)
                      {
                        AppTableService.defaultErrorHandling(response, addSelf);
                      }
                    });

                }
            };
        }

        self.showAddRowDialog = function (opts) {
            opts = opts || {};

            $mdDialog.show({
                // controller: angular.noop,
                controller: addRowDialogController,
                controllerAs: '$ctrl',
                bindToController: true,
                locals: { parent: self, opts: opts },
                templateUrl: 'js/configuration/configuration.add.template.html',
                preserveScope: true,
                clickOutsideToClose: true,
                focusOnOpen: false
            });
        };

        self.showEditRowDialog = function (opts, row) {
            opts = opts || {};
            $mdDialog.show({
                // controller: angular.noop,
                controller: addRowDialogController,
                controllerAs: '$ctrl',
                bindToController: true,
                locals: { parent: self, opts: opts, editRow: row },
                templateUrl: 'js/configuration/configuration.add.template.html',
                preserveScope: true,
                clickOutsideToClose: true,
                focusOnOpen: false
            });
        };

        function effectiveConfiguration($mdDialog, RestService, $rootScope) {
            var addSelf = this;
            addSelf.name = {
                tableName: 'Effective configuration for ' + addSelf.parent.projectCode,
                title: 'Search Result'
            };
            addSelf.predefinedDropdowns = addSelf.parent.predefinedDropdowns;
            addSelf.instanceName = _.clone(addSelf.parent.dbOptions);

            addSelf.env = _.clone(addSelf.predefinedDropdowns.EnvType);

            addSelf.env['*'] = '*';

            addSelf.hide = function () {
                $mdDialog.hide();
            };

            addSelf.cancel = function () {
                $mdDialog.cancel();
            };

            addSelf.selected = addSelf.tableRecords = [];

            addSelf.row = {};

            addSelf.filterToggle = {
                state: false,
                tooltipText: {
                    false: 'Show Filter',
                    true: 'Hide Filter'
                }
            };

            addSelf.query = {
                filter: {},
                where: {},
                order: 'variable_name',
                limit: 5,
                page: 1
            };

            // Table options
            addSelf.limitOptions = [5, 10, 15];

            addSelf.options = {
                rowSelection: false,
                multiSelect: false,
                autoSelect: false,
                decapitate: false,
                largeEditDialog: false,
                boundaryLinks: false,
                limitSelect: true,
                pageSelect: true
            };

            addSelf.clearRowSelection = function (row) {
                addSelf.selected = [];
            };

            addSelf.clearFilter = AppTableService.clearFilter;

            addSelf.searchEffectiveConfiguration = function () {
                    addSelf.configObj = [];
                    addSelf.tempObj = {};
                    var queryParams =  {
                        where: {
                            env: addSelf.row.env,
                            scope: addSelf.row.scope,
                            job_name: addSelf.row.job_name,
                            active:true
                        }
                    };
                    //first query
                    var params = AppTableService.buildQuery(queryParams, {});
                    addSelf.promise = RestService.queryOne(addSelf.parent.modelName, params);
                    addSelf.promise.then(function(response) {
                        if(!_.isEmpty(response)){
                            var data = response.plain();
                            data = _.forEach(data, function(value) {
                                addSelf.tempObj[_.toString(value.variable_name)] = value.variable_value;
                            });
                            _.forEach(addSelf.tempObj, function(value, key) {
                                addSelf.configObj.push({variable_name:key, variable_value: value});
                            });
                            //second query
                           /* var secondQueryParams =  {
                                where: {
                                    env: addSelf.row.env,
                                    scope: "*",
                                    job_name: "*",
                                    active:true
                                }
                            };

                            var secondParams = AppTableService.buildQuery(secondQueryParams, {});
                            addSelf.promise = RestService.queryOne(addSelf.parent.modelName, secondParams);
                            addSelf.promise.then(function(response) {
                                //if(!_.isEmpty(response)){
                                var data = response.plain();
                                data = _.forEach(data, function(value) {
                                    addSelf.tempObj[_.toString(value.variable_name)] = value.variable_value;
                                });

                                //third query
                                var thirdQueryParams =  {
                                    where: {
                                        env: addSelf.row.env,
                                        scope: addSelf.row.scope,
                                        job_name: "*",
                                        active:true
                                    }
                                };

                                var thirdParams = AppTableService.buildQuery(thirdQueryParams, {});
                                addSelf.promise = RestService.queryOne(addSelf.parent.modelName, thirdParams);
                                addSelf.promise.then(function(response) {
                                    //if(!_.isEmpty(response)){
                                        var data = response.plain();
                                        data = _.forEach(data, function(value) {
                                            addSelf.tempObj[_.toString(value.variable_name)] = value.variable_value;
                                        });

                                        //fouth query
                                        var fourQueryParams =  {
                                            where: {
                                                env: addSelf.row.env,
                                                scope: addSelf.row.scope,
                                                job_name: addSelf.row.job_name,
                                                active:true
                                            }
                                        };
                                        var fourParams = AppTableService.buildQuery(fourQueryParams, {});
                                        addSelf.promise = RestService.queryOne(addSelf.parent.modelName, fourParams);
                                        addSelf.promise.then(function(response) {
                                            //if(!_.isEmpty(response)){
                                                var data = response.plain();
                                                data = _.forEach(data, function(value) {
                                                    addSelf.tempObj[_.toString(value.variable_name)] = value.variable_value;
                                                });
                                                _.forEach(addSelf.tempObj, function(value, key) {
                                                    addSelf.configObj.push({variable_name:key, variable_value: value});
                                                });
                                            //}
                                        },function(response){
                                            AppTableService.defaultErrorHandling(response, self);
                                        });
                                    //}
                                },function(response){
                                    AppTableService.defaultErrorHandling(response, self);
                                });
                            //}
                        },function(response){
                            AppTableService.defaultErrorHandling(response, self);
                        });
                    */}
                },function(response){
                    AppTableService.defaultErrorHandling(response, self);
                });
            }
        };

        self.showEffectiveConfigurationDialog = function (opts) {
            opts = opts || {};

            $mdDialog.show({
                // controller: angular.noop,
                controller: effectiveConfiguration,
                controllerAs: '$ctrl',
                bindToController: true,
                locals: { parent: self, opts: opts },
                templateUrl: 'js/configuration/effective-configuration.template.html',
                preserveScope: true,
                clickOutsideToClose: true,
                focusOnOpen: false
            });
        };

        function deployBootstrapperConfig($mdDialog, RestService, $rootScope) {
            var addSelf = this;

            addSelf.name = {
                tableName: 'Deploy Bootstrapper Config for ' + addSelf.parent.projectCode,
                title: 'Deploy Bootstrapper Config'
            };

            addSelf.row = {};

            addSelf.predefinedDropdowns = addSelf.parent.predefinedDropdowns;

            addSelf.environment = {
                D1 : 'D1',
                // D1 : 'D2',
                // Q1 : 'Q1',
                Q2 : 'Q2',
                // P1 : 'P1',
                P2 : 'P2',
                I5 : 'I5',
                Q5 : 'Q5',
                P5 : 'P5'
            };

            addSelf.hide = function () {
                $mdDialog.hide();
            };

            addSelf.cancel = function () {
                $mdDialog.cancel();
            };

            addSelf.advance = function(){
                var projectCode = addSelf.parent.projectCode
                var resulting = Restangular.one(`jenkins/advance?projectCode=${projectCode}`).get();
                resulting.then(function (response) {
                    console.log("response",response)
                    window.open(response,"_blank");
                });

            };

            addSelf.saveRow = function () {
                addSelf.item.form.$setSubmitted();
                if (addSelf.item.form.$valid && !_.isEmpty(addSelf.parent.projectCode) && !_.isEmpty(addSelf.parent.projectDetail.project_name)) {
                    addSelf.parent.buttonDisable = true;
                    var data = {
                        projectCode: addSelf.parent.projectCode,
                        projectName: addSelf.parent.projectDetail.project_name,
                        environment: addSelf.row.environment,
                        gitTag: addSelf.row.gitTag
                    };
                    self.promise = RestService.postOne('jenkins/configuration/core/deploy', data);
                    self.promise.then(function(response) {
                        addSelf.parent.buttonDisable = false;
                        $mdDialog.hide();
                        $mdToast.show(
                            $mdToast.simple()
                            .position('bottom left')
                            .textContent(addSelf.parent.projectDetail.project_code + ' Deployed Bootstrapper Config successfully.')
                            .hideDelay(3000)
                            .action('x')
                        );
                    },
                    function(response) {
                        addSelf.parent.buttonDisable = false;
                        AppTableService.defaultErrorHandling(response, self);
                    });
                }
            };
        }

        self.deployBootstrapperConfig = function (opts) {
            opts = opts || {};
            $mdDialog.show({
                // controller: angular.noop,
                controller: deployBootstrapperConfig,
                controllerAs: '$ctrl',
                bindToController: true,
                locals: { parent: self, opts: opts },
                templateUrl: 'js/configuration/deploy-bootstrapper-config.template.html',
                preserveScope: true,
                clickOutsideToClose: true,
                focusOnOpen: false
            });
        };
    }
]
});