'use strict';

httpErrors.component('error401', {
    templateUrl: 'js/http-errors/401/401.template.html',

    controller: ['Restangular', '$mdEditDialog', '$q', '$timeout', '$mdDialog', '_',
        function SimulationsController(Restangular, $mdEditDialog, $q, $timeout, $mdDialog, _) {
            var self = this;

        }
    ]
});
