'use strict';

var ldapGroups = angular.module('ldapGroups', []);

ldapGroups.component('ldapGroups', {
    templateUrl: 'js/ldap-groups/ldap-groups.template.html',

    controller: ['Restangular', '$mdEditDialog', '$q', '$timeout', '$mdDialog', '_', 'AppTableService', 'AppDropDownsService', '$rootScope', '$mdToast',
        function LdapGroupsController(Restangular, $mdEditDialog, $q, $timeout, $mdDialog, _, AppTableService, AppDropDownsService, $rootScope, $mdToast) {
            var self = this;

            // Loopback model for component
            self.tableName = 'LdapGroups';

            self.modelName = 'LdapGroups';

            self.primaryKey = 'id';

            self.displayField = 'name';

            self.name = {
                singular: 'ldap Group',
                plural: 'ldap Groups',
                title: 'Ldap Groups'
            };

            self.name.singularLcase = self.name.singular.toLowerCase();

            // Load rules via REST
            self.tableRecords = [];

            self.selected = [];

            self.selectedCriteria = [];

            self.fieldValidators = {
                'name': { 'required': true }
            };

            self.predefinedDropdowns = {};

            self.dependantDropdowns = {};

            self.getUpdateDependantDropdown = AppTableService.getUpdateDependantDropdown;

            // Table options
            self.limitOptions = [5, 10, 15];

            self.options = {
                rowSelection: false,
                multiSelect: false,
                autoSelect: false,
                decapitate: false,
                largeEditDialog: false,
                boundaryLinks: false,
                limitSelect: true,
                pageSelect: true
            };

            // Search Filters
            self.filteredCollection = {};

            self.filterToggle = {
                state: false,
                tooltipText: {
                    false: 'Show Filter',
                    true: 'Hide Filter'
                }
            };

            self.query = {
                filter: {},
                order: 'name',
                orderDesc: false,
                limit: 15,
                page: 1,
                where: {}
            };

            self.tableRecords = [];

            self.loadTableRecords = AppTableService.loadTableRecords;

            self.$onInit = function () {
                if ($rootScope.userFullyValidated) {
                    //var permissionName = 'SCREEN_' + self.name.title.toUpperCase().replace(/\s/g, '_');
                    //self.permission = $rootScope.getPermission(permissionName);
                    self.loadTableRecords();
                }
            };

            // onOpenGetFilterValues: Gets unique and non-empty values for the filter dropdown of column on open
            self.onOpenGetFilterValues = AppTableService.onOpenGetFilterValues;

            // getFilterValues: Gets unique and non-empty values for the filter dropdown of column
            self.getFilterValues = AppTableService.getFilterValues;

            self.resetFilter = AppTableService.resetFilter;

            self.clearFilter = AppTableService.clearFilter;

            self.filterDate = {};

            self.handleDateFilter = AppTableService.handleDateFilter;

            // Table toolbar buttons
            self.reloadTableData = AppTableService.reloadTableData;

            self.clearRowSelection = AppTableService.clearRowSelection;

            // Row actions
            self.selectRow = function (rule) {};

            self.refillRelatedDropDowns = function (row, fieldName) {
                var elementOpts = [];
                elementOpts = self.predefinedDropdowns[fieldName];
                return elementOpts;
            };

            self.editField = AppTableService.editField;

            self.deleteRow = AppTableService.deleteRow;

            self.statusUpdate = AppTableService.statusUpdate;

            self.duplicateRow = AppTableService.duplicateRow;

            // Pagination
            self.toggleLimitOptions = AppTableService.toggleLimitOptions;

            self.logOrder = AppTableService.logOrder;

            self.logPagination = AppTableService.logPagination;

            self.showFullName = AppTableService.showFullName;

            // Add row
            function addRowDialogController($mdDialog, Restangular, $rootScope) {
                var addSelf = this;

                addSelf.name = self.name;

                // Form pre submit default values
                addSelf.row = {};

                addSelf.today = new Date();

                addSelf.hide = function () {
                    $mdDialog.hide();
                };

                addSelf.cancel = function () {
                    $mdDialog.cancel();
                };

                addSelf.saveRow = function () {
                    addSelf.item.form.$setSubmitted();

                    if (addSelf.item.form.$valid) {
                        addSelf.row.created = new Date();
                        addSelf.row.created_by = $rootScope.employee.cwid;
                        var saveRuleRest = Restangular.all(self.modelName);
                        addSelf.promise = saveRuleRest.customPOST(addSelf.row);
                        addSelf.promise.then(function (response) {
                            $mdDialog.hide();

                            self.reloadTableData();
                            $mdToast.show(
                                $mdToast.simple()
                                .position($rootScope.mdToastPosition)
                                .textContent('New ' + self.name.singular + ' added')
                                .hideDelay(3000)
                                .action('x')
                            );
                        }, function (response) {
                            AppTableService.defaultErrorHandling(response, addSelf);
                        });
                    }
                };
            }

            self.addRow = function () {
                $mdDialog.show({
                    // controller: angular.noop,
                    controller: addRowDialogController,
                    controllerAs: '$ctrl',
                    bindToController: true,
                    locals: { parent: self },
                    templateUrl: 'js/ldap-groups/ldap-groups.add.template.html',
                    preserveScope: true,
                    clickOutsideToClose: true,
                    focusOnOpen: false
                });
            };

            // Manage Row
            function manageRolePermissionDialogController($mdDialog, Restangular, AppTableService, $rootScope, AuthService) {
                var roleManageSelf = this;

                roleManageSelf.tableName = 'role_permissions';

                roleManageSelf.modelName = 'role_permissions';

                roleManageSelf.primaryKey = 'id';

                roleManageSelf.displayField = 'name';

                roleManageSelf.name = {
                    singular: 'LDAP Groups Permission',
                    plural: 'LDAP Groups Permissions',
                    title: 'LDAP Groups Permissions for ' +
                        '#' + roleManageSelf.currentRow[roleManageSelf.parent.primaryKey] + ', ' +
                        roleManageSelf.currentRow[roleManageSelf.parent.displayField]
                };

                roleManageSelf.hide = function () {
                    $mdDialog.hide();
                };

                roleManageSelf.cancel = function () {
                    $mdDialog.cancel();
                };

                roleManageSelf.tableRecords = [];

                // Table options
                roleManageSelf.limitOptions = [5, 10];

                roleManageSelf.options = {
                    rowSelection: false,
                    multiSelect: false,
                    autoSelect: false,
                    decapitate: false,
                    largeEditDialog: false,
                    boundaryLinks: false,
                    limitSelect: true,
                    pageSelect: true
                };

                roleManageSelf.filterToggle = roleManageSelf.parent.filterToggle;

                // Search Filters
                roleManageSelf.filteredCollection = {};

                roleManageSelf.query = {
                    filter: {
                        permission: 'MENU_'
                    },
                    where: {
                        role_id: roleManageSelf.currentRow[roleManageSelf.parent.primaryKey]
                    },
                    order: 'permission',
                    limit: 10,
                    page: 1
                };

                roleManageSelf.loadTableRecords = function () {
                    roleManageSelf.clearRowSelection();

                    roleManageSelf.tableRecords = [];

                    var param = AppTableService.buildQuery(roleManageSelf.query, roleManageSelf);

                    roleManageSelf.promise = Restangular.all(roleManageSelf.modelName).getList(param);
                    roleManageSelf.promise.then(function (rolePermissions) {

                        roleManageSelf.promise = Restangular.all('permissions').getList();
                        roleManageSelf.promise.then(function (permissions) {

                            _.each(permissions, function (permission) {
                                var rolePermission = {
                                    role_id: roleManageSelf.currentRow[roleManageSelf.parent.primaryKey],
                                    permission: permission.title,
                                    permission_id: permission.id,
                                    read: false,
                                    create: false,
                                    update: false,
                                    delete: false
                                };

                                var permissionAttachedWithRole = _.find(rolePermissions, {
                                    permission_id: permission.id
                                });

                                if (permissionAttachedWithRole) {
                                    rolePermission.id = permissionAttachedWithRole.id;
                                    rolePermission.read = permissionAttachedWithRole.read;
                                    rolePermission.create = permissionAttachedWithRole.create;
                                    rolePermission.update = permissionAttachedWithRole.update;
                                    rolePermission.delete = permissionAttachedWithRole.delete;
                                }

                                roleManageSelf.checkAllSet(rolePermission);

                                roleManageSelf.tableRecords.push(rolePermission);
                            });

                        }, function (response) {
                            AppTableService.defaultErrorHandling(response, roleManageSelf);
                        });
                    }, function (response) {
                        AppTableService.defaultErrorHandling(response, roleManageSelf);
                    });
                };

                roleManageSelf.clearRowSelection = AppTableService.clearRowSelection;

                roleManageSelf.loadTableRecords();

                roleManageSelf.changeCB = function (event, changeRow) {
                    var rowRest;

                    var row = _.clone(changeRow);
                    var permissionName = row.permission;
                    delete row.permission;
                    delete row.all;

                    var isPost = false;

                    if (row.id) {
                        rowRest = Restangular.one(roleManageSelf.modelName, row.id);
                        roleManageSelf.promise = rowRest.customPATCH(row);
                    } else {
                        row.created = new Date();
                        row.created_by = 'EMYXH';
                        rowRest = Restangular.all(roleManageSelf.modelName);
                        roleManageSelf.promise = rowRest.customPOST(row);
                        isPost = true;
                    }

                    roleManageSelf.promise.then(function (response) {
                        row.permission = permissionName;
                        changeRow = _.clone(row);
                        roleManageSelf.checkAllSet(changeRow);

                        if (isPost) {
                            changeRow.id = response.id;
                        }

                        // Update Menu if a permission of Menu is changed for the current user's role
                        // if (($rootScope.employee.Role.Code === roleManageSelf.currentRow.Code) && (row.Permission.match(/MENU_/))) {
                        //     AuthService.reValidateUser();
                        // }
                    }, function (response) {
                        AppTableService.defaultErrorHandling(response, roleManageSelf);
                    });
                };

                roleManageSelf.setAll = function (event, row) {
                    row.read = row.all;

                    if (row.permission.indexOf('MENU') !== 0) {
                        row.create = row.all;
                        row.update = row.all;
                        row.delete = row.all;
                    }

                    roleManageSelf.changeCB(event, row);
                };

                roleManageSelf.checkAllSet = function (row) {
                    if (row.permission.indexOf('MENU') === 0) {
                        if (row.read) {
                            row.all = true;
                        } else {
                            row.all = false;
                        }
                    } else {
                        if (row.read && row.create && row.update && row.delete) {
                            row.all = true;
                        } else {
                            row.all = false;
                        }
                    }
                };

                // Pagination
                roleManageSelf.toggleLimitOptions = AppTableService.toggleLimitOptions;

                roleManageSelf.logOrder = AppTableService.logOrder;

                roleManageSelf.logPagination = AppTableService.logPagination;
            }

            self.manageRolePermission = function (event, row) {
                $mdDialog.show({
                    // controller: angular.noop,
                    controller: manageRolePermissionDialogController,
                    controllerAs: '$ctrl',
                    bindToController: true,
                    locals: { parent: self, currentRow: row },
                    templateUrl: 'js/ldap-groups/manage-ldap-groups-permission.template.html',
                    preserveScope: true,
                    clickOutsideToClose: true,
                    focusOnOpen: false
                });
            };
        }
    ]
});
