'use strict';

//const { concat } = require("lodash");


var esbList = angular.module('esb-list', []);

esbList.component('esbList', {
    templateUrl: 'js/esb-list/esb-list.template.html',

    controller: ['Restangular', '$state', '$mdEditDialog', '$q', '$timeout', '$mdDialog', '_', 'AppTableService', '$mdToast', '$rootScope', 'moment', '$window',
    function EsbListController(Restangular, $state, $mdEditDialog, $q, $timeout, $mdDialog, _, AppTableService, $mdToast, $rootScope, moment, $window) {
        var self = this;

        self.tableName = 'runtimes';

        self.modelName = 'runtimes';

        self.name = {
            singular: 'ESB-Job Overview',
            plural: 'ESB-Job Overview',
            title: 'ESB-Job Overview'
        };
        self.name.singularLcase = self.name.singular.toLowerCase();

        // Load rules via REST
        self.tableRecords = [];

        self.selected = [];

        self.jobListOneTime =[];

        self.selectedObjectField = [];

        self.fieldValidators = {};

        self.dependantDropdowns = {};

        self.loadData = 0;

        self.getUpdateDependantDropdown = AppTableService.getUpdateDependantDropdown;

        // Table options
         self.limitOptions =[10,20,50,100,500];

        self.options = {
            rowSelection: false,
            multiSelect: false,
            autoSelect: false,
            decapitate: false,
            largeEditDialog: false,
            boundaryLinks: false,
            limitSelect: true,
            pageSelect: true
        };

        // Search Filters
        self.filteredCollection = {};

        self.filterToggle = {
            state: false,
            tooltipText: {
                false: 'Show Filter',
                true: 'Hide Filter'
            }
        };

        self.selectedProject = 'Select Project...'

        self.projectNames = {"Select Project...":"Select Project..."};

        self.projectPermissions = [];

        self.getEnvEnabled = function(value){
          var res=false;
          var currProject = self.projectPermissions.find(function (project) {
            return project.project_code == self.selectedProject;
          });
          if (currProject)
          {
            console.debug('esb-list-permissions: Start filtering environments');
            currProject.environments.forEach(function (env){
              console.debug('esb-list-permissions: process environment: ' + JSON.stringify(env));
            switch (value) {
            case "start":
            case "stop" :
              res = env.roles.some(role=>self.startStopAuthorizedRoles.indexOf(role)> -1);
            break;
            case "deploy":
            case "undeploy":
              res = env.roles.some(role=>self.deployUndeployAuthorizedRoles.indexOf(role)> -1);  
            break;
            default:
              return false;
            }
        })} 
        return res;
      };

        $rootScope.$watch('userFullyValidated', function(newValue, oldValue) {
            if((oldValue !== newValue) && newValue) {
                self.$onInit();
            }
        });

        $rootScope.$on('vCountrySwitched', function(event, data) {
            self.$onInit();
        });

        self.loadTableRecords = AppTableService.loadTableRecords;

        self.deleteRow = AppTableService.deleteRow;

        // Pagination
        self.toggleLimitOptions = AppTableService.toggleLimitOptions;

        self.logOrder = AppTableService.logOrder;

        self.logPagination = AppTableService.logPagination;

        self.clearRowSelection = function() {
            self.selected = [];
            self.jobList = [];
            self.globalCodes = [];
        };

        self.query = {
            filter: {},
            order: false,
            orderDesc: false,
            limit: 10,
            page: 1,
            where: {
                //project_code: 'CFL'
            },
            contains: []
        };

        self.startStopAuthorizedRoles = [];
        var param = AppTableService.buildQuery(self.query, self);
        self.promise = Restangular.all('permission/apis?name=TalendApi&action=startStopEsb').getList(param);
        self.promise.then(function(records) {
          self.startStopAuthorizedRoles = records;
        });

        self.deployUndeployAuthorizedRoles = [];
        var param = AppTableService.buildQuery(self.query, self);
        self.promise = Restangular.all('permission/apis?name=TalendApi&action=deployUndeployEsb').getList(param);
        self.promise.then(function(records) {
          self.deployUndeployAuthorizedRoles = records;
        });

        self.$onInit = function(reloadTableData) {
            if($rootScope.userFullyValidated) {
                if(!reloadTableData) {
                    reloadTableData = false;
                }
                var param = AppTableService.buildQuery(self.query, self);
                self.promise = Restangular.all('permission').getList(param);
                self.promise.then(function(records) {
                    var projects = [];
                    _.forEach(records, function(key, value) {
                       // projects[key['project_code']] = key['project_code'];
                       projects.push({ data:key['project_code']});
                    });
                    console.log("projects",projects)
                    self.projectNames = projects;
                    console.log(self.projectNames)
                    self.projectPermissions = records;
                    console.log("projectPermission", self.projectPermissions);
                });
            }
        };

        // getFilterValues: Gets unique and non-empty values for the filter dropdown of column
        self.getFilterValues = AppTableService.getFilterValues;

        self.resetFilter = AppTableService.resetFilter;

        self.clearFilter = AppTableService.clearFilter;


        self.reloadEsbList = function () {
          self.tableRecords = [];
          self.promise = Restangular.one('talend/esbs?projectCodes=["'+self.selectedProject+'"]').get();
          self.promise.then(function(response) {
            if(!_.isEmpty(response)){
              console.log({response});
              self.tableRecords = response;
            }
            $mdToast.show(
              $mdToast.simple()
              .position($rootScope.mdToastPosition)
              .textContent(msgContent + 'data refreshed')
              .hideDelay(3000)
              .action('x')
            );
          },function(response){
            AppTableService.defaultErrorHandling(response, self);
          });
        }
        // Table toolbar buttons
        self.reloadTableData = function(){
            self.reloadEsbList();
        };

        self.onProjectChange = function(){
          self.reloadEsbList();
        };


        self.undeployEsb =function(row, env)
        {
          var promise = Restangular.one('talend/esb/undeploy?esbId='+env.id+'&env='+env.env).customPOST();
          promise.then(function (response) {
                console.log(response);
                self.reloadEsbList();
                 $mdDialog.show(
                     $mdDialog.alert()
                     .title()
                     .ariaLabel(row.esblabel +": undeployed")
                     .textContent( row.esblabel +": undeployed")
                     .ok('Ok')
                 );
              }, function(response) {
                  // Error
                  AppTableService.defaultErrorHandling(response);
                  $mdDialog.show(
                      $mdDialog.alert()
                      .title()
                      .ariaLabel("Could not undeploy esb: "+row.esblabel)
                      .textContent("Could not undeploy esb: "+row.esblabel)
                      .ok('Ok')
                  );
              });
        }

        self.deployEsb =function(row, env)
        {
          var promise = Restangular.one('talend/esb/deploy?esbId='+env.id+'&env='+env.env).customPOST();
          promise.then(function (response) {
                console.log(response);
                self.reloadEsbList();
                 $mdDialog.show(
                     $mdDialog.alert()
                     .title()
                     .ariaLabel(row.esblabel +": deployed")
                     .textContent( row.esblabel +": deployed")
                     .ok('Ok')
                 );
              }, function(response) {
                  // Error
                  AppTableService.defaultErrorHandling(response);
                  $mdDialog.show(
                      $mdDialog.alert()
                      .title()
                      .ariaLabel("Could not deploy esb: "+row.esblabel)
                      .textContent("Could not deploy esb: "+row.esblabel)
                      .ok('Ok')
                  )
              });
        }

        self.startEsb =function(row, env)
        {
          var promise = Restangular.one('talend/esb/start?esbId='+env.id+'&env='+env.env).customPOST();
          promise.then(function (response) {
                console.log(response);
                self.reloadEsbList();
                 $mdDialog.show(
                     $mdDialog.alert()
                     .title()
                     .ariaLabel(row.esblabel +": started")
                     .textContent( row.esblabel +": started")
                     .ok('Ok')
                 );
              }, function(response) {
                  // Error
                  AppTableService.defaultErrorHandling(response);
                  $mdDialog.show(
                      $mdDialog.alert()
                      .title()
                      .ariaLabel("Could not start esb: "+row.esblabel)
                      .textContent("Could not start esb: "+row.esblabel)
                      .ok('Ok')
                  )
              });
        }

        self.stopEsb =function(row, env)
        {
          var promise = Restangular.one('talend/esb/stop?esbId='+env.id+'&env='+env.env).customPOST();
          promise.then(function (response) {
                console.log(response);
                self.reloadEsbList();
                 $mdDialog.show(
                     $mdDialog.alert()
                     .title()
                     .ariaLabel(row.esblabel +": stopped")
                     .textContent( row.esblabel +": stopped")
                     .ok('Ok')
                 );
              }, function(response) {
                  // Error
                  AppTableService.defaultErrorHandling(response);
                  $mdDialog.show(
                      $mdDialog.alert()
                      .title()
                      .ariaLabel("Could not stop esb: "+row.esblabel)
                      .textContent("Could not stop esb: "+row.esblabel)
                      .ok('Ok')
                  )
              });
        }

    }
]
});
