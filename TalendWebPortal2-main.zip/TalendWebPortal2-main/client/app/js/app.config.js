'use strict';

app.config(['$qProvider', '$mdThemingProvider', '$locationProvider', '$stateProvider', '$urlRouterProvider', '$mdDateLocaleProvider', 'moment', 'LoopBackResourceProvider', '_',
    function config($qProvider, $mdThemingProvider, $locationProvider, $stateProvider, $urlRouterProvider, $mdDateLocaleProvider, moment, LoopBackResourceProvider, _) {

        // Use a custom auth header instead of the default 'Authorization'
        LoopBackResourceProvider.setAuthHeader('X-Access-Token');
		      $qProvider.errorOnUnhandledRejections(false);
        // Change the URL where to access the LoopBack REST API server
        LoopBackResourceProvider.setUrlBase('/api');
        // Format Date formats for application
        $mdDateLocaleProvider.formatDate = function (date) {
            if (date) {
                return moment(date).format('MM/DD/YYYY');
            } else {
                return '';
            }
        };

        $mdDateLocaleProvider.parseDate = function (dateString) {
            var m = moment(dateString, 'MM/DD/YYYY', true);
            return m.isValid() ? m.toDate() : new Date(NaN);
        };

        $mdThemingProvider.theme('default')
            .primaryPalette('teal')
            .accentPalette('blue-grey', {
                'default': '100' // use shade 200 for default, and keep all other shades the same
            })
            .warnPalette('red');

        $locationProvider.hashPrefix('!');

        function checkForAuthenticatedUser(AuthService, $state) {
            // \console.log('212');
            return AuthService.getCurrentUser().$promise
                .then(function(response) {
                    return AuthService.validateUser(response.CWID, response);
                }, function(response) {
                    AuthService.logout();
                });
        }

        $stateProvider
            .state('app', {
                abstract: true,
                // see controller def below
                controller: function (authUser, $rootScope, $state) {
                    $rootScope.validateState(null, $state.current);
                },
                // this is template, discussed below - very important
                template: '<div ui-view layout-fill="layout-fill"></div>',
                // resolve used only once, but for available for all child states
                resolve: {
                    authUser: checkForAuthenticatedUser
                }
            })
            .state('app.home', {
              url: '/',
              template: '<login-form></login-form>',
              data: {
                pageTitle: 'Login'
              }
            })
            .state('app.login', {
              url: '/login',
              template: '<login-form></login-form>',
              data: {
                pageTitle: 'Login'
              },
              params: {
                errorMessage: null,
                loginRedirect: null
              }
            })
            .state('app.dashboard', {
                url: '/dashboard',
                template: '<header-nav></header-nav> <dashboard></dashboard>',
                data: {
                    pageTitle: 'Dashboard'
                },
                authenticate: true
            })
            .state('app.users', {
                url: '/users',
                template: '<header-nav></header-nav> <users></users>',
                data: {
                    pageTitle: 'Users'
                },
                authenticate: true
            })
            .state('app.permissions', {
                url: '/permissions',
                template: '<header-nav></header-nav> <permission></permission>',
                data: {
                    pageTitle: 'Permissions'
                },
                authenticate: true
            })
            .state('app.roles', {
                url: '/roles',
                template: '<header-nav></header-nav> <role></role>',
                data: {
                    pageTitle: 'Roles'
                },
                authenticate: true
            })
            .state('app.ldap-groups', {
                url: '/ldap-groups',
                template: '<header-nav></header-nav> <ldap-groups></ldap-groups>',
                data: {
                    pageTitle: 'Ldap Groups'
                },
                authenticate: true
            })
            .state('app.runtimes', {
                url: '/runtimes',
                template: '<header-nav></header-nav> <runtimes></runtimes>',
                data: {
                    pageTitle: 'Project Overview'
                },
                authenticate: true
            })
            .state('app.configuration', {
                url: '/configuration/{project_code:string}',
                template: '<header-nav></header-nav> <configuration></configuration>',
                data: {
                    pageTitle: 'Configuration'
                },
                authenticate: true
            })
            .state('app.reference', {
                url: '/reference/{project_id:string}',
                template: '<header-nav></header-nav> <reference></reference>',
                data: {
                    pageTitle: 'Secondary Reference'
                },
                authenticate: true
              })
            .state('app.menus', {
                url: '/menus',
                template: '<header-nav></header-nav> <menu-list></menu-list>',
                data: {
                    pageTitle: 'Menus'
                },
                authenticate: true
            })
            .state('app.task-list', {
              url: '/task-list',
              template: '<header-nav></header-nav> <task-list></task-list>',
              data: {
                  pageTitle: 'Task List'
              },
              authenticate: true
            })
            .state('app.esb-list', {
                url: '/esb-list',
                template: '<header-nav></header-nav> <esb-list></esb-list>',
                data: {
                    pageTitle: 'Esb List'
                },
                authenticate: true
              })
            /*.state('app.projects', {
              url: '/projects',
              template: '<header-nav></header-nav> <projects></projects>',
              data: {
                  pageTitle: 'Project Overview'
              },
              authenticate: true
            })*/
            .state('app.test', {
                url: '/testrun',
                template: '<header-nav></header-nav> <test></test>',
                data: {
                    pageTitle: 'TestRUN'
                },
                authenticate: true
              })
            .state('app.tbutton', {
                url: '/tbutton',
                template: '<header-nav></header-nav> <tbutton></tbutton>',
                data: {
                    pageTitle: 'ConnBUTTON'
                },
                authenticate: true
              })  
            .state('app.postgredb', {
                url: '/postgredb',
                template: '<header-nav></header-nav> <postgredb></postgredb>',
                data: {
                    pageTitle: 'Postgre Connection Test'
                },
                authenticate: true
              })
            .state('app.mssqldb', {
                url: '/mssqldb',
                template: '<header-nav></header-nav> <mssqldb></mssqldb>',
                data: {
                    pageTitle: 'MSSQL Connection Test'
                },
                authenticate: true
              })  
            .state('app.oracledb', {
                url: '/oracledb',
                template: '<header-nav></header-nav> <oracledb></oracledb>',
                data: {
                    pageTitle: 'Oracle Connection Test'
                },
                authenticate: true
              })  
            .state('404', {
                url: '/404',
                template: '<error-404></error-404>',
                data: {
                    pageTitle: '404 - Not Found'
                }
            })
            .state('401', {
                url: '/401',
                template: '<error-401></error-401>',
                data: {
                    pageTitle: '401'
                }
            })
			.state('forbidden', {
                url: '/forbidden',
                templateUrl: 'static/forbidden.html',
				data: {
                    pageTitle: 'forbidden'
                }
            })
            .state('403', {
                url: '/403',
                template: '<error-403></error-403>',
                data: {
                    pageTitle: '403'
                }
            });


        // Homepage check
        $urlRouterProvider.when('', '/');

        // Send to login if the URL was not found
        $urlRouterProvider.otherwise('/404');


    }
]);
