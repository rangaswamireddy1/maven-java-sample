'use strict';

var runtimes = angular.module('projects', []);

runtimes.component('projects', {
    templateUrl: 'js/projects/projects.template.html',

    controller: ['Restangular', '$state', '$mdEditDialog', '$q', '$timeout', '$mdDialog', '_', 'AppTableService', '$mdToast', '$rootScope', 'moment', '$window',
    function RuntimesController(Restangular, $state, $mdEditDialog, $q, $timeout, $mdDialog, _, AppTableService, $mdToast, $rootScope, moment, $window) {
        var self = this;

        self.tableName = 'projects';

        self.modelName = 'projects';

        /*self.name = {
            singular: 'Project Overview',
            plural: 'Project Overview',
            title: 'Project Overview'
        };*/
        self.name.singularLcase = self.name.singular.toLowerCase();

        // Load rules via REST
        self.tableRecords = [];

        self.selected = [];

        self.jobListOneTime =[];

        self.selectedObjectField = [];

        self.fieldValidators = {};

        self.predefinedDropdowns = {
            EnvType: {
                INT: "INT",
                QA: "QA",
                PROD: "PROD"
            },
            envDisplayRank:{
                D1 : 1,
                E1 : 2,
                Q2 : 3,
                I1 : 4,
                P2 : 5
            }
        };

        self.dependantDropdowns = {};

        self.loadData = 0;

        self.getUpdateDependantDropdown = AppTableService.getUpdateDependantDropdown;

        // Table options
         self.limitOptions =[5,10,20,50];

        self.options = {
            rowSelection: true,
            multiSelect: false,
            autoSelect: false,
            decapitate: false,
            largeEditDialog: false,
            boundaryLinks: false,
            limitSelect: true,
            pageSelect: true
        };

        // Search Filters
        self.filteredCollection = {};

        self.filterToggle = {
            state: false,
            tooltipText: {
                false: 'Show Filter',
                true: 'Hide Filter'
            }
        };

        self.query = {
            filter: {},
            order: false,
            orderDesc: false,
            limit: 10,
            page: 1,
            where: {
                //project_code: 'CFL'
            },
            contains: [
              {
                relation: 'activemqs'
              },
              {
                relation: 'runtimes'
              }
            ]
        };

        $rootScope.$watch('userFullyValidated', function(newValue, oldValue) {
            if((oldValue !== newValue) && newValue) {
                self.$onInit();
            }
        });

        self.loadTableRecords = AppTableService.loadTableRecords;

        self.deleteRow = AppTableService.deleteRow;

        // Pagination
        self.toggleLimitOptions = AppTableService.toggleLimitOptions;

        self.logOrder = AppTableService.logOrder;

        self.logPagination = AppTableService.logPagination;

        self.clearRowSelection = function() {
            self.selected = [];
            self.jobList = [];
            self.globalCodes = [];
        };

        self.$onInit = function(reloadTableData) {
            if($rootScope.userFullyValidated) {
                if(!reloadTableData) {
                    reloadTableData = false;
                }
                var queryParams =  {
                    where:{
                        is_active: true,
                        env_name:"ALL",
                        module_type:"ELK",
                        is_default:true,
                        env_type: {
                            inq: ["PROD", "INT", "QA"]
                        }
                    }
                };
                var params = AppTableService.buildQuery(queryParams, {});
                self.promise = Restangular.one('software_modules').get(params);
                self.promise.then(function(response) {
                    if(!_.isEmpty(response)){
                        var data = response.plain();
                        var linkToKibanaDev = _.find(data, ['env_type', 'INT']);
                        var linkToKibanaQa = _.find(data, ['env_type', 'QA']);
                        var linkToKibanaProd = _.find(data, ['env_type', 'PROD']);

                        var param = AppTableService.buildQuery(self.query, self);
                        self.promise = Restangular.all('projects').getList(param);
                        self.promise.then(function(records) {
                            console.log(records);
                            var projects = [];
                            _.forEach(records, function(key, value) {

                                //activemqs
                                var activemqs = key['activemqs'];
                                if(!_.isEmpty(activemqs)){
                                    var activemqsData =  _.sortBy(activemqs, function(element){
                                        var rank = self.predefinedDropdowns.envDisplayRank;
                                        return rank[element['env']];
                                    });
                                }

                                //runtimes
                                var runtimes = key['runtimes'];
                                if (!_.isEmpty(runtimes))
                                {
                                  var runtimeData = _.sortBy(runtimes, function (element) {
                                    var rank = self.predefinedDropdowns.envDisplayRank;
                                    return rank[element['env']];
                                  });
                                }

                                var linkToKibana = [];
                                var env = self.predefinedDropdowns.EnvType;
                                _.forEach(env, function(obj, env) {
                                    if(env === 'PROD'){
                                        linkToKibana.push({
                                          env : obj,
                                          link : linkToKibanaProd.url + self.linkToKibana(key['project_name'],
                                          env)});
                                    }else if(env === 'QA'){
                                        linkToKibana.push({
                                          env : obj,
                                          link : linkToKibanaQa.url + self.linkToKibana(key['project_name'],
                                          env)});
                                    }else{
                                        linkToKibana.push({
                                          env : obj,
                                          link : linkToKibanaDev.url + self.linkToKibana(key['project_name'],
                                          env)});
                                    }
                                });
                                
                                var coreconfigProperties = [];
                                    if(key['isCORERef'] ){
                                    coreconfigProperties.push({env : 'DEV'});
                                  }
                                
                            

                                projects.push({
                                  project_code: key['project_code'],
                                  project_name: key['project_name'],
                                  runtimes: _.uniqBy(runtimeData, 'env'),
                                  linkToGit: key['gitURLtac'],
                                  project_id: key['project_id'],
                                  activemqsData: _.uniqBy(activemqsData, 'env'),
                                  linkToKibana: linkToKibana,
                                  coreconfigProperties: coreconfigProperties,
                                  isCORERef: key['isCORERef']
                                });
                            });
                            self.tableRecords = projects;
                            if(reloadTableData){
                                var tabelName = self.name.title;
                                if(_.isUndefined(tabelName)){
                                    tabelName = self.name.plural;
                                }
                                var msgContent = tabelName +' table ';
                                $mdToast.show(
                                    $mdToast.simple()
                                    .position($rootScope.mdToastPosition)
                                    .textContent(msgContent + 'data refreshed')
                                    .hideDelay(3000)
                                    .action('x')
                                );
                            }

                        });
                      }
                    },function(response){
                      console.log('error', response);
                        AppTableService.defaultErrorHandling(response, self);
                    });

            }
        };

        // getFilterValues: Gets unique and non-empty values for the filter dropdown of column
        self.getFilterValues = AppTableService.getFilterValues;

        self.resetFilter = AppTableService.resetFilter;

        self.clearFilter = AppTableService.clearFilter;

        self.linkToKibana = function(project_name, envKibana){
            var linkTokibana = '';

      			var dashboardID = "13976330-11a3-11e8-bed9-e53afa493bd5";
      			//var indexId="";
      			// if (envKibana === 'DEV')
      			//   {
      			//     indexId="AWFRfSnsVsJkw7Un4Vsv";
      			//   }
      			// if (envKibana === 'PROD' || envKibana === 'QA')
      			//   {
      			// 	dashboardID = "13976330-11a3-11e8-bed9-e53afa493bd5";
      			//     indexId="AWFRfSnsVsJkw7Un4Vsv";
      			//   }
                  linkTokibana +="/s/talend/app/dashboards#/view/"+dashboardID ;
      			//_g
      			// linkTokibana +="?_g=(filters:!(";
      			// linkTokibana +="('$state':(store:globalState),meta:(alias:!n,disabled:!f,index:'"+indexId+"',key:project,negate:!f,type:phrase,value:"+project_name+"),query:(match:(project:(query:"+project_name+",type:phrase))))";
      			// linkTokibana +=",";
      			// linkTokibana +="('$state':(store:globalState),meta:(alias:!n,disabled:!f,index:'"+indexId+"',key:environment,negate:!f,type:phrase,value:"+envKibana+"),query:(match:(environment:(query:"+envKibana+",type:phrase))))";
      			// linkTokibana +="),refreshInterval:(display:Off,pause:!f,value:0),time:(from:now-24h,mode:quick,to:now))";
      			// //_a
      			// linkTokibana +="&_a=(filters:!(),query:(query_string:(analyze_wildcard:!t,query:'*')),viewMode:view)";

            return linkTokibana;
        }

        // Table toolbar buttons
        self.reloadTableData = function(){
            self.$onInit(true);
        };
        self.coreconfigProperties = function(event, row){
            if(!_.isEmpty(row)){
                event.stopPropagation(); // in case autoselect is enabled
                var projectName  = row.project_name;
                console.log(row)
                var env  = env;
                var gitLink = row.linkToGit;
                //console.log("self",{self})
                if(gitLink.includes('github') ){
                    var resulting = Restangular.one('github/configuration.properties?projectName=' + projectName).get();
                    console.log("github: ",resulting)
                }
                else if(gitLink.includes('gitlab')) {
                    var resulting = Restangular.one('gitlab/configuration.properties?projectName=' + projectName).get();
                    console.log("gitlab: ",resulting)    
                }
                else if(!(gitLink.includes('gitlab') || gitLink.includes('github')) ){
                    (function(response){
                        var opener = window.open(response, "Please Contact Your Administrator");
                        opener.document.write(response);
                    });
                }
                resulting.then(function (response) {
                   //console.log("response",response)
                   var newResponse = response.replaceAll("\n","<br/>");
                   //console.log({newResponse})
                   var opener = window.open(newResponse,"_blank");
                   opener.document.write(newResponse);

                }, function(response) {
                    // Error
                    console.log("Error",response)
                    AppTableService.defaultErrorHandling(response);
                }); 
 

                // var projectName  = row.project_name;
                // console.log({projectName})
                // var env  = env;
                // $window.open($rootScope.baseServerApiUrl + 'gitlab/configuration.properties?projectName=' + projectName, '_blank');
            }
        }

        // Row actions
        self.selectRow = function(row) {
            self.jobList = [];
            var projectName = row.project_name;
            if(self.loadData === 0){
                //self.name.title = 'Job List for Project, ' + projectName;
                self.jobListPromise = Restangular.one('talend/job').get();
                self.jobListPromise.then(function (response) {
                    var response = JSON.parse(response);
                    self.jobList = _.filter(response.result, {projectName: projectName});
                    self.jobListOneTime = response.result;
                    self.loadData ++;
                }, function(response) {
                    // Error
                    AppTableService.defaultErrorHandling(response);
                });
            }else{
                self.jobList = _.filter(self.jobListOneTime, {projectName: projectName});
            }
        };

        self.displayProjectConfiguration = function (event, row) {
          var url = $state.go('app.configuration', {project_code: row.project_code });//{ id: row.id });
        };

        self.displayProjectReferences = function (event, row) {
            var id = String(row.project_id);
            var url = $state.go('app.reference', {project_id: id });//{ id: row.id });
          };

    }
]
});
