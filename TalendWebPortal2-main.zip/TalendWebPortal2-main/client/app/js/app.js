
"use strict";

if (!Array.prototype.find) {
        Array.prototype.find = function(predicate) {

            if (this == null) {
              console.error('Array.prototype.find called on null or undefined');
                throw new TypeError('Array.prototype.find called on null or undefined');
            }
            if (typeof predicate !== 'function') {
              console.error('predicate must be a function');
                throw new TypeError('predicate must be a function');
            }
            var list = Object(this);
            var length = list.length >>> 0;
            var thisArg = arguments[1];
            var value;

            for (var i = 0; i < length; i++) {
                value = list[i];
                if (predicate.call(thisArg, value, i, list)) {
                    return value;
                }
            }
            return undefined;
        };
}

var app = angular.module('Talend', [
    'ui.router', 'ngMessages',
    'ngMaterial', 'md.data.table',
    'lodash', 'angular-lodash-filter', 
    'restangular', 'angularMoment','lbServices', 

    //
    'httpErrors',

    // Layout
    'headerNav',

    // Internal app modules
    'dashboard',
    'users', 'permission', 'loginForm', 'role', 'menuList', 'ldapGroups', 'runtimes', 'configuration', 'task-list','esb-list','reference', 'projects', 'test', 'tbutton', 'postgredb', 'mssqldb', 'oracledb'
]);

app.directive('ngConfirmClick', [
    function(){
        return {
            link: function (scope, element, attr) {
                var msg = attr.ngConfirmClick || "Are you sure?";
                var clickAction = attr.confirmedClick;
                element.bind('click',function (event) {
                    if ( window.confirm(msg) )
                    {
                        scope.$eval(clickAction)
                    }
                });
            }
        };
}])
