'use strict';

app.service('AppTableService', [
    '$state', 'Restangular', '$mdEditDialog', '$q', '$timeout', '$mdDialog', '_', 'moment', '$rootScope', 'AppDropDownsService', '$mdToast', '$window',
    function ($state, Restangular, $mdEditDialog, $q, $timeout, $mdDialog, _, moment, $rootScope, AppDropDownsService, $mdToast, $window) {

        var selfService = this;

        var self;

        selfService.filterToggle = {
            state: false,
            tooltipText: {
                false: 'Show Filter',
                true: 'Hide Filter'
            }
        };

        selfService.getUpdateDependantDropdown = function (targetModelName, currentModelName, currentValue, self) {
            if (!self) {
                self = this;
            }

            self.predefinedDropdowns[targetModelName] = self.dependantDropdowns[currentModelName + '_2_' + targetModelName][currentValue];
            return self.predefinedDropdowns[targetModelName];
        };

        selfService.onOpenGetFilterValues = function (field) {
            var self = this;
            if (!angular.isDefined(self.filterValues)) {
                self.filterValues = {};
            }
            var values = _.map(self.tableRecords, field);
            values = _.filter(_.uniq(values), function (val) {
                return !_.isEmpty(val);
            });
            self.filterValues[field] = values;
        };

        selfService.getFilterValues = function (field) {
            var self = this;

            var values = _.map(self.tableRecords, field);
            values = _.filter(_.uniq(values), function (val) {
                return !_.isEmpty(val);
            });
            return values;
        };

        selfService.resetFilter = function () {
            var self = this;

            if (!self.filterToggle.state) {
                self.query.filter = {};
            }
        };

        selfService.clearFilter = function () {
            var self = this;

            self.query.filter = self.query.filter = {};
            self.filterDate = {};

            var tabelName = self.name.title;
            if (_.isUndefined(tabelName)) {
                tabelName = self.name.plural;
            }
            var msgContent = tabelName + ' table ';

            if (self.showDefaultText === true) {
                msgContent = '';
            }

            $mdToast.show(
                $mdToast.simple()
                .position($rootScope.mdToastPosition)
                .textContent(msgContent + 'filter cleared')
                .hideDelay(3000)
                .action('x')
            );
        };

        selfService.handleDateFilter = function (fieldName) {
            var self = this;

            var str = self.filterDate[fieldName];

            if (str.length) {
                var slashCount = (str.match(/\//g) || []).length;
                // console.log(slashCount);
                if (slashCount > 0) {
                    if (slashCount === 1) {
                        if (str.length < 6) {
                            self.query.filter[fieldName] = moment(self.filterDate[fieldName], 'MM/DD').format('MM-DD');
                        } else {
                            self.query.filter[fieldName] = moment(self.filterDate[fieldName], 'MM/YYYY').format('YYYY-MM');
                        }

                    } else {
                        self.query.filter[fieldName] = moment(self.filterDate[fieldName], 'MM/DD/YYYY').format('YYYY-MM-DD');
                    }
                } else {
                    self.query.filter[fieldName] = self.filterDate[fieldName];
                }
            } else {
                self.query.filter[fieldName] = moment(self.filterDate[fieldName], 'MM/DD/YYYY').format('YYYY-MM-DD');
            }
            // console.log(self.query.filter[fieldName]);
        };

        selfService.buildQuery = function(query, self) {
          var obj = {};

          if(!_.isEmpty(self.query)) {
            self.query = _.extend(self.query, query);
          } else {
            self.query = query;
          }

          var params = {
            filter: JSON.stringify({
              include: self.query.contains,
              where: self.query.where
            })
          };

          return params;
        };

        // Table toolbar buttons
        selfService.loadTableRecords = function(event) {
            var self = this;

            self.clearRowSelection();

            //console.log(self.modelName);

            var param = selfService.buildQuery(self.query, self);
            //console.log(self.query);

            self.promise = Restangular.all(self.modelName).getList(param);
            self.promise.then(function(records) {
                self.tableRecords = records;
                if(!_.isUndefined(event)){
                    var tabelName = self.name.title;
                    if(_.isUndefined(tabelName)){
                        tabelName = self.name.plural;
                    }

                    var msgContent = tabelName +' table ';

                    if(self.showDefaultText === true){
                        msgContent = '';
                    }

                    $mdToast.show(
                        $mdToast.simple()
                        .position($rootScope.mdToastPosition)
                        .textContent(msgContent + 'data refreshed')
                        .hideDelay(3000)
                        .action('x')
                    );
                }

            }, function(response) {
                selfService.defaultErrorHandling(response);
            });
        };

        selfService.reloadTableData = selfService.loadTableRecords;

        selfService.getCreatedModifiedFullName = function functionName(records) {
            if(!_.isEmpty(records)){
                _.each(records, function (record) {
                    if (!_.isEmpty(record.CreatedBy)) {
                        record.CreatedByFull = selfService.getFullName(record.CreatedBy);
                    }
                    if (!_.isEmpty(record.ModifiedBy)) {
                        record.ModifiedByFull = selfService.getFullName(record.ModifiedBy);
                    }
                });
                return records;
            }else{
                return records;
            }
        }

        selfService.clearRowSelection = function (row) {
            var self = this;

            self.selected = [];
        };

        selfService.getAttrs = function (fieldName) {
            var self = this;
            var validators = self.fieldValidators[fieldName];

            var attrs = 'type="' + (validators.type || 'text') + '"';

            for (var attr in validators) {
                if (attr.length > 2) {
                    attrs += ' ' + attr + '="' + validators[attr] + '"';
                } else {
                    attrs += ' ' + validators[attr] + '';
                }
            }

            return attrs;
        };

        selfService.resetDependantDropDowns = function (row, fieldName) {
            var self = this;

            // console.log(fieldName);

            _.each(_.keys(self.dependantDropdowns), function (key) {
                var keyParts = key.split('_2_');
                // console.log(keyParts);
                // console.log(_.first(keyParts) + ' === ' + fieldName);
                if (_.first(keyParts) === fieldName) {
                    var dependantFieldName = _.last(keyParts);

                    // console.log(dependantFieldName);
                    // console.log(row);
                    // console.log(!_.isEmpty(row[dependantFieldName]));

                    if (!_.isEmpty(row[dependantFieldName])) {
                        row[dependantFieldName] = null;
                        // console.log(row);
                        selfService.resetDependantDropDowns(row, dependantFieldName);
                        // row = _.extend(row, selfService.resetDependantDropDowns(row, dependantFieldName));
                    }
                }
            });
        };

        selfService.refillRelatedDropDowns = function (row, fieldName, self) {
            if (!self) {
                self = this;
            }

            var elementOpts = [];

            elementOpts = self.predefinedDropdowns[fieldName];

            var keysSplitParts = _.map(
                _.keys(self.dependantDropdowns),
                function (key) {
                    return key.split('_2_');
                }
            );
            // console.log(keysSplitParts);

            var paths = [];
            if (_.isUndefined(self.dependantDropdownsPaths)) {
                _.each(keysSplitParts, function (keyParts) {
                    _.each(keysSplitParts, function (node) {
                        // console.log(_.first(keyParts) + " === " + _.last(node));
                        if (!_.isEqual(keyParts, node)) {
                            if (_.first(keyParts) === _.last(node)) {
                                // console.log(_.first(node) + ' ===> ' + _.first(keyParts) + ' ===> ' + _.last(keyParts));

                                var newPathSet = [_.first(node), _.first(keyParts), _.last(keyParts)];

                                var isPathMerged = false;

                                _.each(paths, function (path, index) {
                                    if (_.intersection(path, newPathSet).length === 2) {
                                        paths[index] = _.union(path, newPathSet);
                                        isPathMerged = true;
                                    }
                                });

                                if (!isPathMerged) {
                                    paths.push(newPathSet);
                                }
                            }
                        }
                    });
                });

                var tempPaths = angular.copy(paths);

                if (!_.isEmpty(tempPaths)) {
                    _.each(keysSplitParts, function (keyParts) {
                        _.each(tempPaths, function (path) {
                            if (!_.includes(path, _.first(keyParts)) || !_.includes(path, _.last(keyParts))) {
                                if (!_.includes(paths, keyParts)) {
                                    paths.push(keyParts);
                                }
                            }
                        });
                    });
                } else {
                    paths = angular.copy(keysSplitParts);
                }

                self.dependantDropdownsPaths = paths;
            } else {
                paths = self.dependantDropdownsPaths;
            }
            // console.log(paths);

            // Get path level for the current field
            _.each(keysSplitParts, function (keyParts) {
                if (_.last(keyParts) === fieldName) {
                    var sourceFieldName = _.first(keyParts);
                    var currentValue = '';

                    if (!_.isUndefined(row[sourceFieldName])) {
                        _.each(paths, function (path) {
                            var fieldIndex = _.indexOf(path, fieldName);
                            // console.log(path);
                            // console.log(fieldIndex);
                            if (fieldIndex > 0) {
                                _.each(path, function (field, index) {
                                    if (index < fieldIndex) {
                                        currentValue = currentValue + ((index !== 0) ? '_' : '') + row[field];
                                    }
                                });
                            }
                            // console.log(currentValue);
                        });

                        elementOpts = selfService.getUpdateDependantDropdown(fieldName, sourceFieldName, currentValue, self);
                    }
                }
            });

            if (_.isFunction(self.beforeLoadElementOpts)) {
                elementOpts = self.beforeLoadElementOpts(elementOpts, fieldName, row);
            }

            return elementOpts;
        };

        // Edit inline
        selfService.editField = function (event, row, fieldName, options, self) {
            if (!self) {
                self = this;
            }

            if (!options) {
                options = {};
            }

            event.stopPropagation(); // in case autoselect is enabled

            var modelValue = _.isBoolean(row[fieldName]) ? String(row[fieldName]) : row[fieldName];

            var dropdownFields = _.keys(self.predefinedDropdowns);

            var elementType = 'text';
            var elementOpts;

            if (_.indexOf(dropdownFields, fieldName) > -1) {
                elementType = 'select';
                elementOpts = selfService.refillRelatedDropDowns(row, fieldName, self);
            }

            if (!_.isEmpty(options.type)) {
                elementType = options.type;

                if (options.type === 'date') {
                    modelValue = new Date(modelValue);
                }
            }

            var dependantFieldsModified = [];

            var fillDependantFirstValue = function (row, fieldName, self) {
                var relatedData = {};

                // console.log('Checking for: ' + fieldName);
                _.each(_.keys(self.dependantDropdowns), function (key) {
                    var keyParts = key.split('_2_');
                    // console.log(keyParts);
                    if (_.first(keyParts) === fieldName) {
                        var dependantFieldName = _.last(keyParts);

                        if (!_.isUndefined(row[dependantFieldName])) {
                            dependantFieldsModified.push(dependantFieldName);

                            if (self.fieldValidators[dependantFieldName] && self.fieldValidators[dependantFieldName].required) {
                                relatedData[dependantFieldName] = row[dependantFieldName] = _.first(selfService.refillRelatedDropDowns(row, dependantFieldName, self));
                            } else {
                                relatedData[dependantFieldName] = null;
                            }
                            relatedData = _.extend(relatedData, fillDependantFirstValue(row, dependantFieldName, self));
                        }
                    }
                });
                // console.log(relatedData);

                return relatedData;
            };

            var editDialog = {
              modelValue: modelValue,
              placeholder: 'Add a value',
              save: function(input) {
                dependantFieldsModified = [];

                row[fieldName] = input.$modelValue;

                var saveData = {};
                saveData[fieldName] = row[fieldName];

                // console.log(_.keys(self.dependantDropdowns));
                saveData = _.extend(saveData, fillDependantFirstValue(row, fieldName, self));
                if($rootScope.employee) {
                  saveData.modified = new Date();
                  saveData.modified_by = $rootScope.employee.cwid;
                }
                // console.log(saveData);
                // console.log(dependantFieldsModified);

                var rowID = row.id;
                var whereFilter = {
                  where: {
                    id: rowID
                  }
                };

                if(row.id) {
                  rowID = row.id;
                  whereFilter = {
                    where: {
                      id: rowID
                    }
                  };
                }

                var message = '#'+rowID+' '+self.name.singular+' updated';

                if(_.isFunction(self.editWhereFilter)) {
                  whereFilter = self.editWhereFilter(row, fieldName, whereFilter);
                  message = 'data updated successfully';
                }

                self.promise = Restangular.one(self.modelName).customPOST(saveData, 'update', whereFilter, {})
                .then(function(response) {
                  if(!options.completeRefresh) {
                    angular.copy(response.plain(), row);
                  } else {
                    self.reloadTableData();
                  }

                  $mdToast.show(
                    $mdToast.simple()
                    .position('bottom left')
                    .textContent(message)
                    .hideDelay(3000)
                    .action('x')
                  );
                  //console.log(options);
                  //when a role is change, an the role is changed for the Current user, then to RELOAD the application
                  if(options.reloadPage) {
                    if(row.CWID === $rootScope.currentUser.CWID){
                      $window.location.reload();
                    }
                  }

                  if(!_.isEmpty(dependantFieldsModified)) {
                    $mdDialog.show(
                      $mdDialog.alert()
                      .title('Alert')
                      .textContent('Dependant fields "' + dependantFieldsModified.join(', ') + '" data is modified, please review the field(s)')
                      .ariaLabel('Dependant fields "' + dependantFieldsModified.join(', ') + '" data is modified, please review the field(s)')
                      .ok('Ok')
                    );
                  }

                  if(_.isFunction(self.editFieldAfterSave)) {
                    self.editFieldAfterSave(row, fieldName, response);
                  }



                }, function(response) {
                  selfService.defaultErrorHandling(response);
                });
              },
              targetEvent: event,
              title: 'Edit',
              validators: self.fieldValidators[fieldName],
              type: elementType,
              elementOptions: elementOpts
            };

            var promise;

            promise = $mdEditDialog.small(editDialog);

            promise.then(function (ctrl) {
                var input = ctrl.getInput();
            });
        };

        selfService.deleteRow = function(event, row, isDisableDeleteEverythingBtn, opts) {
          event.stopPropagation(); // in case autoselect is enabled
          opts = opts || {};
          var self = opts.self || this;

          var modelName;
          if(_.isEmpty(opts.modelName)) {
            modelName = self.modelName;
          } else {
            modelName = opts.modelName;
          }

          var rowID = row.id;

          var rowUpdateAfterDelete = {
            id: rowID
          };

          if(row.id) {
            rowID = row.id;
            rowUpdateAfterDelete = {
              id: rowID
            };
          }

          $mdDialog.show(
            $mdDialog.confirm()
            .clickOutsideToClose(true)
            .title('Delete ' + self.name.singularLcase + ' #'+rowID)
            .textContent('Are you sure you want to delete ' + self.name.singularLcase + ' #'+rowID)
            .ariaLabel('Delete ' + self.name.singularLcase + ' #'+rowID)
            .ok('Yes')
            .cancel('No')
            .targetEvent(event)
          ).then(function() {

            self.promise = Restangular.one(modelName, rowID).remove();
            self.promise.then(function() {
              // Delete success
              self.clearRowSelection();
              self.loadTableRecords();

              self.tableRecords = _.without(self.tableRecords, _.findWhere(self.tableRecords, rowUpdateAfterDelete));

              // Call callback function afterDelete after
              // successful delete
              if(_.isFunction(self.afterDelete)) {
                self.afterDelete(row);
              }

              // $mdDialog.show(
              //     $mdDialog.alert()
              //         .title(self.name.singular + ' #'+rowID+' deleted')
              //         .ariaLabel(self.name.singular + ' #'+rowID+' deleted')
              //         .ok('Ok')
              // );

              $mdToast.show(
                $mdToast.simple()
                .position('bottom left')
                .textContent(self.name.singular + ' #'+rowID+' deleted')
                .hideDelay(3000)
                .action('x')
              );
            },
            function(response) {
              // console.log(response);
              var errorTitle, errorMessage;
              errorTitle = 'Something\'s wrong';
              errorMessage = 'Oops something got wrong, cannot complete your request.';

              var errDialog = null;

              switch (response.status) {
                case 500:
                case 408:
                if(!_.isEmpty(response.data)) {
                  switch (response.data.error.number) {
                    case 547:
                    errorTitle = self.name.singular + ' #'+rowID+' has related data';
                    errorMessage = 'Cannot delete the ' + self.name.singularLcase + ', it has related data. Delete the related data first to delete the ' + self.name.singularLcase + '.';

                    if(!isDisableDeleteEverythingBtn) {
                      errDialog = $mdDialog.confirm()
                      .cancel('I understand. Delete everything!');
                    } else {
                      errDialog = $mdDialog.alert();
                    }
                    break;
                  }
                }
                break;
              }

              if(_.isEmpty(errDialog)) {
                errDialog = $mdDialog.alert();
              }

              $mdDialog.show(
                errDialog.title(errorTitle)
                .ariaLabel(errorTitle)
                .textContent(errorMessage)
                .ok('Ok')
              ).then(function() {
                // Ignore if clicked on ok.
              }, function() {
                // Call deleteRelated function if available
                // to delete the related data
                if(_.isFunction(self.deleteRelated)) {
                  self.deleteRelated(row);
                } else {
                  // console.log('deleteRelated fn not found');
                }
              });
            });
          }, function() {
            //
          });
        };


        selfService.statusUpdate = function (event, row) {
            event.stopPropagation(); // in case autoselect is enabled
            var self = this;
            var modelName = self.modelName;
            var statusText = row.active ? 'Deactivate' : 'Activate';

            $mdDialog.show(
                $mdDialog.confirm()
                .clickOutsideToClose(true)
                .title(statusText + ' ' + self.name.singularLcase)
                .textContent('Are you sure you want to ' + statusText + ' ' + self.name.singularLcase)
                .ariaLabel(statusText + ' ' + self.name.singularLcase)
                .ok('Yes')
                .cancel('No')
                .targetEvent(event)
            ).then(function () {
                var whereFilter = {};

                var saveData = {
                    active: row.active ? false : true
                };

                if($rootScope.employee) {
                  saveData.modified = new Date();
                  saveData.modified_by = $rootScope.employee.cwid;
                }

                if(_.isFunction(self.editWhereFilter)) {
                  whereFilter = self.editWhereFilter(row, 'active', whereFilter);
                }

                self.promise = Restangular.one(self.modelName).customPOST(saveData, 'update', whereFilter, {})
                .then(function(response) {
                    // Delete success
                    self.clearRowSelection();
                    self.reloadTableData();
                    $mdToast.show(
                        $mdToast.simple()
                        .position($rootScope.mdToastPosition)
                        .textContent('Selected ' + self.name.singularLcase + ' record updated')
                        .hideDelay(3000)
                        .action('x')
                    );
                },
                function (response) {
                    // Error
                    selfService.defaultErrorHandling(response);
                });
            }, function () {
                //
            });
        };

        selfService.deleteSelected = function (event, rows, opts) {
            event.stopPropagation(); // in case autoselect is enabled

            rows = rows || {};
            opts = opts || {};
            var self = opts.self || this;
            var modelName = opts.modelNameSingular || self.modelNameSingular;
            var postTextContent = opts.postTextContent || '';
            var isReloadTableData = (_.isUndefined(opts.isReloadTableData)) ? true : opts.isReloadTableData;

            $mdDialog.show(
                $mdDialog.confirm()
                .clickOutsideToClose(true)
                .title('Delete selected ' + rows.length + ' ' + self.name.singularLcase + '(s)')
                .textContent('Are you sure you want to delete ' + rows.length + ' ' + self.name.singularLcase + '(s)' + postTextContent)
                .ariaLabel('Delete selected ' + rows.length + ' ' + self.name.singularLcase + '(s)')
                .ok('Yes')
                .cancel('No')
                .targetEvent(event)
            ).then(function () {
                // console.log(rows);

                var queryParams = {
                    where: {
                        id: {
                            inq: _.map(rows, 'id')
                        }
                    },
                    modelName: modelName
                };

                self.promise = Restangular.one('deleteAll').customPOST(queryParams);
                self.promise.then(function () {
                    // Delete success
                    self.clearRowSelection();

                    if (isReloadTableData) {
                        self.reloadTableData();
                    }

                    // Call callback function afterDeleteSelected after
                    // successful delete
                    if (_.isFunction(self.afterDeleteSelected)) {
                        self.afterDeleteSelected();
                    }

                    // $mdDialog.show(
                    //     $mdDialog.alert()
                    //         .title('Selected ' + self.name.singularLcase + ' records deleted')
                    //         .ariaLabel('Selected ' + self.name.singularLcase + ' records deleted')
                    //         .ok('Ok')
                    // );

                    $mdToast.show(
                        $mdToast.simple()
                        .position($rootScope.mdToastPosition)
                        .textContent('Selected ' + self.name.singularLcase + ' records deleted')
                        .hideDelay(3000)
                        .action('x')
                    );
                },
                    function (response) { });
            }, function () {
                //
            });
        };

        selfService.duplicateRow = function(event, row) {
            var self = this;
            event.stopPropagation(); // in case autoselect is enabled

            var dupRow = angular.copy(row);
            delete dupRow.id;

            if(dupRow.CREATED_DATE) {
                dupRow.CREATED_DATE = new Date();
                dupRow.CHANGED_DATE = new Date();
            }

            if(dupRow.CREATED_USER) {
                dupRow.CREATED_USER = $rootScope.employee.CWID;
                dupRow.CHANGED_USER = $rootScope.employee.CWID;
            }
            console.log(dupRow);
            var duplicateRowRest = Restangular.all(self.modelName);
            var saveRequest = duplicateRowRest.customPOST(dupRow);
            saveRequest.then(function(response) {
                self.reloadTableData();

                // $mdDialog.show(
                //     $mdDialog.alert()
                //         .title(self.name.singular + ' duplicated!')
                //         .ariaLabel(self.name.singular + ' duplicated')
                //         .textContent('#' + row.id + ' ' + self.name.singularLcase + ' is duplicated, with new ' + self.name.singularLcase + ' ID: #' + response.id)
                //         .ok('Ok')
                // );

                $mdToast.show(
                    $mdToast.simple()
                    .position($rootScope.mdToastPosition)
                    .textContent('#' + row.id + ' ' + self.name.singularLcase + ' is duplicated, with new ' + self.name.singularLcase + ' ID: #' + response.id)
                    .hideDelay(3000)
                    .action('x')
                );

            }, function(response) {
                var errorTitle, errorMessage;
                errorTitle = 'Something\'s wrong';
                errorMessage = 'Oops something got wrong, cannot complete your request.';

                switch (response.status) {
                    case 500:

                    break;
                }

                $mdDialog.show(
                    $mdDialog.alert()
                    .title(errorTitle)
                    .ariaLabel(errorTitle)
                    .textContent(errorMessage)
                    .ok('Ok')
                );
            });
        };

        selfService.defaultErrorHandling = function(response) {
            var self = this;

            var errorTitle, errorMessage;
            errorTitle = 'Something\'s wrong';
            errorMessage = 'Oops something got wrong, cannot complete your request.';

            switch (response.status) {
                case 403:
                errorTitle = 'Invalid user session';
                errorMessage = 'Please relogin into the application';
                break;
                case 404:
                errorTitle = 'Server down';
                errorMessage = 'We are not able to contact the server, please try again later';
                break;
                case 408:
                switch (response.data.error.number) {
                    case 2601:
                    errorTitle = 'Cannot create duplicate record';
                    errorMessage = 'Cannot create a duplicate record having same data';
                    break;

                    default:
                    errorMessage = 'Error message: ' + response.data.error.message + '. ' +
                    'Response status: ' + response.status;
                    break;
                }
                break;
                case 500:
                if (response.data.message) {
                  errorMessage = response.data.message + '. Response status: ' + response.status;
                } else {
                  if(!_.isArray(response.data)){
                     var errorMessages = response.data;
                  }else{
                      var errorMessages = _.map(response.data[0], 'message');
                      errorMessage = errorMessages.join('; ');
                  }
                }
                break;
            }

            $mdDialog.show(
                $mdDialog.alert()
                .title(errorTitle)
                .ariaLabel(errorTitle)
                .textContent(errorMessage)
                .ok('Ok')
            );
        };

        // Pagination
        selfService.toggleLimitOptions = function () {
            var self = this;
            self.limitOptions = self.limitOptions ? undefined : [10, 20, 50];
            //self.limitOptions = self.limitOptions ? undefined : [5, 10, 15];
        };

        selfService.logOrder = function (order) {
            var self = this;

            // console.log('order: ', order);
        };

        selfService.logPagination = function (page, limit) {
            var self = this;

            // console.log('page: ', page);
            // console.log('limit: ', limit);
        };

        selfService.exportToExcel = function (event, data, self) {
            if (_.isUndefined(self)) {
                self = this;
            }

            // Convert date string values to Date object
            _.each(data, function (row) {
                _.each(row, function (value, col) {
                    if (
                        value &&
                        _.isString(value) &&
                        moment(value.substr(0, value.length - 4), 'YYYY-MM-DDTHH:mm:ss', true).isValid()
                    ) {
                        row[col] = new Date(value);
                    }
                });
            });

            /* generate a worksheet */
            var ws = XLSX.utils.json_to_sheet(data);

            ws['!autofilter'] = { ref: ws['!ref'] };

            /* add to workbook */
            var wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, self.modelName);

            /* write workbook and force a download */
            XLSX.writeFile(wb, self.name.plural + '_' + moment().format('YYYY-MM-DD HH:mm') + '.xlsx');
        };

        selfService.getName = function (Cwid) {
            if (_.isEmpty(Cwid)) {
                return '';
            }

            var users = $rootScope.appUsers;

            if (_.isUndefined(users[Cwid])) {
                return '';
            }

            return users[Cwid].FirstName + ' ' + users[Cwid].LastName;
        };

        selfService.getFullName = function (Cwid) {
            if (_.isEmpty(Cwid)) {
                return '';
            }

            var users = $rootScope.appUsers;

            if (_.isUndefined(users[Cwid])) {
                return Cwid;
            }

            return selfService.getName(Cwid) + ' (' + Cwid + ')';
        };

        selfService.showFullName = function (row, key) {
            return row[key + 'Full'];
        };
    }
]);
