// CommonJS package manager support
if (typeof module !== 'undefined' && typeof exports !== 'undefined' &&
  module.exports === exports) {
  // Export the *name* of this Angular module
  // Sample usage:
  //
  //   import lbServices from './lb-services';
  //   angular.module('app', [lbServices]);
  //
  module.exports = "lbServices";
}

(function(window, angular, undefined) {
  'use strict';

  var urlBase = "/api";
  var authHeader = 'authorization';

  function getHost(url) {
    var m = url.match(/^(?:https?:)?\/\/([^\/]+)/);
    return m ? m[1] : null;
  }

  var urlBaseHost = getHost(urlBase) || location.host;

/**
 * @ngdoc overview
 * @name lbServices
 * @module
 * @description
 *
 * The `lbServices` module provides services for interacting with
 * the models exposed by the LoopBack server via the REST API.
 *
 */
  var module = angular.module("lbServices", ['ngResource']);

/**
 * @ngdoc object
 * @name lbServices.UserIdentity
 * @header lbServices.UserIdentity
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `UserIdentity` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "UserIdentity",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/UserIdentities/:id",
          { 'id': '@id' },
          {

            // INTERNAL. Use UserIdentity.user() instead.
            "prototype$__get__user": {
              url: urlBase + "/UserIdentities/:id/user",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#create
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/UserIdentities",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#createMany
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/UserIdentities",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#upsert
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
            "upsert": {
              url: urlBase + "/UserIdentities",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#replaceOrCreate
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/UserIdentities/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#upsertWithWhere
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/UserIdentities/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#exists
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/UserIdentities/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#findById
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/UserIdentities/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#replaceById
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/UserIdentities/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#find
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/UserIdentities",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#findOne
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/UserIdentities/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#updateAll
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
            "updateAll": {
              url: urlBase + "/UserIdentities/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#deleteById
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/UserIdentities/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#count
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/UserIdentities/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#prototype$updateAttributes
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
            "prototype$updateAttributes": {
              url: urlBase + "/UserIdentities/:id",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#createChangeStream
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/UserIdentities/change-stream",
              method: "POST",
            },

            // INTERNAL. Use User.identities.findById() instead.
            "::findById::User::identities": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/users/:id/identities/:fk",
              method: "GET",
            },

            // INTERNAL. Use User.identities.destroyById() instead.
            "::destroyById::User::identities": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/users/:id/identities/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use User.identities.updateById() instead.
            "::updateById::User::identities": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/users/:id/identities/:fk",
              method: "PUT",
            },

            // INTERNAL. Use User.identities() instead.
            "::get::User::identities": {
              isArray: true,
              url: urlBase + "/users/:id/identities",
              method: "GET",
            },

            // INTERNAL. Use User.identities.create() instead.
            "::create::User::identities": {
              url: urlBase + "/users/:id/identities",
              method: "POST",
            },

            // INTERNAL. Use User.identities.createMany() instead.
            "::createMany::User::identities": {
              isArray: true,
              url: urlBase + "/users/:id/identities",
              method: "POST",
            },

            // INTERNAL. Use User.identities.destroyAll() instead.
            "::delete::User::identities": {
              url: urlBase + "/users/:id/identities",
              method: "DELETE",
            },

            // INTERNAL. Use User.identities.count() instead.
            "::count::User::identities": {
              url: urlBase + "/users/:id/identities/count",
              method: "GET",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#patchOrCreate
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
        R["patchOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#updateOrCreate
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
        R["updateOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#patchOrCreateWithWhere
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#update
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#destroyById
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#removeById
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#patchAttributes
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
        R["patchAttributes"] = R["prototype$updateAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.UserIdentity#modelName
        * @propertyOf lbServices.UserIdentity
        * @description
        * The name of the model represented by this $resource,
        * i.e. `UserIdentity`.
        */
        R.modelName = "UserIdentity";


            /**
             * @ngdoc method
             * @name lbServices.UserIdentity#user
             * @methodOf lbServices.UserIdentity
             *
             * @description
             *
             * Fetches belongsTo relation user.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `refresh` – `{boolean=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
        R.user = function() {
          var TargetResource = $injector.get("User");
          var action = TargetResource["::get::UserIdentity::user"];
          return action.apply(R, arguments);
        };


        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.UserCredential
 * @header lbServices.UserCredential
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `UserCredential` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "UserCredential",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/UserCredentials/:id",
          { 'id': '@id' },
          {

            // INTERNAL. Use UserCredential.user() instead.
            "prototype$__get__user": {
              url: urlBase + "/UserCredentials/:id/user",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserCredential#create
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/UserCredentials",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserCredential#createMany
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/UserCredentials",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserCredential#upsert
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
            "upsert": {
              url: urlBase + "/UserCredentials",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserCredential#replaceOrCreate
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/UserCredentials/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserCredential#upsertWithWhere
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/UserCredentials/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserCredential#exists
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/UserCredentials/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserCredential#findById
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/UserCredentials/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserCredential#replaceById
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/UserCredentials/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserCredential#find
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/UserCredentials",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserCredential#findOne
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/UserCredentials/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserCredential#updateAll
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
            "updateAll": {
              url: urlBase + "/UserCredentials/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserCredential#deleteById
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/UserCredentials/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserCredential#count
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/UserCredentials/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserCredential#prototype$updateAttributes
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
            "prototype$updateAttributes": {
              url: urlBase + "/UserCredentials/:id",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.UserCredential#createChangeStream
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/UserCredentials/change-stream",
              method: "POST",
            },

            // INTERNAL. Use User.credentials.findById() instead.
            "::findById::User::credentials": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/users/:id/credentials/:fk",
              method: "GET",
            },

            // INTERNAL. Use User.credentials.destroyById() instead.
            "::destroyById::User::credentials": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/users/:id/credentials/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use User.credentials.updateById() instead.
            "::updateById::User::credentials": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/users/:id/credentials/:fk",
              method: "PUT",
            },

            // INTERNAL. Use User.credentials() instead.
            "::get::User::credentials": {
              isArray: true,
              url: urlBase + "/users/:id/credentials",
              method: "GET",
            },

            // INTERNAL. Use User.credentials.create() instead.
            "::create::User::credentials": {
              url: urlBase + "/users/:id/credentials",
              method: "POST",
            },

            // INTERNAL. Use User.credentials.createMany() instead.
            "::createMany::User::credentials": {
              isArray: true,
              url: urlBase + "/users/:id/credentials",
              method: "POST",
            },

            // INTERNAL. Use User.credentials.destroyAll() instead.
            "::delete::User::credentials": {
              url: urlBase + "/users/:id/credentials",
              method: "DELETE",
            },

            // INTERNAL. Use User.credentials.count() instead.
            "::count::User::credentials": {
              url: urlBase + "/users/:id/credentials/count",
              method: "GET",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.UserCredential#patchOrCreate
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
        R["patchOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.UserCredential#updateOrCreate
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
        R["updateOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.UserCredential#patchOrCreateWithWhere
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.UserCredential#update
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.UserCredential#destroyById
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.UserCredential#removeById
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.UserCredential#patchAttributes
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
        R["patchAttributes"] = R["prototype$updateAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.UserCredential#modelName
        * @propertyOf lbServices.UserCredential
        * @description
        * The name of the model represented by this $resource,
        * i.e. `UserCredential`.
        */
        R.modelName = "UserCredential";


            /**
             * @ngdoc method
             * @name lbServices.UserCredential#user
             * @methodOf lbServices.UserCredential
             *
             * @description
             *
             * Fetches belongsTo relation user.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `refresh` – `{boolean=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
        R.user = function() {
          var TargetResource = $injector.get("User");
          var action = TargetResource["::get::UserCredential::user"];
          return action.apply(R, arguments);
        };


        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.TM_ORG_MODEL_COUNTRY
 * @header lbServices.TM_ORG_MODEL_COUNTRY
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `TM_ORG_MODEL_COUNTRY` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "TM_ORG_MODEL_COUNTRY",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/TM_ORG_MODEL_COUNTRIES/:id",
          { 'id': '@id' },
          {

            // INTERNAL. Use TM_ORG_MODEL_COUNTRY.divisions.findById() instead.
            "prototype$__findById__divisions": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/:id/divisions/:fk",
              method: "GET",
            },

            // INTERNAL. Use TM_ORG_MODEL_COUNTRY.divisions.destroyById() instead.
            "prototype$__destroyById__divisions": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/:id/divisions/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ORG_MODEL_COUNTRY.divisions.updateById() instead.
            "prototype$__updateById__divisions": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/:id/divisions/:fk",
              method: "PUT",
            },

            // INTERNAL. Use TM_ORG_MODEL_COUNTRY.divisions() instead.
            "prototype$__get__divisions": {
              isArray: true,
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/:id/divisions",
              method: "GET",
            },

            // INTERNAL. Use TM_ORG_MODEL_COUNTRY.divisions.create() instead.
            "prototype$__create__divisions": {
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/:id/divisions",
              method: "POST",
            },

            // INTERNAL. Use TM_ORG_MODEL_COUNTRY.divisions.destroyAll() instead.
            "prototype$__delete__divisions": {
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/:id/divisions",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ORG_MODEL_COUNTRY.divisions.count() instead.
            "prototype$__count__divisions": {
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/:id/divisions/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#create
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_COUNTRY` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#createMany
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_COUNTRY` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#upsert
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_COUNTRY` object.)
             * </em>
             */
            "upsert": {
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#replaceOrCreate
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_COUNTRY` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#upsertWithWhere
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_COUNTRY` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#exists
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#findById
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_COUNTRY` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#replaceById
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_COUNTRY` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#find
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_COUNTRY` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#findOne
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_COUNTRY` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#updateAll
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
            "updateAll": {
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#deleteById
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_COUNTRY` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#count
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#prototype$updateAttributes
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_COUNTRY` object.)
             * </em>
             */
            "prototype$updateAttributes": {
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/:id",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#createChangeStream
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/change-stream",
              method: "POST",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#patchOrCreate
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_COUNTRY` object.)
             * </em>
             */
        R["patchOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#updateOrCreate
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_COUNTRY` object.)
             * </em>
             */
        R["updateOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#patchOrCreateWithWhere
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_COUNTRY` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#update
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#destroyById
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_COUNTRY` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#removeById
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_COUNTRY` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#patchAttributes
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_COUNTRY` object.)
             * </em>
             */
        R["patchAttributes"] = R["prototype$updateAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.TM_ORG_MODEL_COUNTRY#modelName
        * @propertyOf lbServices.TM_ORG_MODEL_COUNTRY
        * @description
        * The name of the model represented by this $resource,
        * i.e. `TM_ORG_MODEL_COUNTRY`.
        */
        R.modelName = "TM_ORG_MODEL_COUNTRY";

    /**
     * @ngdoc object
     * @name lbServices.TM_ORG_MODEL_COUNTRY.divisions
     * @header lbServices.TM_ORG_MODEL_COUNTRY.divisions
     * @object
     * @description
     *
     * The object `TM_ORG_MODEL_COUNTRY.divisions` groups methods
     * manipulating `TM_ORG_MODEL_DIVISION` instances related to `TM_ORG_MODEL_COUNTRY`.
     *
     * Call {@link lbServices.TM_ORG_MODEL_COUNTRY#divisions TM_ORG_MODEL_COUNTRY.divisions()}
     * to query all related instances.
     */


            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY#divisions
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY
             *
             * @description
             *
             * Queries divisions of TM_ORG_MODEL_COUNTRY.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `filter` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
        R.divisions = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_DIVISION");
          var action = TargetResource["::get::TM_ORG_MODEL_COUNTRY::divisions"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY.divisions#count
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY.divisions
             *
             * @description
             *
             * Counts divisions of TM_ORG_MODEL_COUNTRY.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
        R.divisions.count = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_DIVISION");
          var action = TargetResource["::count::TM_ORG_MODEL_COUNTRY::divisions"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY.divisions#create
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY.divisions
             *
             * @description
             *
             * Creates a new instance in divisions of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
        R.divisions.create = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_DIVISION");
          var action = TargetResource["::create::TM_ORG_MODEL_COUNTRY::divisions"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY.divisions#createMany
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY.divisions
             *
             * @description
             *
             * Creates a new instance in divisions of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
        R.divisions.createMany = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_DIVISION");
          var action = TargetResource["::createMany::TM_ORG_MODEL_COUNTRY::divisions"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY.divisions#destroyAll
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY.divisions
             *
             * @description
             *
             * Deletes all divisions of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.divisions.destroyAll = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_DIVISION");
          var action = TargetResource["::delete::TM_ORG_MODEL_COUNTRY::divisions"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY.divisions#destroyById
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY.divisions
             *
             * @description
             *
             * Delete a related item by id for divisions.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for divisions
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.divisions.destroyById = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_DIVISION");
          var action = TargetResource["::destroyById::TM_ORG_MODEL_COUNTRY::divisions"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY.divisions#findById
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY.divisions
             *
             * @description
             *
             * Find a related item by id for divisions.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for divisions
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
        R.divisions.findById = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_DIVISION");
          var action = TargetResource["::findById::TM_ORG_MODEL_COUNTRY::divisions"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_COUNTRY.divisions#updateById
             * @methodOf lbServices.TM_ORG_MODEL_COUNTRY.divisions
             *
             * @description
             *
             * Update a related item by id for divisions.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for divisions
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
        R.divisions.updateById = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_DIVISION");
          var action = TargetResource["::updateById::TM_ORG_MODEL_COUNTRY::divisions"];
          return action.apply(R, arguments);
        };


        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.TM_ORG_MODEL_DIVISION
 * @header lbServices.TM_ORG_MODEL_DIVISION
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `TM_ORG_MODEL_DIVISION` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "TM_ORG_MODEL_DIVISION",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/TM_ORG_MODEL_DIVISIONS/:id",
          { 'id': '@id' },
          {

            // INTERNAL. Use TM_ORG_MODEL_DIVISION.businessunits.findById() instead.
            "prototype$__findById__businessunits": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/:id/businessunits/:fk",
              method: "GET",
            },

            // INTERNAL. Use TM_ORG_MODEL_DIVISION.businessunits.destroyById() instead.
            "prototype$__destroyById__businessunits": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/:id/businessunits/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ORG_MODEL_DIVISION.businessunits.updateById() instead.
            "prototype$__updateById__businessunits": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/:id/businessunits/:fk",
              method: "PUT",
            },

            // INTERNAL. Use TM_ORG_MODEL_DIVISION.businessunits() instead.
            "prototype$__get__businessunits": {
              isArray: true,
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/:id/businessunits",
              method: "GET",
            },

            // INTERNAL. Use TM_ORG_MODEL_DIVISION.businessunits.create() instead.
            "prototype$__create__businessunits": {
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/:id/businessunits",
              method: "POST",
            },

            // INTERNAL. Use TM_ORG_MODEL_DIVISION.businessunits.destroyAll() instead.
            "prototype$__delete__businessunits": {
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/:id/businessunits",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ORG_MODEL_DIVISION.businessunits.count() instead.
            "prototype$__count__businessunits": {
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/:id/businessunits/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#create
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#createMany
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#upsert
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
            "upsert": {
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#replaceOrCreate
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#upsertWithWhere
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#exists
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#findById
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#replaceById
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#find
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#findOne
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#updateAll
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
            "updateAll": {
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#deleteById
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#count
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#prototype$updateAttributes
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
            "prototype$updateAttributes": {
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/:id",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#createChangeStream
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/change-stream",
              method: "POST",
            },

            // INTERNAL. Use TM_ORG_MODEL_COUNTRY.divisions.findById() instead.
            "::findById::TM_ORG_MODEL_COUNTRY::divisions": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/:id/divisions/:fk",
              method: "GET",
            },

            // INTERNAL. Use TM_ORG_MODEL_COUNTRY.divisions.destroyById() instead.
            "::destroyById::TM_ORG_MODEL_COUNTRY::divisions": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/:id/divisions/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ORG_MODEL_COUNTRY.divisions.updateById() instead.
            "::updateById::TM_ORG_MODEL_COUNTRY::divisions": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/:id/divisions/:fk",
              method: "PUT",
            },

            // INTERNAL. Use TM_ORG_MODEL_COUNTRY.divisions() instead.
            "::get::TM_ORG_MODEL_COUNTRY::divisions": {
              isArray: true,
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/:id/divisions",
              method: "GET",
            },

            // INTERNAL. Use TM_ORG_MODEL_COUNTRY.divisions.create() instead.
            "::create::TM_ORG_MODEL_COUNTRY::divisions": {
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/:id/divisions",
              method: "POST",
            },

            // INTERNAL. Use TM_ORG_MODEL_COUNTRY.divisions.createMany() instead.
            "::createMany::TM_ORG_MODEL_COUNTRY::divisions": {
              isArray: true,
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/:id/divisions",
              method: "POST",
            },

            // INTERNAL. Use TM_ORG_MODEL_COUNTRY.divisions.destroyAll() instead.
            "::delete::TM_ORG_MODEL_COUNTRY::divisions": {
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/:id/divisions",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ORG_MODEL_COUNTRY.divisions.count() instead.
            "::count::TM_ORG_MODEL_COUNTRY::divisions": {
              url: urlBase + "/TM_ORG_MODEL_COUNTRIES/:id/divisions/count",
              method: "GET",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#patchOrCreate
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
        R["patchOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#updateOrCreate
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
        R["updateOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#patchOrCreateWithWhere
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#update
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#destroyById
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#removeById
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#patchAttributes
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_DIVISION` object.)
             * </em>
             */
        R["patchAttributes"] = R["prototype$updateAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.TM_ORG_MODEL_DIVISION#modelName
        * @propertyOf lbServices.TM_ORG_MODEL_DIVISION
        * @description
        * The name of the model represented by this $resource,
        * i.e. `TM_ORG_MODEL_DIVISION`.
        */
        R.modelName = "TM_ORG_MODEL_DIVISION";

    /**
     * @ngdoc object
     * @name lbServices.TM_ORG_MODEL_DIVISION.businessunits
     * @header lbServices.TM_ORG_MODEL_DIVISION.businessunits
     * @object
     * @description
     *
     * The object `TM_ORG_MODEL_DIVISION.businessunits` groups methods
     * manipulating `TM_ORG_MODEL_BU` instances related to `TM_ORG_MODEL_DIVISION`.
     *
     * Call {@link lbServices.TM_ORG_MODEL_DIVISION#businessunits TM_ORG_MODEL_DIVISION.businessunits()}
     * to query all related instances.
     */


            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION#businessunits
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION
             *
             * @description
             *
             * Queries businessunits of TM_ORG_MODEL_DIVISION.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `filter` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
        R.businessunits = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_BU");
          var action = TargetResource["::get::TM_ORG_MODEL_DIVISION::businessunits"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION.businessunits#count
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION.businessunits
             *
             * @description
             *
             * Counts businessunits of TM_ORG_MODEL_DIVISION.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
        R.businessunits.count = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_BU");
          var action = TargetResource["::count::TM_ORG_MODEL_DIVISION::businessunits"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION.businessunits#create
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION.businessunits
             *
             * @description
             *
             * Creates a new instance in businessunits of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
        R.businessunits.create = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_BU");
          var action = TargetResource["::create::TM_ORG_MODEL_DIVISION::businessunits"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION.businessunits#createMany
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION.businessunits
             *
             * @description
             *
             * Creates a new instance in businessunits of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
        R.businessunits.createMany = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_BU");
          var action = TargetResource["::createMany::TM_ORG_MODEL_DIVISION::businessunits"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION.businessunits#destroyAll
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION.businessunits
             *
             * @description
             *
             * Deletes all businessunits of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.businessunits.destroyAll = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_BU");
          var action = TargetResource["::delete::TM_ORG_MODEL_DIVISION::businessunits"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION.businessunits#destroyById
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION.businessunits
             *
             * @description
             *
             * Delete a related item by id for businessunits.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for businessunits
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.businessunits.destroyById = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_BU");
          var action = TargetResource["::destroyById::TM_ORG_MODEL_DIVISION::businessunits"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION.businessunits#findById
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION.businessunits
             *
             * @description
             *
             * Find a related item by id for businessunits.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for businessunits
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
        R.businessunits.findById = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_BU");
          var action = TargetResource["::findById::TM_ORG_MODEL_DIVISION::businessunits"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_DIVISION.businessunits#updateById
             * @methodOf lbServices.TM_ORG_MODEL_DIVISION.businessunits
             *
             * @description
             *
             * Update a related item by id for businessunits.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for businessunits
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
        R.businessunits.updateById = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_BU");
          var action = TargetResource["::updateById::TM_ORG_MODEL_DIVISION::businessunits"];
          return action.apply(R, arguments);
        };


        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.TM_ORG_MODEL_BU
 * @header lbServices.TM_ORG_MODEL_BU
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `TM_ORG_MODEL_BU` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "TM_ORG_MODEL_BU",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/TM_ORG_MODEL_BUS/:id",
          { 'id': '@id' },
          {

            // INTERNAL. Use TM_ORG_MODEL_BU.saleslines.findById() instead.
            "prototype$__findById__saleslines": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ORG_MODEL_BUS/:id/saleslines/:fk",
              method: "GET",
            },

            // INTERNAL. Use TM_ORG_MODEL_BU.saleslines.destroyById() instead.
            "prototype$__destroyById__saleslines": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ORG_MODEL_BUS/:id/saleslines/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ORG_MODEL_BU.saleslines.updateById() instead.
            "prototype$__updateById__saleslines": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ORG_MODEL_BUS/:id/saleslines/:fk",
              method: "PUT",
            },

            // INTERNAL. Use TM_ORG_MODEL_BU.saleslines() instead.
            "prototype$__get__saleslines": {
              isArray: true,
              url: urlBase + "/TM_ORG_MODEL_BUS/:id/saleslines",
              method: "GET",
            },

            // INTERNAL. Use TM_ORG_MODEL_BU.saleslines.create() instead.
            "prototype$__create__saleslines": {
              url: urlBase + "/TM_ORG_MODEL_BUS/:id/saleslines",
              method: "POST",
            },

            // INTERNAL. Use TM_ORG_MODEL_BU.saleslines.destroyAll() instead.
            "prototype$__delete__saleslines": {
              url: urlBase + "/TM_ORG_MODEL_BUS/:id/saleslines",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ORG_MODEL_BU.saleslines.count() instead.
            "prototype$__count__saleslines": {
              url: urlBase + "/TM_ORG_MODEL_BUS/:id/saleslines/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#create
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/TM_ORG_MODEL_BUS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#createMany
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/TM_ORG_MODEL_BUS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#upsert
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
            "upsert": {
              url: urlBase + "/TM_ORG_MODEL_BUS",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#replaceOrCreate
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/TM_ORG_MODEL_BUS/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#upsertWithWhere
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/TM_ORG_MODEL_BUS/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#exists
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/TM_ORG_MODEL_BUS/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#findById
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/TM_ORG_MODEL_BUS/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#replaceById
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/TM_ORG_MODEL_BUS/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#find
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/TM_ORG_MODEL_BUS",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#findOne
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/TM_ORG_MODEL_BUS/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#updateAll
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
            "updateAll": {
              url: urlBase + "/TM_ORG_MODEL_BUS/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#deleteById
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/TM_ORG_MODEL_BUS/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#count
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/TM_ORG_MODEL_BUS/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#prototype$updateAttributes
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
            "prototype$updateAttributes": {
              url: urlBase + "/TM_ORG_MODEL_BUS/:id",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#createChangeStream
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/TM_ORG_MODEL_BUS/change-stream",
              method: "POST",
            },

            // INTERNAL. Use TM_ORG_MODEL_DIVISION.businessunits.findById() instead.
            "::findById::TM_ORG_MODEL_DIVISION::businessunits": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/:id/businessunits/:fk",
              method: "GET",
            },

            // INTERNAL. Use TM_ORG_MODEL_DIVISION.businessunits.destroyById() instead.
            "::destroyById::TM_ORG_MODEL_DIVISION::businessunits": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/:id/businessunits/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ORG_MODEL_DIVISION.businessunits.updateById() instead.
            "::updateById::TM_ORG_MODEL_DIVISION::businessunits": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/:id/businessunits/:fk",
              method: "PUT",
            },

            // INTERNAL. Use TM_ORG_MODEL_DIVISION.businessunits() instead.
            "::get::TM_ORG_MODEL_DIVISION::businessunits": {
              isArray: true,
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/:id/businessunits",
              method: "GET",
            },

            // INTERNAL. Use TM_ORG_MODEL_DIVISION.businessunits.create() instead.
            "::create::TM_ORG_MODEL_DIVISION::businessunits": {
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/:id/businessunits",
              method: "POST",
            },

            // INTERNAL. Use TM_ORG_MODEL_DIVISION.businessunits.createMany() instead.
            "::createMany::TM_ORG_MODEL_DIVISION::businessunits": {
              isArray: true,
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/:id/businessunits",
              method: "POST",
            },

            // INTERNAL. Use TM_ORG_MODEL_DIVISION.businessunits.destroyAll() instead.
            "::delete::TM_ORG_MODEL_DIVISION::businessunits": {
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/:id/businessunits",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ORG_MODEL_DIVISION.businessunits.count() instead.
            "::count::TM_ORG_MODEL_DIVISION::businessunits": {
              url: urlBase + "/TM_ORG_MODEL_DIVISIONS/:id/businessunits/count",
              method: "GET",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#patchOrCreate
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
        R["patchOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#updateOrCreate
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
        R["updateOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#patchOrCreateWithWhere
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#update
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#destroyById
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#removeById
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#patchAttributes
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_BU` object.)
             * </em>
             */
        R["patchAttributes"] = R["prototype$updateAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.TM_ORG_MODEL_BU#modelName
        * @propertyOf lbServices.TM_ORG_MODEL_BU
        * @description
        * The name of the model represented by this $resource,
        * i.e. `TM_ORG_MODEL_BU`.
        */
        R.modelName = "TM_ORG_MODEL_BU";

    /**
     * @ngdoc object
     * @name lbServices.TM_ORG_MODEL_BU.saleslines
     * @header lbServices.TM_ORG_MODEL_BU.saleslines
     * @object
     * @description
     *
     * The object `TM_ORG_MODEL_BU.saleslines` groups methods
     * manipulating `TM_ORG_MODEL_SL` instances related to `TM_ORG_MODEL_BU`.
     *
     * Call {@link lbServices.TM_ORG_MODEL_BU#saleslines TM_ORG_MODEL_BU.saleslines()}
     * to query all related instances.
     */


            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU#saleslines
             * @methodOf lbServices.TM_ORG_MODEL_BU
             *
             * @description
             *
             * Queries saleslines of TM_ORG_MODEL_BU.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `filter` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
        R.saleslines = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_SL");
          var action = TargetResource["::get::TM_ORG_MODEL_BU::saleslines"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU.saleslines#count
             * @methodOf lbServices.TM_ORG_MODEL_BU.saleslines
             *
             * @description
             *
             * Counts saleslines of TM_ORG_MODEL_BU.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
        R.saleslines.count = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_SL");
          var action = TargetResource["::count::TM_ORG_MODEL_BU::saleslines"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU.saleslines#create
             * @methodOf lbServices.TM_ORG_MODEL_BU.saleslines
             *
             * @description
             *
             * Creates a new instance in saleslines of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
        R.saleslines.create = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_SL");
          var action = TargetResource["::create::TM_ORG_MODEL_BU::saleslines"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU.saleslines#createMany
             * @methodOf lbServices.TM_ORG_MODEL_BU.saleslines
             *
             * @description
             *
             * Creates a new instance in saleslines of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
        R.saleslines.createMany = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_SL");
          var action = TargetResource["::createMany::TM_ORG_MODEL_BU::saleslines"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU.saleslines#destroyAll
             * @methodOf lbServices.TM_ORG_MODEL_BU.saleslines
             *
             * @description
             *
             * Deletes all saleslines of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.saleslines.destroyAll = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_SL");
          var action = TargetResource["::delete::TM_ORG_MODEL_BU::saleslines"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU.saleslines#destroyById
             * @methodOf lbServices.TM_ORG_MODEL_BU.saleslines
             *
             * @description
             *
             * Delete a related item by id for saleslines.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for saleslines
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.saleslines.destroyById = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_SL");
          var action = TargetResource["::destroyById::TM_ORG_MODEL_BU::saleslines"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU.saleslines#findById
             * @methodOf lbServices.TM_ORG_MODEL_BU.saleslines
             *
             * @description
             *
             * Find a related item by id for saleslines.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for saleslines
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
        R.saleslines.findById = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_SL");
          var action = TargetResource["::findById::TM_ORG_MODEL_BU::saleslines"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_BU.saleslines#updateById
             * @methodOf lbServices.TM_ORG_MODEL_BU.saleslines
             *
             * @description
             *
             * Update a related item by id for saleslines.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for saleslines
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
        R.saleslines.updateById = function() {
          var TargetResource = $injector.get("TM_ORG_MODEL_SL");
          var action = TargetResource["::updateById::TM_ORG_MODEL_BU::saleslines"];
          return action.apply(R, arguments);
        };


        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.TM_ORG_MODEL_SL
 * @header lbServices.TM_ORG_MODEL_SL
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `TM_ORG_MODEL_SL` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "TM_ORG_MODEL_SL",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/TM_ORG_MODEL_SLS/:id",
          { 'id': '@id' },
          {

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#create
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/TM_ORG_MODEL_SLS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#createMany
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/TM_ORG_MODEL_SLS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#upsert
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
            "upsert": {
              url: urlBase + "/TM_ORG_MODEL_SLS",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#replaceOrCreate
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/TM_ORG_MODEL_SLS/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#upsertWithWhere
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/TM_ORG_MODEL_SLS/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#exists
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/TM_ORG_MODEL_SLS/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#findById
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/TM_ORG_MODEL_SLS/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#replaceById
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/TM_ORG_MODEL_SLS/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#find
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/TM_ORG_MODEL_SLS",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#findOne
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/TM_ORG_MODEL_SLS/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#updateAll
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
            "updateAll": {
              url: urlBase + "/TM_ORG_MODEL_SLS/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#deleteById
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/TM_ORG_MODEL_SLS/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#count
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/TM_ORG_MODEL_SLS/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#prototype$updateAttributes
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
            "prototype$updateAttributes": {
              url: urlBase + "/TM_ORG_MODEL_SLS/:id",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#createChangeStream
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/TM_ORG_MODEL_SLS/change-stream",
              method: "POST",
            },

            // INTERNAL. Use TM_ORG_MODEL_BU.saleslines.findById() instead.
            "::findById::TM_ORG_MODEL_BU::saleslines": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ORG_MODEL_BUS/:id/saleslines/:fk",
              method: "GET",
            },

            // INTERNAL. Use TM_ORG_MODEL_BU.saleslines.destroyById() instead.
            "::destroyById::TM_ORG_MODEL_BU::saleslines": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ORG_MODEL_BUS/:id/saleslines/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ORG_MODEL_BU.saleslines.updateById() instead.
            "::updateById::TM_ORG_MODEL_BU::saleslines": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ORG_MODEL_BUS/:id/saleslines/:fk",
              method: "PUT",
            },

            // INTERNAL. Use TM_ORG_MODEL_BU.saleslines() instead.
            "::get::TM_ORG_MODEL_BU::saleslines": {
              isArray: true,
              url: urlBase + "/TM_ORG_MODEL_BUS/:id/saleslines",
              method: "GET",
            },

            // INTERNAL. Use TM_ORG_MODEL_BU.saleslines.create() instead.
            "::create::TM_ORG_MODEL_BU::saleslines": {
              url: urlBase + "/TM_ORG_MODEL_BUS/:id/saleslines",
              method: "POST",
            },

            // INTERNAL. Use TM_ORG_MODEL_BU.saleslines.createMany() instead.
            "::createMany::TM_ORG_MODEL_BU::saleslines": {
              isArray: true,
              url: urlBase + "/TM_ORG_MODEL_BUS/:id/saleslines",
              method: "POST",
            },

            // INTERNAL. Use TM_ORG_MODEL_BU.saleslines.destroyAll() instead.
            "::delete::TM_ORG_MODEL_BU::saleslines": {
              url: urlBase + "/TM_ORG_MODEL_BUS/:id/saleslines",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ORG_MODEL_BU.saleslines.count() instead.
            "::count::TM_ORG_MODEL_BU::saleslines": {
              url: urlBase + "/TM_ORG_MODEL_BUS/:id/saleslines/count",
              method: "GET",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#patchOrCreate
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
        R["patchOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#updateOrCreate
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
        R["updateOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#patchOrCreateWithWhere
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#update
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#destroyById
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#removeById
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ORG_MODEL_SL#patchAttributes
             * @methodOf lbServices.TM_ORG_MODEL_SL
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ORG_MODEL_SL` object.)
             * </em>
             */
        R["patchAttributes"] = R["prototype$updateAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.TM_ORG_MODEL_SL#modelName
        * @propertyOf lbServices.TM_ORG_MODEL_SL
        * @description
        * The name of the model represented by this $resource,
        * i.e. `TM_ORG_MODEL_SL`.
        */
        R.modelName = "TM_ORG_MODEL_SL";



        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.TM_ASSIGNM_RULE
 * @header lbServices.TM_ASSIGNM_RULE
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `TM_ASSIGNM_RULE` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "TM_ASSIGNM_RULE",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/TM_ASSIGNM_RULES/:id",
          { 'id': '@id' },
          {

            // INTERNAL. Use TM_ASSIGNM_RULE.criterias.findById() instead.
            "prototype$__findById__criterias": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ASSIGNM_RULES/:id/criterias/:fk",
              method: "GET",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.criterias.destroyById() instead.
            "prototype$__destroyById__criterias": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ASSIGNM_RULES/:id/criterias/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.criterias.updateById() instead.
            "prototype$__updateById__criterias": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ASSIGNM_RULES/:id/criterias/:fk",
              method: "PUT",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.geoCriterias.findById() instead.
            "prototype$__findById__geoCriterias": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ASSIGNM_RULES/:id/geoCriterias/:fk",
              method: "GET",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.geoCriterias.destroyById() instead.
            "prototype$__destroyById__geoCriterias": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ASSIGNM_RULES/:id/geoCriterias/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.geoCriterias.updateById() instead.
            "prototype$__updateById__geoCriterias": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ASSIGNM_RULES/:id/geoCriterias/:fk",
              method: "PUT",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.criterias() instead.
            "prototype$__get__criterias": {
              isArray: true,
              url: urlBase + "/TM_ASSIGNM_RULES/:id/criterias",
              method: "GET",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.criterias.create() instead.
            "prototype$__create__criterias": {
              url: urlBase + "/TM_ASSIGNM_RULES/:id/criterias",
              method: "POST",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.criterias.destroyAll() instead.
            "prototype$__delete__criterias": {
              url: urlBase + "/TM_ASSIGNM_RULES/:id/criterias",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.criterias.count() instead.
            "prototype$__count__criterias": {
              url: urlBase + "/TM_ASSIGNM_RULES/:id/criterias/count",
              method: "GET",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.geoCriterias() instead.
            "prototype$__get__geoCriterias": {
              isArray: true,
              url: urlBase + "/TM_ASSIGNM_RULES/:id/geoCriterias",
              method: "GET",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.geoCriterias.create() instead.
            "prototype$__create__geoCriterias": {
              url: urlBase + "/TM_ASSIGNM_RULES/:id/geoCriterias",
              method: "POST",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.geoCriterias.destroyAll() instead.
            "prototype$__delete__geoCriterias": {
              url: urlBase + "/TM_ASSIGNM_RULES/:id/geoCriterias",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.geoCriterias.count() instead.
            "prototype$__count__geoCriterias": {
              url: urlBase + "/TM_ASSIGNM_RULES/:id/geoCriterias/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#create
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/TM_ASSIGNM_RULES",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#createMany
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/TM_ASSIGNM_RULES",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#upsert
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE` object.)
             * </em>
             */
            "upsert": {
              url: urlBase + "/TM_ASSIGNM_RULES",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#replaceOrCreate
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/TM_ASSIGNM_RULES/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#upsertWithWhere
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/TM_ASSIGNM_RULES/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#exists
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/TM_ASSIGNM_RULES/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#findById
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/TM_ASSIGNM_RULES/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#replaceById
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/TM_ASSIGNM_RULES/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#find
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/TM_ASSIGNM_RULES",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#findOne
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/TM_ASSIGNM_RULES/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#updateAll
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
            "updateAll": {
              url: urlBase + "/TM_ASSIGNM_RULES/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#deleteById
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/TM_ASSIGNM_RULES/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#count
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/TM_ASSIGNM_RULES/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#prototype$updateAttributes
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE` object.)
             * </em>
             */
            "prototype$updateAttributes": {
              url: urlBase + "/TM_ASSIGNM_RULES/:id",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#createChangeStream
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/TM_ASSIGNM_RULES/change-stream",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#deepClone
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * <em>
             * (The remote method definition does not provide any description.)
             * </em>
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `id` – `{number}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE` object.)
             * </em>
             */
            "deepClone": {
              url: urlBase + "/TM_ASSIGNM_RULES/deepClone",
              method: "POST",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#patchOrCreate
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE` object.)
             * </em>
             */
        R["patchOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#updateOrCreate
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE` object.)
             * </em>
             */
        R["updateOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#patchOrCreateWithWhere
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#update
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#destroyById
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#removeById
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#patchAttributes
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE` object.)
             * </em>
             */
        R["patchAttributes"] = R["prototype$updateAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.TM_ASSIGNM_RULE#modelName
        * @propertyOf lbServices.TM_ASSIGNM_RULE
        * @description
        * The name of the model represented by this $resource,
        * i.e. `TM_ASSIGNM_RULE`.
        */
        R.modelName = "TM_ASSIGNM_RULE";

    /**
     * @ngdoc object
     * @name lbServices.TM_ASSIGNM_RULE.criterias
     * @header lbServices.TM_ASSIGNM_RULE.criterias
     * @object
     * @description
     *
     * The object `TM_ASSIGNM_RULE.criterias` groups methods
     * manipulating `TM_ASSIGNM_RULE_CRITERIA` instances related to `TM_ASSIGNM_RULE`.
     *
     * Call {@link lbServices.TM_ASSIGNM_RULE#criterias TM_ASSIGNM_RULE.criterias()}
     * to query all related instances.
     */


            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#criterias
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Queries criterias of TM_ASSIGNM_RULE.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `filter` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
        R.criterias = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_CRITERIA");
          var action = TargetResource["::get::TM_ASSIGNM_RULE::criterias"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE.criterias#count
             * @methodOf lbServices.TM_ASSIGNM_RULE.criterias
             *
             * @description
             *
             * Counts criterias of TM_ASSIGNM_RULE.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
        R.criterias.count = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_CRITERIA");
          var action = TargetResource["::count::TM_ASSIGNM_RULE::criterias"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE.criterias#create
             * @methodOf lbServices.TM_ASSIGNM_RULE.criterias
             *
             * @description
             *
             * Creates a new instance in criterias of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
        R.criterias.create = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_CRITERIA");
          var action = TargetResource["::create::TM_ASSIGNM_RULE::criterias"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE.criterias#createMany
             * @methodOf lbServices.TM_ASSIGNM_RULE.criterias
             *
             * @description
             *
             * Creates a new instance in criterias of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
        R.criterias.createMany = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_CRITERIA");
          var action = TargetResource["::createMany::TM_ASSIGNM_RULE::criterias"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE.criterias#destroyAll
             * @methodOf lbServices.TM_ASSIGNM_RULE.criterias
             *
             * @description
             *
             * Deletes all criterias of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.criterias.destroyAll = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_CRITERIA");
          var action = TargetResource["::delete::TM_ASSIGNM_RULE::criterias"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE.criterias#destroyById
             * @methodOf lbServices.TM_ASSIGNM_RULE.criterias
             *
             * @description
             *
             * Delete a related item by id for criterias.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for criterias
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.criterias.destroyById = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_CRITERIA");
          var action = TargetResource["::destroyById::TM_ASSIGNM_RULE::criterias"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE.criterias#findById
             * @methodOf lbServices.TM_ASSIGNM_RULE.criterias
             *
             * @description
             *
             * Find a related item by id for criterias.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for criterias
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
        R.criterias.findById = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_CRITERIA");
          var action = TargetResource["::findById::TM_ASSIGNM_RULE::criterias"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE.criterias#updateById
             * @methodOf lbServices.TM_ASSIGNM_RULE.criterias
             *
             * @description
             *
             * Update a related item by id for criterias.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for criterias
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
        R.criterias.updateById = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_CRITERIA");
          var action = TargetResource["::updateById::TM_ASSIGNM_RULE::criterias"];
          return action.apply(R, arguments);
        };
    /**
     * @ngdoc object
     * @name lbServices.TM_ASSIGNM_RULE.geoCriterias
     * @header lbServices.TM_ASSIGNM_RULE.geoCriterias
     * @object
     * @description
     *
     * The object `TM_ASSIGNM_RULE.geoCriterias` groups methods
     * manipulating `TM_ASSIGNM_RULE_GEO_CRITERIA` instances related to `TM_ASSIGNM_RULE`.
     *
     * Call {@link lbServices.TM_ASSIGNM_RULE#geoCriterias TM_ASSIGNM_RULE.geoCriterias()}
     * to query all related instances.
     */


            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE#geoCriterias
             * @methodOf lbServices.TM_ASSIGNM_RULE
             *
             * @description
             *
             * Queries geoCriterias of TM_ASSIGNM_RULE.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `filter` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
        R.geoCriterias = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_GEO_CRITERIA");
          var action = TargetResource["::get::TM_ASSIGNM_RULE::geoCriterias"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE.geoCriterias#count
             * @methodOf lbServices.TM_ASSIGNM_RULE.geoCriterias
             *
             * @description
             *
             * Counts geoCriterias of TM_ASSIGNM_RULE.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
        R.geoCriterias.count = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_GEO_CRITERIA");
          var action = TargetResource["::count::TM_ASSIGNM_RULE::geoCriterias"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE.geoCriterias#create
             * @methodOf lbServices.TM_ASSIGNM_RULE.geoCriterias
             *
             * @description
             *
             * Creates a new instance in geoCriterias of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
        R.geoCriterias.create = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_GEO_CRITERIA");
          var action = TargetResource["::create::TM_ASSIGNM_RULE::geoCriterias"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE.geoCriterias#createMany
             * @methodOf lbServices.TM_ASSIGNM_RULE.geoCriterias
             *
             * @description
             *
             * Creates a new instance in geoCriterias of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
        R.geoCriterias.createMany = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_GEO_CRITERIA");
          var action = TargetResource["::createMany::TM_ASSIGNM_RULE::geoCriterias"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE.geoCriterias#destroyAll
             * @methodOf lbServices.TM_ASSIGNM_RULE.geoCriterias
             *
             * @description
             *
             * Deletes all geoCriterias of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.geoCriterias.destroyAll = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_GEO_CRITERIA");
          var action = TargetResource["::delete::TM_ASSIGNM_RULE::geoCriterias"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE.geoCriterias#destroyById
             * @methodOf lbServices.TM_ASSIGNM_RULE.geoCriterias
             *
             * @description
             *
             * Delete a related item by id for geoCriterias.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for geoCriterias
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.geoCriterias.destroyById = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_GEO_CRITERIA");
          var action = TargetResource["::destroyById::TM_ASSIGNM_RULE::geoCriterias"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE.geoCriterias#findById
             * @methodOf lbServices.TM_ASSIGNM_RULE.geoCriterias
             *
             * @description
             *
             * Find a related item by id for geoCriterias.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for geoCriterias
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
        R.geoCriterias.findById = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_GEO_CRITERIA");
          var action = TargetResource["::findById::TM_ASSIGNM_RULE::geoCriterias"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE.geoCriterias#updateById
             * @methodOf lbServices.TM_ASSIGNM_RULE.geoCriterias
             *
             * @description
             *
             * Update a related item by id for geoCriterias.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for geoCriterias
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
        R.geoCriterias.updateById = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_GEO_CRITERIA");
          var action = TargetResource["::updateById::TM_ASSIGNM_RULE::geoCriterias"];
          return action.apply(R, arguments);
        };


        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.TM_ASSIGNM_RULE_CRITERIA
 * @header lbServices.TM_ASSIGNM_RULE_CRITERIA
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `TM_ASSIGNM_RULE_CRITERIA` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "TM_ASSIGNM_RULE_CRITERIA",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/:id",
          { 'id': '@id' },
          {

            // INTERNAL. Use TM_ASSIGNM_RULE_CRITERIA.Values.findById() instead.
            "prototype$__findById__Values": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/:id/Values/:fk",
              method: "GET",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE_CRITERIA.Values.destroyById() instead.
            "prototype$__destroyById__Values": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/:id/Values/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE_CRITERIA.Values.updateById() instead.
            "prototype$__updateById__Values": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/:id/Values/:fk",
              method: "PUT",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE_CRITERIA.Values() instead.
            "prototype$__get__Values": {
              isArray: true,
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/:id/Values",
              method: "GET",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE_CRITERIA.Values.create() instead.
            "prototype$__create__Values": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/:id/Values",
              method: "POST",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE_CRITERIA.Values.destroyAll() instead.
            "prototype$__delete__Values": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/:id/Values",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE_CRITERIA.Values.count() instead.
            "prototype$__count__Values": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/:id/Values/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#create
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#createMany
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#upsert
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
            "upsert": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#replaceOrCreate
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#upsertWithWhere
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#exists
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#findById
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#replaceById
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#find
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#findOne
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#updateAll
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
            "updateAll": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#deleteById
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#count
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#prototype$updateAttributes
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
            "prototype$updateAttributes": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/:id",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#createChangeStream
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/change-stream",
              method: "POST",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.criterias.findById() instead.
            "::findById::TM_ASSIGNM_RULE::criterias": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ASSIGNM_RULES/:id/criterias/:fk",
              method: "GET",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.criterias.destroyById() instead.
            "::destroyById::TM_ASSIGNM_RULE::criterias": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ASSIGNM_RULES/:id/criterias/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.criterias.updateById() instead.
            "::updateById::TM_ASSIGNM_RULE::criterias": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ASSIGNM_RULES/:id/criterias/:fk",
              method: "PUT",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.criterias() instead.
            "::get::TM_ASSIGNM_RULE::criterias": {
              isArray: true,
              url: urlBase + "/TM_ASSIGNM_RULES/:id/criterias",
              method: "GET",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.criterias.create() instead.
            "::create::TM_ASSIGNM_RULE::criterias": {
              url: urlBase + "/TM_ASSIGNM_RULES/:id/criterias",
              method: "POST",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.criterias.createMany() instead.
            "::createMany::TM_ASSIGNM_RULE::criterias": {
              isArray: true,
              url: urlBase + "/TM_ASSIGNM_RULES/:id/criterias",
              method: "POST",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.criterias.destroyAll() instead.
            "::delete::TM_ASSIGNM_RULE::criterias": {
              url: urlBase + "/TM_ASSIGNM_RULES/:id/criterias",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.criterias.count() instead.
            "::count::TM_ASSIGNM_RULE::criterias": {
              url: urlBase + "/TM_ASSIGNM_RULES/:id/criterias/count",
              method: "GET",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#patchOrCreate
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
        R["patchOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#updateOrCreate
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
        R["updateOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#patchOrCreateWithWhere
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#update
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#destroyById
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#removeById
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#patchAttributes
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA` object.)
             * </em>
             */
        R["patchAttributes"] = R["prototype$updateAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#modelName
        * @propertyOf lbServices.TM_ASSIGNM_RULE_CRITERIA
        * @description
        * The name of the model represented by this $resource,
        * i.e. `TM_ASSIGNM_RULE_CRITERIA`.
        */
        R.modelName = "TM_ASSIGNM_RULE_CRITERIA";

    /**
     * @ngdoc object
     * @name lbServices.TM_ASSIGNM_RULE_CRITERIA.Values
     * @header lbServices.TM_ASSIGNM_RULE_CRITERIA.Values
     * @object
     * @description
     *
     * The object `TM_ASSIGNM_RULE_CRITERIA.Values` groups methods
     * manipulating `TM_ASSIGNM_RULE_CRITERIA_VALUE` instances related to `TM_ASSIGNM_RULE_CRITERIA`.
     *
     * Call {@link lbServices.TM_ASSIGNM_RULE_CRITERIA#Values TM_ASSIGNM_RULE_CRITERIA.Values()}
     * to query all related instances.
     */


            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA#Values
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA
             *
             * @description
             *
             * Queries Values of TM_ASSIGNM_RULE_CRITERIA.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `filter` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
        R.Values = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_CRITERIA_VALUE");
          var action = TargetResource["::get::TM_ASSIGNM_RULE_CRITERIA::Values"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA.Values#count
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA.Values
             *
             * @description
             *
             * Counts Values of TM_ASSIGNM_RULE_CRITERIA.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
        R.Values.count = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_CRITERIA_VALUE");
          var action = TargetResource["::count::TM_ASSIGNM_RULE_CRITERIA::Values"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA.Values#create
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA.Values
             *
             * @description
             *
             * Creates a new instance in Values of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
        R.Values.create = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_CRITERIA_VALUE");
          var action = TargetResource["::create::TM_ASSIGNM_RULE_CRITERIA::Values"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA.Values#createMany
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA.Values
             *
             * @description
             *
             * Creates a new instance in Values of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
        R.Values.createMany = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_CRITERIA_VALUE");
          var action = TargetResource["::createMany::TM_ASSIGNM_RULE_CRITERIA::Values"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA.Values#destroyAll
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA.Values
             *
             * @description
             *
             * Deletes all Values of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.Values.destroyAll = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_CRITERIA_VALUE");
          var action = TargetResource["::delete::TM_ASSIGNM_RULE_CRITERIA::Values"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA.Values#destroyById
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA.Values
             *
             * @description
             *
             * Delete a related item by id for Values.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for Values
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.Values.destroyById = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_CRITERIA_VALUE");
          var action = TargetResource["::destroyById::TM_ASSIGNM_RULE_CRITERIA::Values"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA.Values#findById
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA.Values
             *
             * @description
             *
             * Find a related item by id for Values.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for Values
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
        R.Values.findById = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_CRITERIA_VALUE");
          var action = TargetResource["::findById::TM_ASSIGNM_RULE_CRITERIA::Values"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA.Values#updateById
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA.Values
             *
             * @description
             *
             * Update a related item by id for Values.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for Values
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
        R.Values.updateById = function() {
          var TargetResource = $injector.get("TM_ASSIGNM_RULE_CRITERIA_VALUE");
          var action = TargetResource["::updateById::TM_ASSIGNM_RULE_CRITERIA::Values"];
          return action.apply(R, arguments);
        };


        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
 * @header lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `TM_ASSIGNM_RULE_CRITERIA_VALUE` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "TM_ASSIGNM_RULE_CRITERIA_VALUE",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/TM_ASSIGNM_RULE_CRITERIA_VALUES/:id",
          { 'id': '@id' },
          {

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#create
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIA_VALUES",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#createMany
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIA_VALUES",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#upsert
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
            "upsert": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIA_VALUES",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#replaceOrCreate
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIA_VALUES/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#upsertWithWhere
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIA_VALUES/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#exists
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIA_VALUES/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#findById
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIA_VALUES/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#replaceById
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIA_VALUES/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#find
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIA_VALUES",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#findOne
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIA_VALUES/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#updateAll
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
            "updateAll": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIA_VALUES/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#deleteById
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIA_VALUES/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#count
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIA_VALUES/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#prototype$updateAttributes
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
            "prototype$updateAttributes": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIA_VALUES/:id",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#createChangeStream
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIA_VALUES/change-stream",
              method: "POST",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE_CRITERIA.Values.findById() instead.
            "::findById::TM_ASSIGNM_RULE_CRITERIA::Values": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/:id/Values/:fk",
              method: "GET",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE_CRITERIA.Values.destroyById() instead.
            "::destroyById::TM_ASSIGNM_RULE_CRITERIA::Values": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/:id/Values/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE_CRITERIA.Values.updateById() instead.
            "::updateById::TM_ASSIGNM_RULE_CRITERIA::Values": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/:id/Values/:fk",
              method: "PUT",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE_CRITERIA.Values() instead.
            "::get::TM_ASSIGNM_RULE_CRITERIA::Values": {
              isArray: true,
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/:id/Values",
              method: "GET",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE_CRITERIA.Values.create() instead.
            "::create::TM_ASSIGNM_RULE_CRITERIA::Values": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/:id/Values",
              method: "POST",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE_CRITERIA.Values.createMany() instead.
            "::createMany::TM_ASSIGNM_RULE_CRITERIA::Values": {
              isArray: true,
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/:id/Values",
              method: "POST",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE_CRITERIA.Values.destroyAll() instead.
            "::delete::TM_ASSIGNM_RULE_CRITERIA::Values": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/:id/Values",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE_CRITERIA.Values.count() instead.
            "::count::TM_ASSIGNM_RULE_CRITERIA::Values": {
              url: urlBase + "/TM_ASSIGNM_RULE_CRITERIAS/:id/Values/count",
              method: "GET",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#patchOrCreate
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
        R["patchOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#updateOrCreate
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
        R["updateOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#patchOrCreateWithWhere
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#update
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#destroyById
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#removeById
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#patchAttributes
             * @methodOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_CRITERIA_VALUE` object.)
             * </em>
             */
        R["patchAttributes"] = R["prototype$updateAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE#modelName
        * @propertyOf lbServices.TM_ASSIGNM_RULE_CRITERIA_VALUE
        * @description
        * The name of the model represented by this $resource,
        * i.e. `TM_ASSIGNM_RULE_CRITERIA_VALUE`.
        */
        R.modelName = "TM_ASSIGNM_RULE_CRITERIA_VALUE";



        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.TM_CODE_VALUE
 * @header lbServices.TM_CODE_VALUE
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `TM_CODE_VALUE` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "TM_CODE_VALUE",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/TM_CODE_VALUES/:id",
          { 'id': '@id' },
          {

            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#create
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_CODE_VALUE` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/TM_CODE_VALUES",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#createMany
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_CODE_VALUE` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/TM_CODE_VALUES",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#upsert
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_CODE_VALUE` object.)
             * </em>
             */
            "upsert": {
              url: urlBase + "/TM_CODE_VALUES",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#replaceOrCreate
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_CODE_VALUE` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/TM_CODE_VALUES/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#upsertWithWhere
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_CODE_VALUE` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/TM_CODE_VALUES/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#exists
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/TM_CODE_VALUES/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#findById
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_CODE_VALUE` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/TM_CODE_VALUES/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#replaceById
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_CODE_VALUE` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/TM_CODE_VALUES/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#find
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_CODE_VALUE` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/TM_CODE_VALUES",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#findOne
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_CODE_VALUE` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/TM_CODE_VALUES/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#updateAll
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
            "updateAll": {
              url: urlBase + "/TM_CODE_VALUES/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#deleteById
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_CODE_VALUE` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/TM_CODE_VALUES/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#count
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/TM_CODE_VALUES/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#prototype$updateAttributes
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_CODE_VALUE` object.)
             * </em>
             */
            "prototype$updateAttributes": {
              url: urlBase + "/TM_CODE_VALUES/:id",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#createChangeStream
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/TM_CODE_VALUES/change-stream",
              method: "POST",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#patchOrCreate
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_CODE_VALUE` object.)
             * </em>
             */
        R["patchOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#updateOrCreate
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_CODE_VALUE` object.)
             * </em>
             */
        R["updateOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#patchOrCreateWithWhere
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_CODE_VALUE` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#update
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#destroyById
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_CODE_VALUE` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#removeById
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_CODE_VALUE` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_CODE_VALUE#patchAttributes
             * @methodOf lbServices.TM_CODE_VALUE
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_CODE_VALUE` object.)
             * </em>
             */
        R["patchAttributes"] = R["prototype$updateAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.TM_CODE_VALUE#modelName
        * @propertyOf lbServices.TM_CODE_VALUE
        * @description
        * The name of the model represented by this $resource,
        * i.e. `TM_CODE_VALUE`.
        */
        R.modelName = "TM_CODE_VALUE";



        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
 * @header lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `TM_ASSIGNM_RULE_GEO_CRITERIA` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "TM_ASSIGNM_RULE_GEO_CRITERIA",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/TM_ASSIGNM_RULE_GEO_CRITERIAS/:id",
          { 'id': '@id' },
          {

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#create
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/TM_ASSIGNM_RULE_GEO_CRITERIAS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#createMany
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/TM_ASSIGNM_RULE_GEO_CRITERIAS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#upsert
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
            "upsert": {
              url: urlBase + "/TM_ASSIGNM_RULE_GEO_CRITERIAS",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#replaceOrCreate
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/TM_ASSIGNM_RULE_GEO_CRITERIAS/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#upsertWithWhere
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/TM_ASSIGNM_RULE_GEO_CRITERIAS/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#exists
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/TM_ASSIGNM_RULE_GEO_CRITERIAS/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#findById
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/TM_ASSIGNM_RULE_GEO_CRITERIAS/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#replaceById
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/TM_ASSIGNM_RULE_GEO_CRITERIAS/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#find
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/TM_ASSIGNM_RULE_GEO_CRITERIAS",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#findOne
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/TM_ASSIGNM_RULE_GEO_CRITERIAS/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#updateAll
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
            "updateAll": {
              url: urlBase + "/TM_ASSIGNM_RULE_GEO_CRITERIAS/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#deleteById
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/TM_ASSIGNM_RULE_GEO_CRITERIAS/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#count
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/TM_ASSIGNM_RULE_GEO_CRITERIAS/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#prototype$updateAttributes
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
            "prototype$updateAttributes": {
              url: urlBase + "/TM_ASSIGNM_RULE_GEO_CRITERIAS/:id",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#createChangeStream
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/TM_ASSIGNM_RULE_GEO_CRITERIAS/change-stream",
              method: "POST",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.geoCriterias.findById() instead.
            "::findById::TM_ASSIGNM_RULE::geoCriterias": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ASSIGNM_RULES/:id/geoCriterias/:fk",
              method: "GET",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.geoCriterias.destroyById() instead.
            "::destroyById::TM_ASSIGNM_RULE::geoCriterias": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ASSIGNM_RULES/:id/geoCriterias/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.geoCriterias.updateById() instead.
            "::updateById::TM_ASSIGNM_RULE::geoCriterias": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/TM_ASSIGNM_RULES/:id/geoCriterias/:fk",
              method: "PUT",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.geoCriterias() instead.
            "::get::TM_ASSIGNM_RULE::geoCriterias": {
              isArray: true,
              url: urlBase + "/TM_ASSIGNM_RULES/:id/geoCriterias",
              method: "GET",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.geoCriterias.create() instead.
            "::create::TM_ASSIGNM_RULE::geoCriterias": {
              url: urlBase + "/TM_ASSIGNM_RULES/:id/geoCriterias",
              method: "POST",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.geoCriterias.createMany() instead.
            "::createMany::TM_ASSIGNM_RULE::geoCriterias": {
              isArray: true,
              url: urlBase + "/TM_ASSIGNM_RULES/:id/geoCriterias",
              method: "POST",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.geoCriterias.destroyAll() instead.
            "::delete::TM_ASSIGNM_RULE::geoCriterias": {
              url: urlBase + "/TM_ASSIGNM_RULES/:id/geoCriterias",
              method: "DELETE",
            },

            // INTERNAL. Use TM_ASSIGNM_RULE.geoCriterias.count() instead.
            "::count::TM_ASSIGNM_RULE::geoCriterias": {
              url: urlBase + "/TM_ASSIGNM_RULES/:id/geoCriterias/count",
              method: "GET",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#patchOrCreate
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
        R["patchOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#updateOrCreate
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
        R["updateOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#patchOrCreateWithWhere
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#update
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#destroyById
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#removeById
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#patchAttributes
             * @methodOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_RULE_GEO_CRITERIA` object.)
             * </em>
             */
        R["patchAttributes"] = R["prototype$updateAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA#modelName
        * @propertyOf lbServices.TM_ASSIGNM_RULE_GEO_CRITERIA
        * @description
        * The name of the model represented by this $resource,
        * i.e. `TM_ASSIGNM_RULE_GEO_CRITERIA`.
        */
        R.modelName = "TM_ASSIGNM_RULE_GEO_CRITERIA";



        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.TM_ASSIGNM_EXCEPTION
 * @header lbServices.TM_ASSIGNM_EXCEPTION
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `TM_ASSIGNM_EXCEPTION` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "TM_ASSIGNM_EXCEPTION",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/TM_ASSIGNM_EXCEPTIONS/:id",
          { 'id': '@id' },
          {

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#create
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_EXCEPTION` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/TM_ASSIGNM_EXCEPTIONS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#createMany
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_EXCEPTION` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/TM_ASSIGNM_EXCEPTIONS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#upsert
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_EXCEPTION` object.)
             * </em>
             */
            "upsert": {
              url: urlBase + "/TM_ASSIGNM_EXCEPTIONS",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#replaceOrCreate
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_EXCEPTION` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/TM_ASSIGNM_EXCEPTIONS/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#upsertWithWhere
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_EXCEPTION` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/TM_ASSIGNM_EXCEPTIONS/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#exists
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/TM_ASSIGNM_EXCEPTIONS/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#findById
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_EXCEPTION` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/TM_ASSIGNM_EXCEPTIONS/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#replaceById
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_EXCEPTION` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/TM_ASSIGNM_EXCEPTIONS/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#find
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_EXCEPTION` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/TM_ASSIGNM_EXCEPTIONS",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#findOne
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_EXCEPTION` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/TM_ASSIGNM_EXCEPTIONS/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#updateAll
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
            "updateAll": {
              url: urlBase + "/TM_ASSIGNM_EXCEPTIONS/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#deleteById
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_EXCEPTION` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/TM_ASSIGNM_EXCEPTIONS/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#count
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/TM_ASSIGNM_EXCEPTIONS/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#prototype$updateAttributes
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_EXCEPTION` object.)
             * </em>
             */
            "prototype$updateAttributes": {
              url: urlBase + "/TM_ASSIGNM_EXCEPTIONS/:id",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#createChangeStream
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/TM_ASSIGNM_EXCEPTIONS/change-stream",
              method: "POST",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#patchOrCreate
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_EXCEPTION` object.)
             * </em>
             */
        R["patchOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#updateOrCreate
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_EXCEPTION` object.)
             * </em>
             */
        R["updateOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#patchOrCreateWithWhere
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_EXCEPTION` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#update
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#destroyById
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_EXCEPTION` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#removeById
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_EXCEPTION` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_EXCEPTION#patchAttributes
             * @methodOf lbServices.TM_ASSIGNM_EXCEPTION
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_EXCEPTION` object.)
             * </em>
             */
        R["patchAttributes"] = R["prototype$updateAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.TM_ASSIGNM_EXCEPTION#modelName
        * @propertyOf lbServices.TM_ASSIGNM_EXCEPTION
        * @description
        * The name of the model represented by this $resource,
        * i.e. `TM_ASSIGNM_EXCEPTION`.
        */
        R.modelName = "TM_ASSIGNM_EXCEPTION";



        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.TM_SOFT_ALARM
 * @header lbServices.TM_SOFT_ALARM
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `TM_SOFT_ALARM` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "TM_SOFT_ALARM",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/TM_SOFT_ALARMS/:id",
          { 'id': '@id' },
          {

            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#create
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_SOFT_ALARM` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/TM_SOFT_ALARMS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#createMany
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_SOFT_ALARM` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/TM_SOFT_ALARMS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#upsert
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_SOFT_ALARM` object.)
             * </em>
             */
            "upsert": {
              url: urlBase + "/TM_SOFT_ALARMS",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#replaceOrCreate
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_SOFT_ALARM` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/TM_SOFT_ALARMS/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#upsertWithWhere
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_SOFT_ALARM` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/TM_SOFT_ALARMS/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#exists
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/TM_SOFT_ALARMS/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#findById
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_SOFT_ALARM` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/TM_SOFT_ALARMS/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#replaceById
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_SOFT_ALARM` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/TM_SOFT_ALARMS/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#find
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_SOFT_ALARM` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/TM_SOFT_ALARMS",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#findOne
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_SOFT_ALARM` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/TM_SOFT_ALARMS/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#updateAll
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
            "updateAll": {
              url: urlBase + "/TM_SOFT_ALARMS/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#deleteById
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_SOFT_ALARM` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/TM_SOFT_ALARMS/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#count
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/TM_SOFT_ALARMS/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#prototype$updateAttributes
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_SOFT_ALARM` object.)
             * </em>
             */
            "prototype$updateAttributes": {
              url: urlBase + "/TM_SOFT_ALARMS/:id",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#createChangeStream
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/TM_SOFT_ALARMS/change-stream",
              method: "POST",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#patchOrCreate
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_SOFT_ALARM` object.)
             * </em>
             */
        R["patchOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#updateOrCreate
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_SOFT_ALARM` object.)
             * </em>
             */
        R["updateOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#patchOrCreateWithWhere
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_SOFT_ALARM` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#update
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#destroyById
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_SOFT_ALARM` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#removeById
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_SOFT_ALARM` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_SOFT_ALARM#patchAttributes
             * @methodOf lbServices.TM_SOFT_ALARM
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_SOFT_ALARM` object.)
             * </em>
             */
        R["patchAttributes"] = R["prototype$updateAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.TM_SOFT_ALARM#modelName
        * @propertyOf lbServices.TM_SOFT_ALARM
        * @description
        * The name of the model represented by this $resource,
        * i.e. `TM_SOFT_ALARM`.
        */
        R.modelName = "TM_SOFT_ALARM";



        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.EXEC_HISTORY
 * @header lbServices.EXEC_HISTORY
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `EXEC_HISTORY` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "EXEC_HISTORY",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/EXEC_HISTORIES/:id",
          { 'id': '@id' },
          {

            // INTERNAL. Use EXEC_HISTORY.execDetails.findById() instead.
            "prototype$__findById__execDetails": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/EXEC_HISTORIES/:id/execDetails/:fk",
              method: "GET",
            },

            // INTERNAL. Use EXEC_HISTORY.execDetails.destroyById() instead.
            "prototype$__destroyById__execDetails": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/EXEC_HISTORIES/:id/execDetails/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use EXEC_HISTORY.execDetails.updateById() instead.
            "prototype$__updateById__execDetails": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/EXEC_HISTORIES/:id/execDetails/:fk",
              method: "PUT",
            },

            // INTERNAL. Use EXEC_HISTORY.stATL.findById() instead.
            "prototype$__findById__stATL": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/EXEC_HISTORIES/:id/stATL/:fk",
              method: "GET",
            },

            // INTERNAL. Use EXEC_HISTORY.stATL.destroyById() instead.
            "prototype$__destroyById__stATL": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/EXEC_HISTORIES/:id/stATL/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use EXEC_HISTORY.stATL.updateById() instead.
            "prototype$__updateById__stATL": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/EXEC_HISTORIES/:id/stATL/:fk",
              method: "PUT",
            },

            // INTERNAL. Use EXEC_HISTORY.execDetails() instead.
            "prototype$__get__execDetails": {
              isArray: true,
              url: urlBase + "/EXEC_HISTORIES/:id/execDetails",
              method: "GET",
            },

            // INTERNAL. Use EXEC_HISTORY.execDetails.create() instead.
            "prototype$__create__execDetails": {
              url: urlBase + "/EXEC_HISTORIES/:id/execDetails",
              method: "POST",
            },

            // INTERNAL. Use EXEC_HISTORY.execDetails.destroyAll() instead.
            "prototype$__delete__execDetails": {
              url: urlBase + "/EXEC_HISTORIES/:id/execDetails",
              method: "DELETE",
            },

            // INTERNAL. Use EXEC_HISTORY.execDetails.count() instead.
            "prototype$__count__execDetails": {
              url: urlBase + "/EXEC_HISTORIES/:id/execDetails/count",
              method: "GET",
            },

            // INTERNAL. Use EXEC_HISTORY.stATL() instead.
            "prototype$__get__stATL": {
              isArray: true,
              url: urlBase + "/EXEC_HISTORIES/:id/stATL",
              method: "GET",
            },

            // INTERNAL. Use EXEC_HISTORY.stATL.create() instead.
            "prototype$__create__stATL": {
              url: urlBase + "/EXEC_HISTORIES/:id/stATL",
              method: "POST",
            },

            // INTERNAL. Use EXEC_HISTORY.stATL.destroyAll() instead.
            "prototype$__delete__stATL": {
              url: urlBase + "/EXEC_HISTORIES/:id/stATL",
              method: "DELETE",
            },

            // INTERNAL. Use EXEC_HISTORY.stATL.count() instead.
            "prototype$__count__stATL": {
              url: urlBase + "/EXEC_HISTORIES/:id/stATL/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#create
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_HISTORY` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/EXEC_HISTORIES",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#createMany
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_HISTORY` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/EXEC_HISTORIES",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#upsert
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_HISTORY` object.)
             * </em>
             */
            "upsert": {
              url: urlBase + "/EXEC_HISTORIES",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#replaceOrCreate
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_HISTORY` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/EXEC_HISTORIES/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#upsertWithWhere
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_HISTORY` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/EXEC_HISTORIES/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#exists
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/EXEC_HISTORIES/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#findById
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_HISTORY` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/EXEC_HISTORIES/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#replaceById
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_HISTORY` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/EXEC_HISTORIES/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#find
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_HISTORY` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/EXEC_HISTORIES",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#findOne
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_HISTORY` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/EXEC_HISTORIES/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#updateAll
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
            "updateAll": {
              url: urlBase + "/EXEC_HISTORIES/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#deleteById
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_HISTORY` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/EXEC_HISTORIES/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#count
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/EXEC_HISTORIES/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#prototype$updateAttributes
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_HISTORY` object.)
             * </em>
             */
            "prototype$updateAttributes": {
              url: urlBase + "/EXEC_HISTORIES/:id",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#createChangeStream
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/EXEC_HISTORIES/change-stream",
              method: "POST",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#patchOrCreate
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_HISTORY` object.)
             * </em>
             */
        R["patchOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#updateOrCreate
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_HISTORY` object.)
             * </em>
             */
        R["updateOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#patchOrCreateWithWhere
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_HISTORY` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#update
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#destroyById
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_HISTORY` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#removeById
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_HISTORY` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#patchAttributes
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_HISTORY` object.)
             * </em>
             */
        R["patchAttributes"] = R["prototype$updateAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.EXEC_HISTORY#modelName
        * @propertyOf lbServices.EXEC_HISTORY
        * @description
        * The name of the model represented by this $resource,
        * i.e. `EXEC_HISTORY`.
        */
        R.modelName = "EXEC_HISTORY";

    /**
     * @ngdoc object
     * @name lbServices.EXEC_HISTORY.execDetails
     * @header lbServices.EXEC_HISTORY.execDetails
     * @object
     * @description
     *
     * The object `EXEC_HISTORY.execDetails` groups methods
     * manipulating `EXEC_DETAIL_HISTORY` instances related to `EXEC_HISTORY`.
     *
     * Call {@link lbServices.EXEC_HISTORY#execDetails EXEC_HISTORY.execDetails()}
     * to query all related instances.
     */


            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#execDetails
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Queries execDetails of EXEC_HISTORY.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `filter` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
        R.execDetails = function() {
          var TargetResource = $injector.get("EXEC_DETAIL_HISTORY");
          var action = TargetResource["::get::EXEC_HISTORY::execDetails"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY.execDetails#count
             * @methodOf lbServices.EXEC_HISTORY.execDetails
             *
             * @description
             *
             * Counts execDetails of EXEC_HISTORY.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
        R.execDetails.count = function() {
          var TargetResource = $injector.get("EXEC_DETAIL_HISTORY");
          var action = TargetResource["::count::EXEC_HISTORY::execDetails"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY.execDetails#create
             * @methodOf lbServices.EXEC_HISTORY.execDetails
             *
             * @description
             *
             * Creates a new instance in execDetails of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
        R.execDetails.create = function() {
          var TargetResource = $injector.get("EXEC_DETAIL_HISTORY");
          var action = TargetResource["::create::EXEC_HISTORY::execDetails"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY.execDetails#createMany
             * @methodOf lbServices.EXEC_HISTORY.execDetails
             *
             * @description
             *
             * Creates a new instance in execDetails of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
        R.execDetails.createMany = function() {
          var TargetResource = $injector.get("EXEC_DETAIL_HISTORY");
          var action = TargetResource["::createMany::EXEC_HISTORY::execDetails"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY.execDetails#destroyAll
             * @methodOf lbServices.EXEC_HISTORY.execDetails
             *
             * @description
             *
             * Deletes all execDetails of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.execDetails.destroyAll = function() {
          var TargetResource = $injector.get("EXEC_DETAIL_HISTORY");
          var action = TargetResource["::delete::EXEC_HISTORY::execDetails"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY.execDetails#destroyById
             * @methodOf lbServices.EXEC_HISTORY.execDetails
             *
             * @description
             *
             * Delete a related item by id for execDetails.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for execDetails
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.execDetails.destroyById = function() {
          var TargetResource = $injector.get("EXEC_DETAIL_HISTORY");
          var action = TargetResource["::destroyById::EXEC_HISTORY::execDetails"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY.execDetails#findById
             * @methodOf lbServices.EXEC_HISTORY.execDetails
             *
             * @description
             *
             * Find a related item by id for execDetails.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for execDetails
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
        R.execDetails.findById = function() {
          var TargetResource = $injector.get("EXEC_DETAIL_HISTORY");
          var action = TargetResource["::findById::EXEC_HISTORY::execDetails"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY.execDetails#updateById
             * @methodOf lbServices.EXEC_HISTORY.execDetails
             *
             * @description
             *
             * Update a related item by id for execDetails.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for execDetails
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
        R.execDetails.updateById = function() {
          var TargetResource = $injector.get("EXEC_DETAIL_HISTORY");
          var action = TargetResource["::updateById::EXEC_HISTORY::execDetails"];
          return action.apply(R, arguments);
        };
    /**
     * @ngdoc object
     * @name lbServices.EXEC_HISTORY.stATL
     * @header lbServices.EXEC_HISTORY.stATL
     * @object
     * @description
     *
     * The object `EXEC_HISTORY.stATL` groups methods
     * manipulating `ST_ATL_HISTORY` instances related to `EXEC_HISTORY`.
     *
     * Call {@link lbServices.EXEC_HISTORY#stATL EXEC_HISTORY.stATL()}
     * to query all related instances.
     */


            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY#stATL
             * @methodOf lbServices.EXEC_HISTORY
             *
             * @description
             *
             * Queries stATL of EXEC_HISTORY.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `filter` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
        R.stATL = function() {
          var TargetResource = $injector.get("ST_ATL_HISTORY");
          var action = TargetResource["::get::EXEC_HISTORY::stATL"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY.stATL#count
             * @methodOf lbServices.EXEC_HISTORY.stATL
             *
             * @description
             *
             * Counts stATL of EXEC_HISTORY.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
        R.stATL.count = function() {
          var TargetResource = $injector.get("ST_ATL_HISTORY");
          var action = TargetResource["::count::EXEC_HISTORY::stATL"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY.stATL#create
             * @methodOf lbServices.EXEC_HISTORY.stATL
             *
             * @description
             *
             * Creates a new instance in stATL of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
        R.stATL.create = function() {
          var TargetResource = $injector.get("ST_ATL_HISTORY");
          var action = TargetResource["::create::EXEC_HISTORY::stATL"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY.stATL#createMany
             * @methodOf lbServices.EXEC_HISTORY.stATL
             *
             * @description
             *
             * Creates a new instance in stATL of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
        R.stATL.createMany = function() {
          var TargetResource = $injector.get("ST_ATL_HISTORY");
          var action = TargetResource["::createMany::EXEC_HISTORY::stATL"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY.stATL#destroyAll
             * @methodOf lbServices.EXEC_HISTORY.stATL
             *
             * @description
             *
             * Deletes all stATL of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.stATL.destroyAll = function() {
          var TargetResource = $injector.get("ST_ATL_HISTORY");
          var action = TargetResource["::delete::EXEC_HISTORY::stATL"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY.stATL#destroyById
             * @methodOf lbServices.EXEC_HISTORY.stATL
             *
             * @description
             *
             * Delete a related item by id for stATL.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for stATL
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.stATL.destroyById = function() {
          var TargetResource = $injector.get("ST_ATL_HISTORY");
          var action = TargetResource["::destroyById::EXEC_HISTORY::stATL"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY.stATL#findById
             * @methodOf lbServices.EXEC_HISTORY.stATL
             *
             * @description
             *
             * Find a related item by id for stATL.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for stATL
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
        R.stATL.findById = function() {
          var TargetResource = $injector.get("ST_ATL_HISTORY");
          var action = TargetResource["::findById::EXEC_HISTORY::stATL"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.EXEC_HISTORY.stATL#updateById
             * @methodOf lbServices.EXEC_HISTORY.stATL
             *
             * @description
             *
             * Update a related item by id for stATL.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for stATL
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
        R.stATL.updateById = function() {
          var TargetResource = $injector.get("ST_ATL_HISTORY");
          var action = TargetResource["::updateById::EXEC_HISTORY::stATL"];
          return action.apply(R, arguments);
        };


        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.EXEC_DETAIL_HISTORY
 * @header lbServices.EXEC_DETAIL_HISTORY
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `EXEC_DETAIL_HISTORY` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "EXEC_DETAIL_HISTORY",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/EXEC_DETAIL_HISTORIES/:id",
          { 'id': '@id' },
          {

            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#create
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/EXEC_DETAIL_HISTORIES",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#createMany
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/EXEC_DETAIL_HISTORIES",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#upsert
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
            "upsert": {
              url: urlBase + "/EXEC_DETAIL_HISTORIES",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#replaceOrCreate
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/EXEC_DETAIL_HISTORIES/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#upsertWithWhere
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/EXEC_DETAIL_HISTORIES/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#exists
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/EXEC_DETAIL_HISTORIES/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#findById
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/EXEC_DETAIL_HISTORIES/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#replaceById
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/EXEC_DETAIL_HISTORIES/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#find
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/EXEC_DETAIL_HISTORIES",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#findOne
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/EXEC_DETAIL_HISTORIES/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#updateAll
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
            "updateAll": {
              url: urlBase + "/EXEC_DETAIL_HISTORIES/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#deleteById
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/EXEC_DETAIL_HISTORIES/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#count
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/EXEC_DETAIL_HISTORIES/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#prototype$updateAttributes
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
            "prototype$updateAttributes": {
              url: urlBase + "/EXEC_DETAIL_HISTORIES/:id",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#createChangeStream
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/EXEC_DETAIL_HISTORIES/change-stream",
              method: "POST",
            },

            // INTERNAL. Use EXEC_HISTORY.execDetails.findById() instead.
            "::findById::EXEC_HISTORY::execDetails": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/EXEC_HISTORIES/:id/execDetails/:fk",
              method: "GET",
            },

            // INTERNAL. Use EXEC_HISTORY.execDetails.destroyById() instead.
            "::destroyById::EXEC_HISTORY::execDetails": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/EXEC_HISTORIES/:id/execDetails/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use EXEC_HISTORY.execDetails.updateById() instead.
            "::updateById::EXEC_HISTORY::execDetails": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/EXEC_HISTORIES/:id/execDetails/:fk",
              method: "PUT",
            },

            // INTERNAL. Use EXEC_HISTORY.execDetails() instead.
            "::get::EXEC_HISTORY::execDetails": {
              isArray: true,
              url: urlBase + "/EXEC_HISTORIES/:id/execDetails",
              method: "GET",
            },

            // INTERNAL. Use EXEC_HISTORY.execDetails.create() instead.
            "::create::EXEC_HISTORY::execDetails": {
              url: urlBase + "/EXEC_HISTORIES/:id/execDetails",
              method: "POST",
            },

            // INTERNAL. Use EXEC_HISTORY.execDetails.createMany() instead.
            "::createMany::EXEC_HISTORY::execDetails": {
              isArray: true,
              url: urlBase + "/EXEC_HISTORIES/:id/execDetails",
              method: "POST",
            },

            // INTERNAL. Use EXEC_HISTORY.execDetails.destroyAll() instead.
            "::delete::EXEC_HISTORY::execDetails": {
              url: urlBase + "/EXEC_HISTORIES/:id/execDetails",
              method: "DELETE",
            },

            // INTERNAL. Use EXEC_HISTORY.execDetails.count() instead.
            "::count::EXEC_HISTORY::execDetails": {
              url: urlBase + "/EXEC_HISTORIES/:id/execDetails/count",
              method: "GET",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#patchOrCreate
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
        R["patchOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#updateOrCreate
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
        R["updateOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#patchOrCreateWithWhere
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#update
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#destroyById
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#removeById
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.EXEC_DETAIL_HISTORY#patchAttributes
             * @methodOf lbServices.EXEC_DETAIL_HISTORY
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `EXEC_DETAIL_HISTORY` object.)
             * </em>
             */
        R["patchAttributes"] = R["prototype$updateAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.EXEC_DETAIL_HISTORY#modelName
        * @propertyOf lbServices.EXEC_DETAIL_HISTORY
        * @description
        * The name of the model represented by this $resource,
        * i.e. `EXEC_DETAIL_HISTORY`.
        */
        R.modelName = "EXEC_DETAIL_HISTORY";



        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.ST_ATL_HISTORY
 * @header lbServices.ST_ATL_HISTORY
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `ST_ATL_HISTORY` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "ST_ATL_HISTORY",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/ST_ATL_HISTORIES/:id",
          { 'id': '@id' },
          {

            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#create
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/ST_ATL_HISTORIES",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#createMany
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/ST_ATL_HISTORIES",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#upsert
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
            "upsert": {
              url: urlBase + "/ST_ATL_HISTORIES",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#replaceOrCreate
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/ST_ATL_HISTORIES/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#upsertWithWhere
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/ST_ATL_HISTORIES/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#exists
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/ST_ATL_HISTORIES/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#findById
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/ST_ATL_HISTORIES/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#replaceById
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/ST_ATL_HISTORIES/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#find
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/ST_ATL_HISTORIES",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#findOne
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/ST_ATL_HISTORIES/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#updateAll
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
            "updateAll": {
              url: urlBase + "/ST_ATL_HISTORIES/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#deleteById
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/ST_ATL_HISTORIES/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#count
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/ST_ATL_HISTORIES/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#prototype$updateAttributes
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
            "prototype$updateAttributes": {
              url: urlBase + "/ST_ATL_HISTORIES/:id",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#createChangeStream
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/ST_ATL_HISTORIES/change-stream",
              method: "POST",
            },

            // INTERNAL. Use EXEC_HISTORY.stATL.findById() instead.
            "::findById::EXEC_HISTORY::stATL": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/EXEC_HISTORIES/:id/stATL/:fk",
              method: "GET",
            },

            // INTERNAL. Use EXEC_HISTORY.stATL.destroyById() instead.
            "::destroyById::EXEC_HISTORY::stATL": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/EXEC_HISTORIES/:id/stATL/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use EXEC_HISTORY.stATL.updateById() instead.
            "::updateById::EXEC_HISTORY::stATL": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/EXEC_HISTORIES/:id/stATL/:fk",
              method: "PUT",
            },

            // INTERNAL. Use EXEC_HISTORY.stATL() instead.
            "::get::EXEC_HISTORY::stATL": {
              isArray: true,
              url: urlBase + "/EXEC_HISTORIES/:id/stATL",
              method: "GET",
            },

            // INTERNAL. Use EXEC_HISTORY.stATL.create() instead.
            "::create::EXEC_HISTORY::stATL": {
              url: urlBase + "/EXEC_HISTORIES/:id/stATL",
              method: "POST",
            },

            // INTERNAL. Use EXEC_HISTORY.stATL.createMany() instead.
            "::createMany::EXEC_HISTORY::stATL": {
              isArray: true,
              url: urlBase + "/EXEC_HISTORIES/:id/stATL",
              method: "POST",
            },

            // INTERNAL. Use EXEC_HISTORY.stATL.destroyAll() instead.
            "::delete::EXEC_HISTORY::stATL": {
              url: urlBase + "/EXEC_HISTORIES/:id/stATL",
              method: "DELETE",
            },

            // INTERNAL. Use EXEC_HISTORY.stATL.count() instead.
            "::count::EXEC_HISTORY::stATL": {
              url: urlBase + "/EXEC_HISTORIES/:id/stATL/count",
              method: "GET",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#patchOrCreate
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
        R["patchOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#updateOrCreate
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
        R["updateOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#patchOrCreateWithWhere
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#update
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#destroyById
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#removeById
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.ST_ATL_HISTORY#patchAttributes
             * @methodOf lbServices.ST_ATL_HISTORY
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `ST_ATL_HISTORY` object.)
             * </em>
             */
        R["patchAttributes"] = R["prototype$updateAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.ST_ATL_HISTORY#modelName
        * @propertyOf lbServices.ST_ATL_HISTORY
        * @description
        * The name of the model represented by this $resource,
        * i.e. `ST_ATL_HISTORY`.
        */
        R.modelName = "ST_ATL_HISTORY";



        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.SIM_REQUEST
 * @header lbServices.SIM_REQUEST
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `SIM_REQUEST` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "SIM_REQUEST",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/SIM_REQUESTS/:id",
          { 'id': '@id' },
          {

            // INTERNAL. Use SIM_REQUEST.results.findById() instead.
            "prototype$__findById__results": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SIM_REQUESTS/:id/results/:fk",
              method: "GET",
            },

            // INTERNAL. Use SIM_REQUEST.results.destroyById() instead.
            "prototype$__destroyById__results": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SIM_REQUESTS/:id/results/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use SIM_REQUEST.results.updateById() instead.
            "prototype$__updateById__results": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SIM_REQUESTS/:id/results/:fk",
              method: "PUT",
            },

            // INTERNAL. Use SIM_REQUEST.results() instead.
            "prototype$__get__results": {
              isArray: true,
              url: urlBase + "/SIM_REQUESTS/:id/results",
              method: "GET",
            },

            // INTERNAL. Use SIM_REQUEST.results.create() instead.
            "prototype$__create__results": {
              url: urlBase + "/SIM_REQUESTS/:id/results",
              method: "POST",
            },

            // INTERNAL. Use SIM_REQUEST.results.destroyAll() instead.
            "prototype$__delete__results": {
              url: urlBase + "/SIM_REQUESTS/:id/results",
              method: "DELETE",
            },

            // INTERNAL. Use SIM_REQUEST.results.count() instead.
            "prototype$__count__results": {
              url: urlBase + "/SIM_REQUESTS/:id/results/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#create
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_REQUEST` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/SIM_REQUESTS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#createMany
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_REQUEST` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/SIM_REQUESTS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#upsert
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_REQUEST` object.)
             * </em>
             */
            "upsert": {
              url: urlBase + "/SIM_REQUESTS",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#replaceOrCreate
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_REQUEST` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/SIM_REQUESTS/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#upsertWithWhere
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_REQUEST` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/SIM_REQUESTS/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#exists
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/SIM_REQUESTS/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#findById
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_REQUEST` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/SIM_REQUESTS/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#replaceById
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_REQUEST` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/SIM_REQUESTS/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#find
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_REQUEST` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/SIM_REQUESTS",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#findOne
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_REQUEST` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/SIM_REQUESTS/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#updateAll
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
            "updateAll": {
              url: urlBase + "/SIM_REQUESTS/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#deleteById
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_REQUEST` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/SIM_REQUESTS/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#count
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/SIM_REQUESTS/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#prototype$updateAttributes
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_REQUEST` object.)
             * </em>
             */
            "prototype$updateAttributes": {
              url: urlBase + "/SIM_REQUESTS/:id",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#createChangeStream
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/SIM_REQUESTS/change-stream",
              method: "POST",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#patchOrCreate
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_REQUEST` object.)
             * </em>
             */
        R["patchOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#updateOrCreate
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_REQUEST` object.)
             * </em>
             */
        R["updateOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#patchOrCreateWithWhere
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_REQUEST` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#update
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#destroyById
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_REQUEST` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#removeById
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_REQUEST` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#patchAttributes
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_REQUEST` object.)
             * </em>
             */
        R["patchAttributes"] = R["prototype$updateAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.SIM_REQUEST#modelName
        * @propertyOf lbServices.SIM_REQUEST
        * @description
        * The name of the model represented by this $resource,
        * i.e. `SIM_REQUEST`.
        */
        R.modelName = "SIM_REQUEST";

    /**
     * @ngdoc object
     * @name lbServices.SIM_REQUEST.results
     * @header lbServices.SIM_REQUEST.results
     * @object
     * @description
     *
     * The object `SIM_REQUEST.results` groups methods
     * manipulating `SIM_RESULT` instances related to `SIM_REQUEST`.
     *
     * Call {@link lbServices.SIM_REQUEST#results SIM_REQUEST.results()}
     * to query all related instances.
     */


            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST#results
             * @methodOf lbServices.SIM_REQUEST
             *
             * @description
             *
             * Queries results of SIM_REQUEST.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `filter` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
        R.results = function() {
          var TargetResource = $injector.get("SIM_RESULT");
          var action = TargetResource["::get::SIM_REQUEST::results"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST.results#count
             * @methodOf lbServices.SIM_REQUEST.results
             *
             * @description
             *
             * Counts results of SIM_REQUEST.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
        R.results.count = function() {
          var TargetResource = $injector.get("SIM_RESULT");
          var action = TargetResource["::count::SIM_REQUEST::results"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST.results#create
             * @methodOf lbServices.SIM_REQUEST.results
             *
             * @description
             *
             * Creates a new instance in results of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
        R.results.create = function() {
          var TargetResource = $injector.get("SIM_RESULT");
          var action = TargetResource["::create::SIM_REQUEST::results"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST.results#createMany
             * @methodOf lbServices.SIM_REQUEST.results
             *
             * @description
             *
             * Creates a new instance in results of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
        R.results.createMany = function() {
          var TargetResource = $injector.get("SIM_RESULT");
          var action = TargetResource["::createMany::SIM_REQUEST::results"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST.results#destroyAll
             * @methodOf lbServices.SIM_REQUEST.results
             *
             * @description
             *
             * Deletes all results of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.results.destroyAll = function() {
          var TargetResource = $injector.get("SIM_RESULT");
          var action = TargetResource["::delete::SIM_REQUEST::results"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST.results#destroyById
             * @methodOf lbServices.SIM_REQUEST.results
             *
             * @description
             *
             * Delete a related item by id for results.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for results
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.results.destroyById = function() {
          var TargetResource = $injector.get("SIM_RESULT");
          var action = TargetResource["::destroyById::SIM_REQUEST::results"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST.results#findById
             * @methodOf lbServices.SIM_REQUEST.results
             *
             * @description
             *
             * Find a related item by id for results.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for results
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
        R.results.findById = function() {
          var TargetResource = $injector.get("SIM_RESULT");
          var action = TargetResource["::findById::SIM_REQUEST::results"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SIM_REQUEST.results#updateById
             * @methodOf lbServices.SIM_REQUEST.results
             *
             * @description
             *
             * Update a related item by id for results.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for results
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
        R.results.updateById = function() {
          var TargetResource = $injector.get("SIM_RESULT");
          var action = TargetResource["::updateById::SIM_REQUEST::results"];
          return action.apply(R, arguments);
        };


        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.SIM_RESULT
 * @header lbServices.SIM_RESULT
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `SIM_RESULT` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "SIM_RESULT",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/SIM_RESULTS/:id",
          { 'id': '@id' },
          {

            // INTERNAL. Use SIM_RESULT.atl_results.findById() instead.
            "prototype$__findById__atl_results": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SIM_RESULTS/:id/atl_results/:fk",
              method: "GET",
            },

            // INTERNAL. Use SIM_RESULT.atl_results.destroyById() instead.
            "prototype$__destroyById__atl_results": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SIM_RESULTS/:id/atl_results/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use SIM_RESULT.atl_results.updateById() instead.
            "prototype$__updateById__atl_results": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SIM_RESULTS/:id/atl_results/:fk",
              method: "PUT",
            },

            // INTERNAL. Use SIM_RESULT.atl_results() instead.
            "prototype$__get__atl_results": {
              isArray: true,
              url: urlBase + "/SIM_RESULTS/:id/atl_results",
              method: "GET",
            },

            // INTERNAL. Use SIM_RESULT.atl_results.create() instead.
            "prototype$__create__atl_results": {
              url: urlBase + "/SIM_RESULTS/:id/atl_results",
              method: "POST",
            },

            // INTERNAL. Use SIM_RESULT.atl_results.destroyAll() instead.
            "prototype$__delete__atl_results": {
              url: urlBase + "/SIM_RESULTS/:id/atl_results",
              method: "DELETE",
            },

            // INTERNAL. Use SIM_RESULT.atl_results.count() instead.
            "prototype$__count__atl_results": {
              url: urlBase + "/SIM_RESULTS/:id/atl_results/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#create
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/SIM_RESULTS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#createMany
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/SIM_RESULTS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#upsert
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
            "upsert": {
              url: urlBase + "/SIM_RESULTS",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#replaceOrCreate
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/SIM_RESULTS/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#upsertWithWhere
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/SIM_RESULTS/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#exists
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/SIM_RESULTS/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#findById
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/SIM_RESULTS/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#replaceById
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/SIM_RESULTS/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#find
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/SIM_RESULTS",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#findOne
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/SIM_RESULTS/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#updateAll
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
            "updateAll": {
              url: urlBase + "/SIM_RESULTS/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#deleteById
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/SIM_RESULTS/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#count
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/SIM_RESULTS/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#prototype$updateAttributes
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
            "prototype$updateAttributes": {
              url: urlBase + "/SIM_RESULTS/:id",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#createChangeStream
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/SIM_RESULTS/change-stream",
              method: "POST",
            },

            // INTERNAL. Use SIM_REQUEST.results.findById() instead.
            "::findById::SIM_REQUEST::results": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SIM_REQUESTS/:id/results/:fk",
              method: "GET",
            },

            // INTERNAL. Use SIM_REQUEST.results.destroyById() instead.
            "::destroyById::SIM_REQUEST::results": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SIM_REQUESTS/:id/results/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use SIM_REQUEST.results.updateById() instead.
            "::updateById::SIM_REQUEST::results": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SIM_REQUESTS/:id/results/:fk",
              method: "PUT",
            },

            // INTERNAL. Use SIM_REQUEST.results() instead.
            "::get::SIM_REQUEST::results": {
              isArray: true,
              url: urlBase + "/SIM_REQUESTS/:id/results",
              method: "GET",
            },

            // INTERNAL. Use SIM_REQUEST.results.create() instead.
            "::create::SIM_REQUEST::results": {
              url: urlBase + "/SIM_REQUESTS/:id/results",
              method: "POST",
            },

            // INTERNAL. Use SIM_REQUEST.results.createMany() instead.
            "::createMany::SIM_REQUEST::results": {
              isArray: true,
              url: urlBase + "/SIM_REQUESTS/:id/results",
              method: "POST",
            },

            // INTERNAL. Use SIM_REQUEST.results.destroyAll() instead.
            "::delete::SIM_REQUEST::results": {
              url: urlBase + "/SIM_REQUESTS/:id/results",
              method: "DELETE",
            },

            // INTERNAL. Use SIM_REQUEST.results.count() instead.
            "::count::SIM_REQUEST::results": {
              url: urlBase + "/SIM_REQUESTS/:id/results/count",
              method: "GET",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#patchOrCreate
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
        R["patchOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#updateOrCreate
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
        R["updateOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#patchOrCreateWithWhere
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#update
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#destroyById
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#removeById
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#patchAttributes
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_RESULT` object.)
             * </em>
             */
        R["patchAttributes"] = R["prototype$updateAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.SIM_RESULT#modelName
        * @propertyOf lbServices.SIM_RESULT
        * @description
        * The name of the model represented by this $resource,
        * i.e. `SIM_RESULT`.
        */
        R.modelName = "SIM_RESULT";

    /**
     * @ngdoc object
     * @name lbServices.SIM_RESULT.atl_results
     * @header lbServices.SIM_RESULT.atl_results
     * @object
     * @description
     *
     * The object `SIM_RESULT.atl_results` groups methods
     * manipulating `SIM_ASSIGNM_ATL` instances related to `SIM_RESULT`.
     *
     * Call {@link lbServices.SIM_RESULT#atl_results SIM_RESULT.atl_results()}
     * to query all related instances.
     */


            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT#atl_results
             * @methodOf lbServices.SIM_RESULT
             *
             * @description
             *
             * Queries atl_results of SIM_RESULT.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `filter` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
        R.atl_results = function() {
          var TargetResource = $injector.get("SIM_ASSIGNM_ATL");
          var action = TargetResource["::get::SIM_RESULT::atl_results"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT.atl_results#count
             * @methodOf lbServices.SIM_RESULT.atl_results
             *
             * @description
             *
             * Counts atl_results of SIM_RESULT.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
        R.atl_results.count = function() {
          var TargetResource = $injector.get("SIM_ASSIGNM_ATL");
          var action = TargetResource["::count::SIM_RESULT::atl_results"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT.atl_results#create
             * @methodOf lbServices.SIM_RESULT.atl_results
             *
             * @description
             *
             * Creates a new instance in atl_results of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
        R.atl_results.create = function() {
          var TargetResource = $injector.get("SIM_ASSIGNM_ATL");
          var action = TargetResource["::create::SIM_RESULT::atl_results"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT.atl_results#createMany
             * @methodOf lbServices.SIM_RESULT.atl_results
             *
             * @description
             *
             * Creates a new instance in atl_results of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
        R.atl_results.createMany = function() {
          var TargetResource = $injector.get("SIM_ASSIGNM_ATL");
          var action = TargetResource["::createMany::SIM_RESULT::atl_results"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT.atl_results#destroyAll
             * @methodOf lbServices.SIM_RESULT.atl_results
             *
             * @description
             *
             * Deletes all atl_results of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.atl_results.destroyAll = function() {
          var TargetResource = $injector.get("SIM_ASSIGNM_ATL");
          var action = TargetResource["::delete::SIM_RESULT::atl_results"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT.atl_results#destroyById
             * @methodOf lbServices.SIM_RESULT.atl_results
             *
             * @description
             *
             * Delete a related item by id for atl_results.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for atl_results
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.atl_results.destroyById = function() {
          var TargetResource = $injector.get("SIM_ASSIGNM_ATL");
          var action = TargetResource["::destroyById::SIM_RESULT::atl_results"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT.atl_results#findById
             * @methodOf lbServices.SIM_RESULT.atl_results
             *
             * @description
             *
             * Find a related item by id for atl_results.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for atl_results
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
        R.atl_results.findById = function() {
          var TargetResource = $injector.get("SIM_ASSIGNM_ATL");
          var action = TargetResource["::findById::SIM_RESULT::atl_results"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.SIM_RESULT.atl_results#updateById
             * @methodOf lbServices.SIM_RESULT.atl_results
             *
             * @description
             *
             * Update a related item by id for atl_results.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             *  - `fk` – `{*}` - Foreign key for atl_results
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
        R.atl_results.updateById = function() {
          var TargetResource = $injector.get("SIM_ASSIGNM_ATL");
          var action = TargetResource["::updateById::SIM_RESULT::atl_results"];
          return action.apply(R, arguments);
        };


        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.SIM_ASSIGNM_ATL
 * @header lbServices.SIM_ASSIGNM_ATL
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `SIM_ASSIGNM_ATL` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "SIM_ASSIGNM_ATL",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/SIM_ASSIGNM_ATLS/:id",
          { 'id': '@id' },
          {

            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#create
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/SIM_ASSIGNM_ATLS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#createMany
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/SIM_ASSIGNM_ATLS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#upsert
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
            "upsert": {
              url: urlBase + "/SIM_ASSIGNM_ATLS",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#replaceOrCreate
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/SIM_ASSIGNM_ATLS/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#upsertWithWhere
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/SIM_ASSIGNM_ATLS/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#exists
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/SIM_ASSIGNM_ATLS/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#findById
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/SIM_ASSIGNM_ATLS/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#replaceById
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/SIM_ASSIGNM_ATLS/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#find
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/SIM_ASSIGNM_ATLS",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#findOne
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/SIM_ASSIGNM_ATLS/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#updateAll
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
            "updateAll": {
              url: urlBase + "/SIM_ASSIGNM_ATLS/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#deleteById
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/SIM_ASSIGNM_ATLS/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#count
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/SIM_ASSIGNM_ATLS/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#prototype$updateAttributes
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
            "prototype$updateAttributes": {
              url: urlBase + "/SIM_ASSIGNM_ATLS/:id",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#createChangeStream
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/SIM_ASSIGNM_ATLS/change-stream",
              method: "POST",
            },

            // INTERNAL. Use SIM_RESULT.atl_results.findById() instead.
            "::findById::SIM_RESULT::atl_results": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SIM_RESULTS/:id/atl_results/:fk",
              method: "GET",
            },

            // INTERNAL. Use SIM_RESULT.atl_results.destroyById() instead.
            "::destroyById::SIM_RESULT::atl_results": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SIM_RESULTS/:id/atl_results/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use SIM_RESULT.atl_results.updateById() instead.
            "::updateById::SIM_RESULT::atl_results": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/SIM_RESULTS/:id/atl_results/:fk",
              method: "PUT",
            },

            // INTERNAL. Use SIM_RESULT.atl_results() instead.
            "::get::SIM_RESULT::atl_results": {
              isArray: true,
              url: urlBase + "/SIM_RESULTS/:id/atl_results",
              method: "GET",
            },

            // INTERNAL. Use SIM_RESULT.atl_results.create() instead.
            "::create::SIM_RESULT::atl_results": {
              url: urlBase + "/SIM_RESULTS/:id/atl_results",
              method: "POST",
            },

            // INTERNAL. Use SIM_RESULT.atl_results.createMany() instead.
            "::createMany::SIM_RESULT::atl_results": {
              isArray: true,
              url: urlBase + "/SIM_RESULTS/:id/atl_results",
              method: "POST",
            },

            // INTERNAL. Use SIM_RESULT.atl_results.destroyAll() instead.
            "::delete::SIM_RESULT::atl_results": {
              url: urlBase + "/SIM_RESULTS/:id/atl_results",
              method: "DELETE",
            },

            // INTERNAL. Use SIM_RESULT.atl_results.count() instead.
            "::count::SIM_RESULT::atl_results": {
              url: urlBase + "/SIM_RESULTS/:id/atl_results/count",
              method: "GET",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#patchOrCreate
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
        R["patchOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#updateOrCreate
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
        R["updateOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#patchOrCreateWithWhere
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#update
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#destroyById
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#removeById
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.SIM_ASSIGNM_ATL#patchAttributes
             * @methodOf lbServices.SIM_ASSIGNM_ATL
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `SIM_ASSIGNM_ATL` object.)
             * </em>
             */
        R["patchAttributes"] = R["prototype$updateAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.SIM_ASSIGNM_ATL#modelName
        * @propertyOf lbServices.SIM_ASSIGNM_ATL
        * @description
        * The name of the model represented by this $resource,
        * i.e. `SIM_ASSIGNM_ATL`.
        */
        R.modelName = "SIM_ASSIGNM_ATL";



        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.TM_ASSIGNM_CHANGE_LOG
 * @header lbServices.TM_ASSIGNM_CHANGE_LOG
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `TM_ASSIGNM_CHANGE_LOG` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "TM_ASSIGNM_CHANGE_LOG",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/TM_ASSIGNM_CHANGE_LOGS/:id",
          { 'id': '@id' },
          {

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#create
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_CHANGE_LOG` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/TM_ASSIGNM_CHANGE_LOGS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#createMany
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_CHANGE_LOG` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/TM_ASSIGNM_CHANGE_LOGS",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#upsert
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_CHANGE_LOG` object.)
             * </em>
             */
            "upsert": {
              url: urlBase + "/TM_ASSIGNM_CHANGE_LOGS",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#replaceOrCreate
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_CHANGE_LOG` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/TM_ASSIGNM_CHANGE_LOGS/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#upsertWithWhere
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_CHANGE_LOG` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/TM_ASSIGNM_CHANGE_LOGS/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#exists
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/TM_ASSIGNM_CHANGE_LOGS/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#findById
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_CHANGE_LOG` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/TM_ASSIGNM_CHANGE_LOGS/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#replaceById
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_CHANGE_LOG` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/TM_ASSIGNM_CHANGE_LOGS/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#find
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_CHANGE_LOG` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/TM_ASSIGNM_CHANGE_LOGS",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#findOne
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_CHANGE_LOG` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/TM_ASSIGNM_CHANGE_LOGS/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#updateAll
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
            "updateAll": {
              url: urlBase + "/TM_ASSIGNM_CHANGE_LOGS/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#deleteById
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_CHANGE_LOG` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/TM_ASSIGNM_CHANGE_LOGS/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#count
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/TM_ASSIGNM_CHANGE_LOGS/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#prototype$updateAttributes
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_CHANGE_LOG` object.)
             * </em>
             */
            "prototype$updateAttributes": {
              url: urlBase + "/TM_ASSIGNM_CHANGE_LOGS/:id",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#createChangeStream
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/TM_ASSIGNM_CHANGE_LOGS/change-stream",
              method: "POST",
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#patchOrCreate
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_CHANGE_LOG` object.)
             * </em>
             */
        R["patchOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#updateOrCreate
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_CHANGE_LOG` object.)
             * </em>
             */
        R["updateOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#patchOrCreateWithWhere
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_CHANGE_LOG` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#update
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#destroyById
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_CHANGE_LOG` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#removeById
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_CHANGE_LOG` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.TM_ASSIGNM_CHANGE_LOG#patchAttributes
             * @methodOf lbServices.TM_ASSIGNM_CHANGE_LOG
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - PersistedModel id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `TM_ASSIGNM_CHANGE_LOG` object.)
             * </em>
             */
        R["patchAttributes"] = R["prototype$updateAttributes"];


        /**
        * @ngdoc property
        * @name lbServices.TM_ASSIGNM_CHANGE_LOG#modelName
        * @propertyOf lbServices.TM_ASSIGNM_CHANGE_LOG
        * @description
        * The name of the model represented by this $resource,
        * i.e. `TM_ASSIGNM_CHANGE_LOG`.
        */
        R.modelName = "TM_ASSIGNM_CHANGE_LOG";



        return R;
      }]);

/**
 * @ngdoc object
 * @name lbServices.User
 * @header lbServices.User
 * @object
 *
 * @description
 *
 * A $resource object for interacting with the `User` model.
 *
 * ## Example
 *
 * See
 * {@link http://docs.angularjs.org/api/ngResource.$resource#example $resource}
 * for an example of using this object.
 *
 */
  module.factory(
    "User",
    [
      'LoopBackResource', 'LoopBackAuth', '$injector', '$q',
      function(LoopBackResource, LoopBackAuth, $injector, $q) {
        var R = LoopBackResource(
        urlBase + "/users/:id",
          { 'id': '@id' },
          {

            /**
             * @ngdoc method
             * @name lbServices.User#prototype$__findById__accessTokens
             * @methodOf lbServices.User
             *
             * @description
             *
             * Find a related item by id for accessTokens.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             *  - `fk` – `{*}` - Foreign key for accessTokens
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
            "prototype$__findById__accessTokens": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/users/:id/accessTokens/:fk",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#prototype$__destroyById__accessTokens
             * @methodOf lbServices.User
             *
             * @description
             *
             * Delete a related item by id for accessTokens.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             *  - `fk` – `{*}` - Foreign key for accessTokens
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
            "prototype$__destroyById__accessTokens": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/users/:id/accessTokens/:fk",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#prototype$__updateById__accessTokens
             * @methodOf lbServices.User
             *
             * @description
             *
             * Update a related item by id for accessTokens.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             *  - `fk` – `{*}` - Foreign key for accessTokens
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
            "prototype$__updateById__accessTokens": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/users/:id/accessTokens/:fk",
              method: "PUT",
            },

            // INTERNAL. Use User.identities.findById() instead.
            "prototype$__findById__identities": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/users/:id/identities/:fk",
              method: "GET",
            },

            // INTERNAL. Use User.identities.destroyById() instead.
            "prototype$__destroyById__identities": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/users/:id/identities/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use User.identities.updateById() instead.
            "prototype$__updateById__identities": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/users/:id/identities/:fk",
              method: "PUT",
            },

            // INTERNAL. Use User.credentials.findById() instead.
            "prototype$__findById__credentials": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/users/:id/credentials/:fk",
              method: "GET",
            },

            // INTERNAL. Use User.credentials.destroyById() instead.
            "prototype$__destroyById__credentials": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/users/:id/credentials/:fk",
              method: "DELETE",
            },

            // INTERNAL. Use User.credentials.updateById() instead.
            "prototype$__updateById__credentials": {
              params: {
                'fk': '@fk',
              },
              url: urlBase + "/users/:id/credentials/:fk",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#prototype$__get__accessTokens
             * @methodOf lbServices.User
             *
             * @description
             *
             * Queries accessTokens of user.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             *  - `filter` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
            "prototype$__get__accessTokens": {
              isArray: true,
              url: urlBase + "/users/:id/accessTokens",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#prototype$__create__accessTokens
             * @methodOf lbServices.User
             *
             * @description
             *
             * Creates a new instance in accessTokens of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
            "prototype$__create__accessTokens": {
              url: urlBase + "/users/:id/accessTokens",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#prototype$__delete__accessTokens
             * @methodOf lbServices.User
             *
             * @description
             *
             * Deletes all accessTokens of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
            "prototype$__delete__accessTokens": {
              url: urlBase + "/users/:id/accessTokens",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#prototype$__count__accessTokens
             * @methodOf lbServices.User
             *
             * @description
             *
             * Counts accessTokens of user.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "prototype$__count__accessTokens": {
              url: urlBase + "/users/:id/accessTokens/count",
              method: "GET",
            },

            // INTERNAL. Use User.identities() instead.
            "prototype$__get__identities": {
              isArray: true,
              url: urlBase + "/users/:id/identities",
              method: "GET",
            },

            // INTERNAL. Use User.identities.create() instead.
            "prototype$__create__identities": {
              url: urlBase + "/users/:id/identities",
              method: "POST",
            },

            // INTERNAL. Use User.identities.destroyAll() instead.
            "prototype$__delete__identities": {
              url: urlBase + "/users/:id/identities",
              method: "DELETE",
            },

            // INTERNAL. Use User.identities.count() instead.
            "prototype$__count__identities": {
              url: urlBase + "/users/:id/identities/count",
              method: "GET",
            },

            // INTERNAL. Use User.credentials() instead.
            "prototype$__get__credentials": {
              isArray: true,
              url: urlBase + "/users/:id/credentials",
              method: "GET",
            },

            // INTERNAL. Use User.credentials.create() instead.
            "prototype$__create__credentials": {
              url: urlBase + "/users/:id/credentials",
              method: "POST",
            },

            // INTERNAL. Use User.credentials.destroyAll() instead.
            "prototype$__delete__credentials": {
              url: urlBase + "/users/:id/credentials",
              method: "DELETE",
            },

            // INTERNAL. Use User.credentials.count() instead.
            "prototype$__count__credentials": {
              url: urlBase + "/users/:id/credentials/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#create
             * @methodOf lbServices.User
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
            "create": {
              url: urlBase + "/users",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#createMany
             * @methodOf lbServices.User
             *
             * @description
             *
             * Create a new instance of the model and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
            "createMany": {
              isArray: true,
              url: urlBase + "/users",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#upsert
             * @methodOf lbServices.User
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
            "upsert": {
              url: urlBase + "/users",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#replaceOrCreate
             * @methodOf lbServices.User
             *
             * @description
             *
             * Replace an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
            "replaceOrCreate": {
              url: urlBase + "/users/replaceOrCreate",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#upsertWithWhere
             * @methodOf lbServices.User
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
            "upsertWithWhere": {
              url: urlBase + "/users/upsertWithWhere",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#exists
             * @methodOf lbServices.User
             *
             * @description
             *
             * Check whether a model instance exists in the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `exists` – `{boolean=}` -
             */
            "exists": {
              url: urlBase + "/users/:id/exists",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#findById
             * @methodOf lbServices.User
             *
             * @description
             *
             * Find a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             *  - `filter` – `{object=}` - Filter defining fields and include
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
            "findById": {
              url: urlBase + "/users/:id",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#replaceById
             * @methodOf lbServices.User
             *
             * @description
             *
             * Replace attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
            "replaceById": {
              url: urlBase + "/users/:id/replace",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#find
             * @methodOf lbServices.User
             *
             * @description
             *
             * Find all instances of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
            "find": {
              isArray: true,
              url: urlBase + "/users",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#findOne
             * @methodOf lbServices.User
             *
             * @description
             *
             * Find first instance of the model matched by filter from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `filter` – `{object=}` - Filter defining fields, where, include, order, offset, and limit
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
            "findOne": {
              url: urlBase + "/users/findOne",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#updateAll
             * @methodOf lbServices.User
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
            "updateAll": {
              url: urlBase + "/users/update",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#deleteById
             * @methodOf lbServices.User
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
            "deleteById": {
              url: urlBase + "/users/:id",
              method: "DELETE",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#count
             * @methodOf lbServices.User
             *
             * @description
             *
             * Count instances of the model matched by where from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
            "count": {
              url: urlBase + "/users/count",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#prototype$updateAttributes
             * @methodOf lbServices.User
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
            "prototype$updateAttributes": {
              url: urlBase + "/users/:id",
              method: "PUT",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#createChangeStream
             * @methodOf lbServices.User
             *
             * @description
             *
             * Create a change stream.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `options` – `{object=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `changes` – `{ReadableStream=}` -
             */
            "createChangeStream": {
              url: urlBase + "/users/change-stream",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#login
             * @methodOf lbServices.User
             *
             * @description
             *
             * Login a user with username/email and password.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `include` – `{string=}` - Related objects to include in the response. See the description of return value for more details.
             *   Default value: `user`.
             *
             *  - `rememberMe` - `boolean` - Whether the authentication credentials
             *     should be remembered in localStorage across app/browser restarts.
             *     Default: `true`.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The response body contains properties of the AccessToken created on login.
             * Depending on the value of `include` parameter, the body may contain additional properties:
             *   - `user` - `U+007BUserU+007D` - Data of the currently logged in user. (`include=user`)
             *
             */
            "login": {
              params: {
                include: 'user',
              },
              interceptor: {
                response: function(response) {
                  var accessToken = response.data;
                  LoopBackAuth.setUser(accessToken.id, accessToken.user.userId, accessToken.user);
                  LoopBackAuth.rememberMe =
                    response.config.params.rememberMe !== false;
                  LoopBackAuth.save();
                  return response.resource;
                },
              },
              url: urlBase + "/auth/ldap",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#logout
             * @methodOf lbServices.User
             *
             * @description
             *
             * Logout a user with access token.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             *  - `access_token` – `{string}` - Do not supply this argument, it is automatically extracted from request headers.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
            "logout": {
              interceptor: {
                response: function(response) {
                  LoopBackAuth.clearUser();
                  LoopBackAuth.clearStorage();
                  return response.resource;
                },
                responseError: function(responseError) {
                  LoopBackAuth.clearUser();
                  LoopBackAuth.clearStorage();
                  return responseError.resource;
                },
              },
              url: urlBase + "/users/logout",
              method: "POST",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#confirm
             * @methodOf lbServices.User
             *
             * @description
             *
             * Confirm a user registration with email verification token.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `uid` – `{string}` -
             *
             *  - `token` – `{string}` -
             *
             *  - `redirect` – `{string=}` -
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
            "confirm": {
              url: urlBase + "/users/confirm",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#resetPassword
             * @methodOf lbServices.User
             *
             * @description
             *
             * Reset password for a user with email.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
            "resetPassword": {
              url: urlBase + "/users/reset",
              method: "POST",
            },

            // INTERNAL. Use UserIdentity.user() instead.
            "::get::UserIdentity::user": {
              url: urlBase + "/UserIdentities/:id/user",
              method: "GET",
            },

            // INTERNAL. Use UserCredential.user() instead.
            "::get::UserCredential::user": {
              url: urlBase + "/UserCredentials/:id/user",
              method: "GET",
            },

            /**
             * @ngdoc method
             * @name lbServices.User#getCurrent
             * @methodOf lbServices.User
             *
             * @description
             *
             * Get data of the currently logged user. Fail with HTTP result 401
             * when there is no user logged in.
             *
             * @param {function(Object,Object)=} successCb
             *    Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *    `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             */
            'getCurrent': {
              url: urlBase + "/users" + '/:id',
              method: 'GET',
              params: {
                id: function() {
                  var id = LoopBackAuth.currentUserId;
                  if (id == null) id = '__anonymous__';
                  return id;
                },
              },
              interceptor: {
                response: function(response) {
                  LoopBackAuth.currentUserData = response.data;
                  return response.resource;
                },
                responseError: function(responseError) {
                  LoopBackAuth.clearUser();
                  LoopBackAuth.clearStorage();
                  return $q.reject(responseError);
                },
              },
              __isGetCurrentUser__: true,
            },
          }
        );



            /**
             * @ngdoc method
             * @name lbServices.User#patchOrCreate
             * @methodOf lbServices.User
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
        R["patchOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.User#updateOrCreate
             * @methodOf lbServices.User
             *
             * @description
             *
             * Patch an existing model instance or insert a new one into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *   This method does not accept any parameters.
             *   Supply an empty object or omit this argument altogether.
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
        R["updateOrCreate"] = R["upsert"];

            /**
             * @ngdoc method
             * @name lbServices.User#patchOrCreateWithWhere
             * @methodOf lbServices.User
             *
             * @description
             *
             * Update an existing model instance or insert a new one into the data source based on the where criteria.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
        R["patchOrCreateWithWhere"] = R["upsertWithWhere"];

            /**
             * @ngdoc method
             * @name lbServices.User#update
             * @methodOf lbServices.User
             *
             * @description
             *
             * Update instances of the model matched by {{where}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * The number of instances updated
             */
        R["update"] = R["updateAll"];

            /**
             * @ngdoc method
             * @name lbServices.User#destroyById
             * @methodOf lbServices.User
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
        R["destroyById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.User#removeById
             * @methodOf lbServices.User
             *
             * @description
             *
             * Delete a model instance by {{id}} from the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - Model id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
        R["removeById"] = R["deleteById"];

            /**
             * @ngdoc method
             * @name lbServices.User#patchAttributes
             * @methodOf lbServices.User
             *
             * @description
             *
             * Patch attributes for a model instance and persist it into the data source.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `User` object.)
             * </em>
             */
        R["patchAttributes"] = R["prototype$updateAttributes"];

        /**
         * @ngdoc method
         * @name lbServices.User#getCachedCurrent
         * @methodOf lbServices.User
         *
         * @description
         *
         * Get data of the currently logged user that was returned by the last
         * call to {@link lbServices.User#login} or
         * {@link lbServices.User#getCurrent}. Return null when there
         * is no user logged in or the data of the current user were not fetched
         * yet.
         *
         * @returns {Object} A User instance.
         */
        R.getCachedCurrent = function() {
          var data = LoopBackAuth.currentUserData;
          return data ? new R(data) : null;
        };

        /**
         * @ngdoc method
         * @name lbServices.User#isAuthenticated
         * @methodOf lbServices.User
         *
         * @returns {boolean} True if the current user is authenticated (logged in).
         */
        R.isAuthenticated = function() {
          return this.getCurrentId() != null;
        };

        /**
         * @ngdoc method
         * @name lbServices.User#getCurrentId
         * @methodOf lbServices.User
         *
         * @returns {Object} Id of the currently logged-in user or null.
         */
        R.getCurrentId = function() {
          return LoopBackAuth.currentUserId;
        };

        /**
        * @ngdoc property
        * @name lbServices.User#modelName
        * @propertyOf lbServices.User
        * @description
        * The name of the model represented by this $resource,
        * i.e. `User`.
        */
        R.modelName = "User";

    /**
     * @ngdoc object
     * @name lbServices.User.identities
     * @header lbServices.User.identities
     * @object
     * @description
     *
     * The object `User.identities` groups methods
     * manipulating `UserIdentity` instances related to `User`.
     *
     * Call {@link lbServices.User#identities User.identities()}
     * to query all related instances.
     */


            /**
             * @ngdoc method
             * @name lbServices.User#identities
             * @methodOf lbServices.User
             *
             * @description
             *
             * Queries identities of user.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             *  - `filter` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
        R.identities = function() {
          var TargetResource = $injector.get("UserIdentity");
          var action = TargetResource["::get::User::identities"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.User.identities#count
             * @methodOf lbServices.User.identities
             *
             * @description
             *
             * Counts identities of user.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
        R.identities.count = function() {
          var TargetResource = $injector.get("UserIdentity");
          var action = TargetResource["::count::User::identities"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.User.identities#create
             * @methodOf lbServices.User.identities
             *
             * @description
             *
             * Creates a new instance in identities of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
        R.identities.create = function() {
          var TargetResource = $injector.get("UserIdentity");
          var action = TargetResource["::create::User::identities"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.User.identities#createMany
             * @methodOf lbServices.User.identities
             *
             * @description
             *
             * Creates a new instance in identities of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
        R.identities.createMany = function() {
          var TargetResource = $injector.get("UserIdentity");
          var action = TargetResource["::createMany::User::identities"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.User.identities#destroyAll
             * @methodOf lbServices.User.identities
             *
             * @description
             *
             * Deletes all identities of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.identities.destroyAll = function() {
          var TargetResource = $injector.get("UserIdentity");
          var action = TargetResource["::delete::User::identities"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.User.identities#destroyById
             * @methodOf lbServices.User.identities
             *
             * @description
             *
             * Delete a related item by id for identities.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             *  - `fk` – `{*}` - Foreign key for identities
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.identities.destroyById = function() {
          var TargetResource = $injector.get("UserIdentity");
          var action = TargetResource["::destroyById::User::identities"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.User.identities#findById
             * @methodOf lbServices.User.identities
             *
             * @description
             *
             * Find a related item by id for identities.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             *  - `fk` – `{*}` - Foreign key for identities
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
        R.identities.findById = function() {
          var TargetResource = $injector.get("UserIdentity");
          var action = TargetResource["::findById::User::identities"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.User.identities#updateById
             * @methodOf lbServices.User.identities
             *
             * @description
             *
             * Update a related item by id for identities.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             *  - `fk` – `{*}` - Foreign key for identities
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserIdentity` object.)
             * </em>
             */
        R.identities.updateById = function() {
          var TargetResource = $injector.get("UserIdentity");
          var action = TargetResource["::updateById::User::identities"];
          return action.apply(R, arguments);
        };
    /**
     * @ngdoc object
     * @name lbServices.User.credentials
     * @header lbServices.User.credentials
     * @object
     * @description
     *
     * The object `User.credentials` groups methods
     * manipulating `UserCredential` instances related to `User`.
     *
     * Call {@link lbServices.User#credentials User.credentials()}
     * to query all related instances.
     */


            /**
             * @ngdoc method
             * @name lbServices.User#credentials
             * @methodOf lbServices.User
             *
             * @description
             *
             * Queries credentials of user.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             *  - `filter` – `{object=}` -
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
        R.credentials = function() {
          var TargetResource = $injector.get("UserCredential");
          var action = TargetResource["::get::User::credentials"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.User.credentials#count
             * @methodOf lbServices.User.credentials
             *
             * @description
             *
             * Counts credentials of user.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             *  - `where` – `{object=}` - Criteria to match model instances
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * Data properties:
             *
             *  - `count` – `{number=}` -
             */
        R.credentials.count = function() {
          var TargetResource = $injector.get("UserCredential");
          var action = TargetResource["::count::User::credentials"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.User.credentials#create
             * @methodOf lbServices.User.credentials
             *
             * @description
             *
             * Creates a new instance in credentials of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
        R.credentials.create = function() {
          var TargetResource = $injector.get("UserCredential");
          var action = TargetResource["::create::User::credentials"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.User.credentials#createMany
             * @methodOf lbServices.User.credentials
             *
             * @description
             *
             * Creates a new instance in credentials of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Array.<Object>,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Array.<Object>} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
        R.credentials.createMany = function() {
          var TargetResource = $injector.get("UserCredential");
          var action = TargetResource["::createMany::User::credentials"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.User.credentials#destroyAll
             * @methodOf lbServices.User.credentials
             *
             * @description
             *
             * Deletes all credentials of this model.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.credentials.destroyAll = function() {
          var TargetResource = $injector.get("UserCredential");
          var action = TargetResource["::delete::User::credentials"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.User.credentials#destroyById
             * @methodOf lbServices.User.credentials
             *
             * @description
             *
             * Delete a related item by id for credentials.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             *  - `fk` – `{*}` - Foreign key for credentials
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * This method returns no data.
             */
        R.credentials.destroyById = function() {
          var TargetResource = $injector.get("UserCredential");
          var action = TargetResource["::destroyById::User::credentials"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.User.credentials#findById
             * @methodOf lbServices.User.credentials
             *
             * @description
             *
             * Find a related item by id for credentials.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             *  - `fk` – `{*}` - Foreign key for credentials
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
        R.credentials.findById = function() {
          var TargetResource = $injector.get("UserCredential");
          var action = TargetResource["::findById::User::credentials"];
          return action.apply(R, arguments);
        };

            /**
             * @ngdoc method
             * @name lbServices.User.credentials#updateById
             * @methodOf lbServices.User.credentials
             *
             * @description
             *
             * Update a related item by id for credentials.
             *
             * @param {Object=} parameters Request parameters.
             *
             *  - `id` – `{*}` - User id
             *
             *  - `fk` – `{*}` - Foreign key for credentials
             *
             * @param {Object} postData Request data.
             *
             * This method expects a subset of model properties as request parameters.
             *
             * @param {function(Object,Object)=} successCb
             *   Success callback with two arguments: `value`, `responseHeaders`.
             *
             * @param {function(Object)=} errorCb Error callback with one argument:
             *   `httpResponse`.
             *
             * @returns {Object} An empty reference that will be
             *   populated with the actual data once the response is returned
             *   from the server.
             *
             * <em>
             * (The remote method definition does not provide any description.
             * This usually means the response is a `UserCredential` object.)
             * </em>
             */
        R.credentials.updateById = function() {
          var TargetResource = $injector.get("UserCredential");
          var action = TargetResource["::updateById::User::credentials"];
          return action.apply(R, arguments);
        };


        return R;
      }]);


  module
  .factory('LoopBackAuth', function() {
    var props = ['accessTokenId', 'currentUserId', 'rememberMe'];
    var propsPrefix = '$LoopBack$';

    function LoopBackAuth() {
      var self = this;
      props.forEach(function(name) {
        self[name] = load(name);
      });
      this.currentUserData = null;
    }

    LoopBackAuth.prototype.save = function() {
      var self = this;
      var storage = this.rememberMe ? localStorage : sessionStorage;
      props.forEach(function(name) {
        save(storage, name, self[name]);
      });
    };

    LoopBackAuth.prototype.setUser = function(accessTokenId, userId, userData) {
      this.accessTokenId = accessTokenId;
      this.currentUserId = userId;
      this.currentUserData = userData;
    };

    LoopBackAuth.prototype.clearUser = function() {
      this.accessTokenId = null;
      this.currentUserId = null;
      this.currentUserData = null;
    };

    LoopBackAuth.prototype.clearStorage = function() {
      props.forEach(function(name) {
        save(sessionStorage, name, null);
        save(localStorage, name, null);
      });
    };

    return new LoopBackAuth();

    // Note: LocalStorage converts the value to string
    // We are using empty string as a marker for null/undefined values.
    function save(storage, name, value) {
      try {
        var key = propsPrefix + name;
        if (value == null) value = '';
        storage[key] = value;
      } catch (err) {
        console.log('Cannot access local/session storage:', err);
      }
    }

    function load(name) {
      var key = propsPrefix + name;
      return localStorage[key] || sessionStorage[key] || null;
    }
  })
  .config(['$httpProvider', function($httpProvider) {
    $httpProvider.interceptors.push('LoopBackAuthRequestInterceptor');
  }])
  .factory('LoopBackAuthRequestInterceptor', ['$q', 'LoopBackAuth',
    function($q, LoopBackAuth) {
      return {
        'request': function(config) {
          // filter out external requests
          var host = getHost(config.url);
          if (host && host !== urlBaseHost) {
            return config;
          }

          if (LoopBackAuth.accessTokenId) {
            config.headers[authHeader] = LoopBackAuth.accessTokenId;
          } else if (config.__isGetCurrentUser__) {
            // Return a stub 401 error for User.getCurrent() when
            // there is no user logged in
            var res = {
              body: { error: { status: 401 }},
              status: 401,
              config: config,
              headers: function() { return undefined; },
            };
            return $q.reject(res);
          }
          return config || $q.when(config);
        },
      };
    }])

  /**
   * @ngdoc object
   * @name lbServices.LoopBackResourceProvider
   * @header lbServices.LoopBackResourceProvider
   * @description
   * Use `LoopBackResourceProvider` to change the global configuration
   * settings used by all models. Note that the provider is available
   * to Configuration Blocks only, see
   * {@link https://docs.angularjs.org/guide/module#module-loading-dependencies Module Loading & Dependencies}
   * for more details.
   *
   * ## Example
   *
   * ```js
   * angular.module('app')
   *  .config(function(LoopBackResourceProvider) {
   *     LoopBackResourceProvider.setAuthHeader('X-Access-Token');
   *  });
   * ```
   */
  .provider('LoopBackResource', function LoopBackResourceProvider() {
    /**
     * @ngdoc method
     * @name lbServices.LoopBackResourceProvider#setAuthHeader
     * @methodOf lbServices.LoopBackResourceProvider
     * @param {string} header The header name to use, e.g. `X-Access-Token`
     * @description
     * Configure the REST transport to use a different header for sending
     * the authentication token. It is sent in the `Authorization` header
     * by default.
     */
    this.setAuthHeader = function(header) {
      authHeader = header;
    };

    /**
     * @ngdoc method
     * @name lbServices.LoopBackResourceProvider#getAuthHeader
     * @methodOf lbServices.LoopBackResourceProvider
     * @description
     * Get the header name that is used for sending the authentication token.
     */
    this.getAuthHeader = function() {
      return authHeader;
    };

    /**
     * @ngdoc method
     * @name lbServices.LoopBackResourceProvider#setUrlBase
     * @methodOf lbServices.LoopBackResourceProvider
     * @param {string} url The URL to use, e.g. `/api` or `//example.com/api`.
     * @description
     * Change the URL of the REST API server. By default, the URL provided
     * to the code generator (`lb-ng` or `grunt-loopback-sdk-angular`) is used.
     */
    this.setUrlBase = function(url) {
      urlBase = url;
      urlBaseHost = getHost(urlBase) || location.host;
    };

    /**
     * @ngdoc method
     * @name lbServices.LoopBackResourceProvider#getUrlBase
     * @methodOf lbServices.LoopBackResourceProvider
     * @description
     * Get the URL of the REST API server. The URL provided
     * to the code generator (`lb-ng` or `grunt-loopback-sdk-angular`) is used.
     */
    this.getUrlBase = function() {
      return urlBase;
    };

    this.$get = ['$resource', function($resource) {
      var LoopBackResource = function(url, params, actions) {
        var resource = $resource(url, params, actions);

        // Angular always calls POST on $save()
        // This hack is based on
        // http://kirkbushell.me/angular-js-using-ng-resource-in-a-more-restful-manner/
        resource.prototype.$save = function(success, error) {
          // Fortunately, LoopBack provides a convenient `upsert` method
          // that exactly fits our needs.
          var result = resource.upsert.call(this, {}, this, success, error);
          return result.$promise || result;
        };
        return resource;
      };

      LoopBackResource.getUrlBase = function() {
        return urlBase;
      };

      LoopBackResource.getAuthHeader = function() {
        return authHeader;
      };

      return LoopBackResource;
    }];
  });
})(window, window.angular);
