'use strict';

app.service('AppDropDownsService', [
    '$rootScope', 'Restangular', '_',
    function ($rootScope, Restangular, _) {

        // var selfService = this;
        //
        // selfService.userVorgs = [];
        //
        // selfService.appPreDefinedDropDowns = {
        //     'VCOUNTRY_ID': []
        // };
        //
        // selfService.dependantDropdowns = {};
        //
        // selfService.loadAppPreDefinedDropDowns = function() {
        //
        // };
        //
        // selfService.getDependantDropdowns = function(predefinedDropdowns) {
        //     var dependantDropdowns = {};
        //
        //     _.each(selfService.dependantDropdowns, function(value, key) {
        //         var keyParts = key.split('_2_');
        //         // console.log(keyParts);
        //         if(!_.isUndefined(predefinedDropdowns[keyParts[0]]) && !_.isUndefined(predefinedDropdowns[keyParts[1]])) {
        //             dependantDropdowns[key] = value;
        //         }
        //     });
        //
        //     return dependantDropdowns;
        // };
    }]
);
