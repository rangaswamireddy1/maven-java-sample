'use strict';

app.factory('RestService', ['AuthService', 'Restangular',
function(AuthService, Restangular) {

    return {
        _applyAuthorizationHeader: function(headers) {
            var requestHeaders = headers || {};
            if( AuthService.getJwt() !== undefined ) {
                requestHeaders.Authorization = "Bearer " + AuthService.getJwt()
            }
            return requestHeaders;
        },

        deleteOne: function(route, url) {
            return Restangular.one(route, url).remove();
        },

        patchOne: function(route, element, data) {
            return Restangular.one(route, element).customPATCH(data);
        },

        queryOne: function(route, queryParams, headers) {
            console.log('Query service through REST Service');
            var qry = queryParams || {};
            console.log('Query service through REST Service');
            return Restangular.one(route).get(qry, this._applyAuthorizationHeader(headers));
        },

        queryAll: function(route, queryParams, headers) {
            return Restangular.all(route).getList(queryParams, this._applyAuthorizationHeader(headers));
        },
        
        postOne: function(route, element, path, params, headers) {
            return Restangular.one(route).customPOST(element, path, params, this._applyAuthorizationHeader(headers));
        },

        postAll: function(route, element, path, params, headers) {
            return Restangular.all(route).customPOST(element, path, params, this._applyAuthorizationHeader(headers));
        }
    };

}]);
