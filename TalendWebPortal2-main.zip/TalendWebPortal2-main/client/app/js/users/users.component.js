'use strict';

var users = angular.module('users', []);

users.component('users', {
  templateUrl: 'js/users/users.template.html',

  controller: ['Restangular', '$mdEditDialog', '$q', '$timeout', '$mdDialog', '_', 'AppTableService', '$mdToast',
  function UserAdminController(Restangular, $mdEditDialog, $q, $timeout, $mdDialog, _, AppTableService, $mdToast) {
    var self = this;

    // Loopback model for component
    self.tableName = 'employee';

    self.modelName = 'employees';

    self.name = {
      singular: 'Employee',
      plural: 'Employees',
      title: 'Employees'
    };

    self.name.singularLcase = self.name.singular.toLowerCase();

    // Table options
   self.limitOptions = [10,20,50];

    self.options = {
      rowSelection: false,
      multiSelect: false,
      autoSelect: false,
      decapitate: false,
      largeEditDialog: false,
      boundaryLinks: false,
      limitSelect: true,
      pageSelect: true
    };

    // Search Filters
    self.filteredCollection = {};

    self.filterToggle = {
      state: false,
      tooltipText: {
        false: 'Show Filter',
        true: 'Hide Filter'
      }
    };

    self.query = {
      filter: {},
      order: 'first_name',
      orderDesc: false,
      limit: 15,
      page: 1,
      where: {},
      contains: ['role']
    };

    // Load rules via REST
    self.tableRecords = [];

    self.loadTableRecords = AppTableService.loadTableRecords;

    self.$onInit = function() {
      self.loadTableRecords();
    };

    self.fieldValidators = {
      'cwid': {'required': true},
      'first_name': {'required': true},
      'last_name': {'required': true},
      'role_id': {'required': true},
      'email': {'required': true}
    };

    self.predefinedDropdowns = {
        'role_id': {}
    };

    self.loadPredefinedDropdowns = function() {
        self.promise = Restangular.all('roles').getList();
        self.promise.then(function(records) {
            _.each(records, function(element) {
                self.predefinedDropdowns.role_id[element.id] = element.name;
            });
        });
    };
    self.loadPredefinedDropdowns();

    self.getUpdateDependantDropdown = AppTableService.getUpdateDependantDropdown;

    // getFilterValues: Gets unique and non-empty values for the filter dropdown of column
    self.getFilterValues = AppTableService.getFilterValues;

    self.resetFilter = AppTableService.resetFilter;

    self.clearFilter = AppTableService.clearFilter;

    self.filterDate = {};

    self.handleDateFilter = AppTableService.handleDateFilter;

    // Table toolbar buttons
    self.reloadTableData = AppTableService.reloadTableData;

    self.clearRowSelection = AppTableService.clearRowSelection;

    self.refillRelatedDropDowns = function(row, fieldName) {
      var elementOpts = [];

      elementOpts = self.predefinedDropdowns[fieldName];

      return elementOpts;
    };

    // Row actions
    self.editField = AppTableService.editField;

    self.deleteRow = AppTableService.deleteRow;

    self.duplicateRow = AppTableService.duplicateRow;

    // Pagination
    self.toggleLimitOptions = AppTableService.toggleLimitOptions;

    self.logOrder = AppTableService.logOrder;

    self.logPagination = AppTableService.logPagination;

    // Add row
    function addRowDialogController($mdDialog, Restangular, $rootScope) {
      var addSelf = this;

      addSelf.name = self.name;

      // Form pre submit default values
      addSelf.row = {};

      addSelf.today = new Date();

      addSelf.hide = function() {
        $mdDialog.hide();
      };

      addSelf.cancel = function() {
        $mdDialog.cancel();
      };

      addSelf.predefinedDropdowns =  addSelf.parent.predefinedDropdowns;

      addSelf.saveRow = function() {
        addSelf.item.form.$setSubmitted();

        if(addSelf.item.form.$valid) {

          // Set defaults
          addSelf.row.created = new Date();
          addSelf.row.created_by = $rootScope.employee.CWID;
          addSelf.row.is_enabled = true;

          var saveRuleRest = Restangular.all(self.modelName);
          var saveRequest = saveRuleRest.customPOST(addSelf.row);
          saveRequest.then(function(response) {
            $mdDialog.hide();

            addSelf.parent.reloadTableData();
            $mdToast.show(
              $mdToast.simple()
              .position('bottom left')
              .textContent('New ' + self.name.singular + ' added')
              .hideDelay(3000)
              .action('x')
            );
          }, function(response) {
            AppTableService.defaultErrorHandling(response);
          });
        }
      };
    }

    self.addRow = function() {
      $mdDialog.show({
        // controller: angular.noop,
        controller: addRowDialogController,
        controllerAs: '$ctrl',
        bindToController: true,
        locals: {parent: self},
        templateUrl: 'js/users/users.add.template.html',
        preserveScope: true,
        clickOutsideToClose: true,
        focusOnOpen: false
      });
    };
  }
]
});
