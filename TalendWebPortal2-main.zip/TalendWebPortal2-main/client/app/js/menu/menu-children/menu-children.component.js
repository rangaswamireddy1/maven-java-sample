'use strict';

menuList.component('menuChildren', {
    templateUrl: 'js/menu/menu-children/menu-children.template.html',

    bindings: {
        promise: '<',
        tableRecords: '<',
    },

    require: {
        menuListCtrl: '^menuList'
    },

    controller: ['Restangular', '$mdEditDialog', '$q', '$timeout', '$mdDialog', '_', 'AppTableService', '$rootScope',
        function ExcludedValuesController(Restangular, $mdEditDialog, $q, $timeout, $mdDialog, _, AppTableService, $rootScope) {
            var self = this;

            // Loopback model for component
            self.tableName = 'Menus';

            self.modelName = 'Menus';

            self.primaryKey = 'Id';

            self.displayField = 'MenuTitle';

            self.name = {
                singular: 'Child Menu',
                plural: 'Child Menus',
                title: 'Child Menus'
            };
            self.name.singularLcase = self.name.singular.toLowerCase();

            // Load rules via REST
            self.tableRecords = [];

            self.selected = [];

            self.fieldValidators = {
                'MenuTitle': { 'required': true },
                'MenuLink': { 'required': true },
                'MenuPermissionName': { 'required': true },
                'MenuOrder': { 'required': true }
            };

            self.predefinedDropdowns = {};

            // Table options
            self.limitOptions = [5, 10, 15];

            self.options = {
                rowSelection: false,
                multiSelect: false,
                autoSelect: false,
                decapitate: false,
                largeEditDialog: false,
                boundaryLinks: false,
                limitSelect: true,
                pageSelect: true
            };

            // Search Filters
            self.filteredCollection = {};

            self.filterToggle = {
                state: false,
                tooltipText: {
                    false: 'Show Filter',
                    true: 'Hide Filter'
                }
            };

            self.query = {
                filter: {},
                where: {},
                contains: {},
                order: 'MenuOrder',
                orderDesc: false,
                limit: 15,
                page: 1
            };

            self.loadTableRecords = AppTableService.loadTableRecords;

            self.$onInit = function () {
                var permissionName = 'SCREEN_' + self.name.title.toUpperCase().replace(/\s/g, '_');
                self.permission = $rootScope.getPermission(permissionName);
            };

            // getFilterValues: Gets unique and non-empty values for the filter dropdown of column
            self.getFilterValues = AppTableService.getFilterValues;

            self.resetFilter = AppTableService.resetFilter;

            self.clearFilter = AppTableService.clearFilter;

            // Table toolbar buttons
            self.reloadTableData = AppTableService.reloadTableData;

            self.clearRowSelection = AppTableService.clearRowSelection;

            self.$onChanges = function (changesObj) {
                // console.log(changesObj);
                if (changesObj.tableRecords) {
                    self.parentSelectionText = '';

                    if (!_.isEmpty(self.menuListCtrl.selected)) {
                        self.query.where = 'MenuParentId eq ' + self.menuListCtrl.selected[0].Id;

                        self.parentSelectionText = ' for, ' + self.menuListCtrl.selected[0].MenuTitle;
                    } else {
                        delete self.query.where;
                    }

                    self.clearRowSelection();
                    // self.clearFilter();
                }
            };

            self.editField = AppTableService.editField;

            self.editFieldAfterSave = function () {
                $rootScope.$emit('menuDataUpdated');
            };

            // Row actions
            self.deleteRow = AppTableService.deleteRow;

            self.statusUpdate = AppTableService.statusUpdate;

            // Pagination
            self.toggleLimitOptions = AppTableService.toggleLimitOptions;

            self.logOrder = AppTableService.logOrder;

            self.logPagination = AppTableService.logPagination;

            self.showFullName = AppTableService.showFullName;

            self.addRow = function () {
                var selectedParentRow = _.first(self.menuListCtrl.selected);
                var opts = {
                    addDefaults: {
                        MenuParentId: selectedParentRow.Id
                    }
                };
                self.menuListCtrl.addRow(opts);
            };

            self.duplicateRow = AppTableService.duplicateRow;
        }
    ]
});
