const SSH = require('simple-ssh');


const execssh = async (hostname) => {

   
        var ssh = new SSH({
            host: 'hostname',
            user: 'eiurm',
            pass: 'Marvel#7980zxxz'
        });
        
        ssh.exec('ping BYDE080YP8G', {
            out: function(stdout) {
                console.log(stdout);
            }
        }).start();
  
    
  };
  
  
  module.exports = {
    execssh
  };
  