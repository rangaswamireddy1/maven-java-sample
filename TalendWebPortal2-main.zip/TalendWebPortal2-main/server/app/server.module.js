'use strict'

const http = require('http');
const https = require('https');

module.exports = (httpPort, httpsPort, url, app) => {
       
    http.createServer(app).listen(httpPort, () => {
        const baseUrl = url.replace(/\/$/, '');

        const sslCert = require('../ssl-config');
        const httpsOptions = {
            key: sslCert.privateKey,
            cert: sslCert.certificate,
            passphrase: 'kitty'
        };

        // console.log('Web server listening at: %s', baseUrl);
        https.createServer(httpsOptions, app).listen(httpsPort, () => {
            app.emit('started');
            console.log('Https Web server listening at: %s', url);
            console.log(process.env.NODE_ENV);
        });

        if (app.get('loopback-component-explorer')) {
            var explorerPath = app.get('loopback-component-explorer').mountPath;
            console.log('Browse your REST API at %s%s', baseUrl, explorerPath);
        }
    });

    return
}