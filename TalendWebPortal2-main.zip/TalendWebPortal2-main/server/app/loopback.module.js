'use strict'

const loopback = require('loopback');
const boot = require('loopback-boot');
const helmet = require('helmet');
const bodyParser = require('body-parser');
//const flash = require('express-flash');

const httpsRedirect = require('../middleware/https-redirect');

module.exports = (configuration) => {
    const app = loopback();

    app.use(helmet());

    boot(app, __dirname + "/../");

    //to support JSON-encoded bodies
    app.middleware('parse', bodyParser.json());

    //to support URL-encoded bodies
    app.middleware('parse', bodyParser.urlencoded({extended: true}));

    //The access token is only available after boot
    app.middleware('parse', loopback.token());

    //We need flash messages to see passport errors
    //app.use(flash());

    var httpsRedirect = require('../middleware/https-redirect');
    var httpsPort = app.get('https-port');
    app.use(httpsRedirect({
        httpsPort: httpsPort
    }));


    app.get('remoting').errorHandler = {
        handler: (err, req, res, defaultHandler) => {
            err = app.buildError(err);

            // send the error back to the original handler
            defaultHandler(err);
        },
        disableStackTrace: true
    };

    app.buildError = (err) => {
        console.error(err);
        err.message = 'please contact Talend Enterprise: ' + err.message;
        // err.status = 408; // override the status

        // remove the statusCode property
        delete err.statusCode;

        throw err;
    };

    app.start = () => {

        require('./server.module')(app.get('http-port'), app.get('https-port'), app.get('url'), app);

    };

    require('./passport.module')(app, configuration);

    return app;
}
