// https://developer.ibm.com/recipes/tutorials/configuring-tokenbased-ldap-authentication-with-loopback-io-2/
'use strict';

if(!process.env.NODE_ENV) {
  process.env.NODE_ENV = 'development';
}
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

const configuration = require('./configuration.module');
const app = module.exports = require('./app/loopback.module')(configuration);
const apiModule = require('./api/api.module')(configuration, app);

app.use("/api", apiModule);

//Bootstrap the application, configure models, datasources and middleware.
//Sub-apps like REST API are mounted via boot scripts.
//start the server if `$ node server.js`
if (require.main === module) {
  app.start();
}
