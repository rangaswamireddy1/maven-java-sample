// 'use strict';
var ensureLoggedIn = require('connect-ensure-login').ensureLoggedIn;

/**
 * this module provides basic authentication related endpoints
 * 
 * @param {*} app 
 */
module.exports = (app) => {

  /**
   * ?
   */
  app.get('/api/auth/loginFail', (req, res) => {
    res.status(401).send({
      auth: false,
      status: "loginFail"
    });
  });

  /**
   * provides user information for logged in users
   */
  app.get('/api/auth/account', (req, res, next) => {
    // console.log(req);
    console.log(req.access_token);
    if(req.user) {
        var op = {
          auth: true,
          id: req.signedCookies.access_token,
          userId: req.user.id,
          email: req.user.email,
          user: JSON.stringify(req.user)
        };

        res.send(op);
    } else {
        res.status(401).send({
          auth: false,
          status: "account retrieval fail"
        });
    }
  });
  
};
