// Create default tables which are defined by Loopback
const server = require('./server');
const ds = server.dataSources.localMysql;
const lbTables = ['User', 'AccessToken', 'ACL', 'RoleMapping', 'Role', 'UserIdentity', 'UserCredential'];

ds.automigrate(lbTables, (er) => {
  if (er) throw er;
  console.log('Loopback tables [' + lbTables + '] created in ', ds.adapter.name);
  ds.disconnect();
});
