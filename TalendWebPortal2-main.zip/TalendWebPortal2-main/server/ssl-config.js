// Copyright IBM Corp. 2014,2016. All Rights Reserved.
// Node module: loopback-example-ssl
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT

const path = require('path');
const fs = require('fs');
var certificateInformation = {
    privateKey: "",
    certificate: ""
}

var domain;

switch (process.env.NODE_ENV) {
    case 'development':
    case 'staging':
        domain = 'nzd8de.nodejs.talend.intranet.cnb';
    break;
    case 'evaluation':
        domain = 'nze8de.nodejs.talend.intranet.cnb';
    break;
    case 'production':
      domain = 'talend.intranet.cnb';
    break;
}

if(domain) {
    certificateInformation.privateKey = fs.readFileSync(path.join(__dirname, './private/' + domain + '.privatekey.pem')).toString();
    certificateInformation.certificate = fs.readFileSync(path.join(__dirname, './private/' + domain + '.certificate.crt')).toString();
}

module.exports = certificateInformation;
