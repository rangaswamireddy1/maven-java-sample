var SSH = require('simple-ssh');

const express = require('express');

'use strict'

const request = require('request');
const passport = require('passport');
const axios = require('axios');

const permission_helper = require('../permission/permission_helper');
const permission_configuration = require('../permission/permissions.json').TalendApi;
const pgHelper = require('../../postgres/pgHelper');


const helpers = require('../../common/express.helpers.module');
/**
 * This modules encapsulates all requests for the Talend Administration Center API
 *
 * @param {*} configuration the global configuration
 */
module.exports = (configuration) => {

    const router = express.Router();
  
    router.post("/rssh/run", async (req, res) => {
        var hostname = req.query.host;
        var url = req.query.url;
        var port = req.query.port;
        var command1 = req.query.command1;
        var options = req.query.options;
    
        performssh(hostname, url, port, command1, options, 
          (body) => helpers.successCallback(res, body),
          (error) => helpers.errorCallback(res, error)
        );
      });
    
    router.get('/rssh', async (req, res) => {
    res.send("SAIK")
    });
    
  
  
   
    return router;
  
  }
  



/**
 * executes a request for the Talend Administration Center Metaservlet
 *
 * @param {*} config.host the configuration to be used
 * @param {*} commandObject the command details
 * @param {*} successCallback callback called on execution success
 * @param {*} errorCallback callback called on faulty execution
 */


/*const performssh = (hostname) => {
    var x = ''
    console.log(hostname)
    var ssh = new SSH({
        host: hostname,
        user: 'Username',
        pass: 'Password'
    });
    
    ssh.exec('ping BYDE080YP8G -c 8', {
      out: function (stdout) { console.log(stdout);
      x = x + stdout
      
   },
     // err: function (stderr) { console.log(stderr); },
     // exit: function (code) { console.log(code); }

      
    }).start();
    
    
    console.log(code)
  };*/


  const performssh = (hostname, url, port, command1, options, successCallback, errorCallback) => {

    console.log(hostname)
    console.log(url)
    console.log(port)
    console.log(command1)
    console.log(options);
    //console.log(Bopt);
    if(command1=='ping' && !options){
  var host = {
    server:        {
     host:         hostname,
     userName:     "Username",
     password:     "Password",
    },
    commands:      [ "ping "+url+" -c 8"]
   };}else if(command1=='ping' && options.includes("-c")){
    var host = {
      server:        {
       host:         hostname,
       userName:     "Username",
       password:     "Password",
      },
      commands:      ["ping "+url+" "+options]
     };
   }else if(command1=='ping' && !options.includes("-c")){
    var host = {
      server:        {
       host:         hostname,
       userName:     "Username",
       password:     "Password",
      },
      commands:      ["ping "+url+" -c 10 "+options]
     };
   }else if(command1=='telnet'){
    var host = {
      server:        {
       host:         hostname,
       userName:     "Username",
       password:     "Password",
      },
      commands:      ["telnet "+url+" "+port]
     };
   }else if(command1=='dig'){
    var host = {
      server:        {
       host:         hostname,
       userName:     "Username",
       password:     "Password",
      },
      commands:      ["dig "+url]
     };
   }else if(command1=='netstat'){
    var host = {
      server:        {
       host:         hostname,
       userName:     "Username",
       password:     "Password",
      },
      commands:      ["netstat -tulpen | grep "+port]
     };
   }else if(command1=='traceroute'){
    var host = {
      server:        {
       host:         hostname,
       userName:     "Username",
       password:     "Password",
      },
      commands:      ["traceroute "+url]
     };
   }else if(command1=='nping'){
    var host = {
      server:        {
       host:         hostname,
       userName:     "Username",
       password:     "Password",
      },
      commands:      ["sudo nping -c 10 --tcp -p "+port+" "+url]
     };
   }else{
    var host = {
      server:        {
       host:         hostname,
       userName:     "Username",
       password:     "Password",
      },
      commands:      ["nmap "+url]
     };
   }
   
   var SSH2Shell = require ('ssh2shell'),
     SSH = new SSH2Shell(host),  
     callback = function(sessionText){
       if(sessionText) {
        console.log((sessionText))
        successCallback((sessionText));
      } else {
        errorCallback(sessionText);

      }
     }
   
   //Start the process
   SSH.connect(callback);

    }