'use strict'

const express = require('express');

/**
 * This module only aggregates all actual API modules
 *
 * @param {*} configuration the global systems configurations
 * @param {*} loopback the loopback application component
 */
module.exports = (configuration, loopback) => {
  const router = express.Router();

  /**
   * Get the swagger documentation for all API modules
   */
  router.get("/", (req,res) => {
    res.send("API Documentation");
    res.end();
  });

  /*
   * Load all sub modules
   */
  router.use('/internal', require('./internal/internal.module')(loopback));
  router.use('/talend', require('./talend/talend.module')(configuration));
  router.use('/gitlab', require('./gitlab/gitlab.module')(configuration));
  router.use('/jenkins', require('./jenkins/jenkins.module')(configuration));
  router.use('/permission', require('./permission/permission.module')(configuration));
  router.use('/github', require('./github/github.module')(configuration));
  router.use('/exessh', require('./exessh/exessh.module')(configuration));


  return router;
};
