'use strict'

const request = require('request');
const _ = require('lodash');
const express = require('express');
const passport = require('passport');
const httpsProxyAgent = require('https-proxy-agent');

const agent = new httpsProxyAgent(`http://mzhvx:DC-PoC$9@bbs-proxy.bayerbbs.net:8080`);


/**
 * This module encapsulates all access to Gitlab
 *
 * @param {*} configuration the global system configuration
 */
module.exports = (configuration) => {
  const router = express.Router();

  const githubEnvironmentConfiguration = configuration[process.env.NODE_ENV || "production"].github;

  router.get("/configuration.properties", passport.authenticate('jwt', {session: false}), (req,res) => {
    console.log("Get configuration.properties");
    console.log(1);
    const projectName = req.query.projectName;
   const githubRequestUrl = githubEnvironmentConfiguration.baseUrl+"/raw/talend/"+projectName+"_coreconfig/master/DEV/configuration.properties";
   console.log(projectName + " - " + githubRequestUrl);
   if( !_.isEmpty(projectName) ) {
      console.log("Request from Github");
      console.log(githubEnvironmentConfiguration.token);
    var axios = require('axios');

    var config = {
    method: 'get',
    url: githubRequestUrl,
    httpsAgent: agent,
    headers: { 
    'strict-ssl': 'false', 
    'Proxy-Authorization': 'Basic ef39f2bff47cd66465d1904005b96c710d27879f', 
    'Authorization': 'Bearer ef39f2bff47cd66465d1904005b96c710d27879f'
  }
};
    axios(config)
          .then(function (response) {
            //console.log(response.data);
            res.send(response.data);
            res.end();
           })
           .catch(function (error) {
            console.log(error);
});
    } else {
      helpers.errorCallback(res, {"message": "Invalid request"});
    }
  });
  
  return router;
}