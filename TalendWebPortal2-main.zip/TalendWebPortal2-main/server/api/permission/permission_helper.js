const axios = require('axios');
const isAuthenicated = async (projectCode, projectName, environment, roles, token) => {
  if ((!projectCode && !projectName) || !environment || !token)
  {
    console.error('Parameters insufficient');
    console.error('projectCode', projectCode);
    console.error('projectName', projectName);
    console.error('environment', environment);
    console.error('roles', roles);
    console.error('token', token);
    return false;
  }
  var projectPermissions;
  try {
    var url = 'https://localhost:8682/api/permission?projectCodes=["'+projectCode+'"]';
    if (projectName)
    {
      url = 'https://localhost:8682/api/permission?projectNames=["'+projectName+'"]';
    }
    var response = await axios.get(url, {headers:{'Authorization': 'bearer '+ token}});
    var projectPermissions = response.data;
  } catch (e) {
    console.error('Exception retrieving permissions:', e);
    return false;
  }
  if (!projectPermissions || projectPermissions.length == 0)
  {
    console.error('Unauthorized. No projects found.');
    return false;
  }

  if (projectCode)
  {
    var currProject = projectPermissions.find((value) => value.project_code === projectCode);
    if (!currProject)
    {
      console.error('Unauthorized. Project permission is missing. Expected:', projectCode);
      return false;
    }
  }
  if (projectName)
  {
    var currProject = projectPermissions.find((value) => value.project_name === projectName);
    if (!currProject)
    {
      console.error('Unauthorized. Project permission is missing. Expected:', projectName);
      return false;
    }
  }

  var currEnv = currProject.environments.find((value) => value.env === environment.substring(0,1));
  console.log({currEnv})
  if (!currEnv)
  {
    console.error('Unauthorized. Environment permission is missing. Expected:', environment.substring(0,1));
    return false;
  }

  if (roles && !currEnv.roles.some(role => roles.includes(role)))
  {
    console.error('Unauthorized. Role permission is missing. Expected:', roles);
    return false;
  }
  return true;
};

const extractProjects = (ldapGroups, expression) => {
  var projects = [];
  ldapGroups.filter((value) => value.match(expression)).forEach((value, index, array) => {
    var extrValues = expression.exec(value);
    var roles = [extrValues[4]];
    var project_code = extrValues[3].toUpperCase();
    var env = extrValues[2];
    var environments = [];
    switch (roles[0])
    {
      case 'reader':
        roles = ['ro'];
        break;
      default:
        break;
    }
    switch (env)
    {
      case 'all':
        environments = [{env:'D', roles},{env:'I', roles}, {env:'Q', roles}, {env:'P', roles}];
        break;
      case 'dev':
        environments.push({env:'D', roles});
        break;
      case 'qa':
        environments.push({env:'Q', roles});
        break;
      case 'prod':
        environments.push({env:'P', roles});
        break;
      case 'int':
        environments.push({env:'I', roles});
        break;
      default:
        break;
    }
    var project = {
      project_code,
      environments
    };
    var projectIdx = projects.findIndex((elem) => {return elem.project_code === project_code;});
    if (projectIdx === -1)
    {
      projects.push(project);
    }
    else
    {
      project.environments.forEach((currEnv,index) => {
        var envIdx = projects[projectIdx].environments.findIndex((elem) => elem.env === currEnv.env);
        if (envIdx === -1)
        {
          projects[projectIdx].environments.push(currEnv);
        }
        else
        {
          projects[projectIdx].environments[envIdx].roles = projects[projectIdx].environments[envIdx].roles.concat(currEnv.roles);
        }
      });
    }
  });
  return projects;
};


module.exports = {
  isAuthenicated,
  extractProjects
};