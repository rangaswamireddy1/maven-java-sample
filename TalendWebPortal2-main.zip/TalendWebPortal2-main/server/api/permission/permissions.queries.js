
var getProjectQuery = (projectCodesForFilter, projectNamesForFilter) =>{
  var projectNameFilter  = '(';
  if (projectNamesForFilter)
  {
    projectNamesForFilter.forEach((project) => {
      projectNameFilter = projectNameFilter + ",'" + project.trim() + "'";
    });
    projectNameFilter = projectNameFilter.replace(",", "") + ")"
  }
  var projectCodeFilter  = '(';
  if (projectCodesForFilter)
  {
    projectCodesForFilter.forEach((project) => {
      projectCodeFilter = projectCodeFilter + ",'" + project.trim() + "'";
    });
    projectCodeFilter = projectCodeFilter.replace(",", "") + ")"
  }
  return `
SELECT 	trim(code) AS project_code,
	trim(name) AS project_name
FROM "[SCHEMA_NAME]".projects
WHERE 1=1
${projectCodesForFilter ? `AND trim(code) IN ${projectCodeFilter}` : ""}
${projectNamesForFilter ? `AND trim(name) IN ${projectNameFilter}` : ""}
  ;`;
};

//Created a script to call the ldapPrefix from TalendEnterprise Schema 
var getldapPrefix =()=>{
  return `
SELECT distinct trim("ldapPrefix") As ldapPrefix FROM "[SCHEMA_NAME]".projects
WHERE trim("ldapPrefix") IS NOT NULL AND trim("ldapPrefix") != ''
;`;

};
module.exports = {
  getProjectQuery,
  getldapPrefix 
};
