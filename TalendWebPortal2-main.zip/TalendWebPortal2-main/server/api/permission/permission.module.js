const express = require('express');
const axios = require('axios');

const permission_helper = require('./permission_helper');
const query_configuration = require('./permissions.queries');
const permission_configuration = require('./permissions.json');
const pgHelper = require('../../postgres/pgHelper');
// const { regExLdapGroups } = require('../../configuration.module');

const getProjectsFromDb = async (projectCodesForFilter, projectNamesForFilter) => {
  try {
    var queryString = query_configuration.getProjectQuery(projectCodesForFilter, projectNamesForFilter);
    var projects = await pgHelper.executeQuery(queryString);
    return projects;
  } catch (e) {
      console.error('Exception caught while loading Project-list from DB', e);
      return new Error(e);
  }
};

//This method gives ldapPrefix in list from database
const getldapPrefixFromDb = async () => {
  try {
    var queryString = query_configuration.getldapPrefix();
    var ldapPrefixList = await pgHelper.executeQuery(queryString);
    return ldapPrefixList;
  } catch (e) {
      console.error('Exception caught while loading ldapPrefixList from DB', e);
      return new Error(e);
  }
};

/**
 * This module encapsulates all access to Gitlab
 *
 * @param {*} configuration the global system configuration
 */
module.exports = (configuration) => {
  const router = express.Router();

  const groupExpression = configuration.regExLdapGroups;
  const joinProjectNamesWithPermission = (projectCodesWithPermission, projectNames, isAdmin) => {
    var joinedList = [];
    projectNames.forEach((pName) => {
      var pCode = projectCodesWithPermission.filter((value) => value.project_code === pName.project_code);
      if (isAdmin)
      {
        joinedList.push({
          project_name: pName.project_name,
          project_code: pName.project_code,
          environments: [ {env:'D', roles: ['admin']},
                          {env:'Q', roles: ['admin']},
                          {env:'P', roles: ['admin']},
                          {env:'I', roles: ['admin']}]
        });
      }
      else if (pCode.length > 0)
      {
        joinedList.push({
          project_name: pName.project_name,
          project_code: pName.project_code,
          environments: pCode[0].environments
        });
      }
    });
    return joinedList;
  };

  router.get("/", async (req,res) => {
    var reqProjectCodes = req.query.projectCodes ? JSON.parse(req.query.projectCodes) : undefined;
    var reqProjectNames = req.query.projectNames ? JSON.parse(req.query.projectNames) : undefined;
    var isAdmin = req.user.groups.some(r => configuration.adminGroups.includes(r));
    console.log({reqProjectCodes, reqProjectNames, isAdmin});
    // isAdmin = false;
    try
    {
      var ldapPrefixList = await getldapPrefixFromDb();       //Taking ldapPrefix as list from database 
      if (ldapPrefixList && Array.isArray(ldapPrefixList) && ldapPrefixList.length>0);  //Cheking the length>0 and is array 
      {
        var ldapPrefixWithPipe = ldapPrefixList.map(x=>x.ldapprefix).join("|");  //Adding Pipe between ldapGroup list obtained from DB
        dynamicExpressionChanges = new RegExp(groupExpression.replace("dynPrefixes",ldapPrefixWithPipe));  //replacing the pipe with dynprefixes
      }
      var projectCodesWithPermission = permission_helper.extractProjects(req.user.groups, dynamicExpressionChanges);
      //IMCM WORKAROUND
      //console.log(projectCodesWithPermission)
      projectCodesWithPermission = projectCodesWithPermission.concat(permission_helper.extractProjects(req.user.groups,new RegExp('^bs.[au].([a-zA-Z]{2,4})_talend_ms_ph_imcm_(ngsf)_([A-z]+)')));
      //console.log(projectCodesWithPermission)
      var filter = {where:{and:[]}};
      //console.log({reqProjectCodes,reqProjectNames,projectCodesWithPermission})
      //Only apply permission filter if user is not superadmin
      var projectList = await getProjectsFromDb(reqProjectCodes, reqProjectNames);
      //console.log({projectList})
      var joinedList = joinProjectNamesWithPermission(projectCodesWithPermission, projectList, isAdmin);
      //console.log(projectList) 
      //console.log(joinedList) 
      /*Token Jan Kolthoff: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImN3aWQiOiJFVEpPTyIsInVzZXJuYW1lIjoibGRhcC5qYW4ua29sdGhvZmYuZXh0QGJheWVyLmNvbSIsImZpcnN0bmFtZSI6IkphbiIsImxhc3RuYW1lIjoiS29sdGhvZmYiLCJlbWFpbCI6Imphbi5rb2x0aG9mZi5leHRAYmF5ZXIuY29tIiwiZ3JvdXBzIjpbImJzLnUuYWxsX3RhbGVuZF9wX2RtNHBfcm8iLCJicy51LmFsbF90YWxlbmRfcF9kbTRwX3JtIiwiYnMudS5hbGxfdGFsZW5kX3BfZG00cF9yd190ZWNoIiwiYnMudS5kZXZfdGFsZW5kX3BfZG00cF9ydyIsImJzLnUuZGV2X3RhbGVuZF9wX21vb25fcnciLCJicy51LmFsbF90YWxlbmRfcF9tb29uX3JvIiwiYnMudS5hbGxfdGFsZW5kX3BfbW9vbl9ybSIsImJzLnUuYWxsX3RhbGVuZF9wX21vb25fcndfdGVjaCIsImJzLnUuYWxsX3RhbGVuZF9wX2NkY21fcm8iLCJicy51LmRldl90YWxlbmRfcF9jZGNtX3J3IiwiYnMudS5hbGxfdGFsZW5kX3BfYmFsaW9zX3JvIiwiYnMudS5kZXZfdGFsZW5kX3BfYmFsaW9zX3J3IiwiYnMudS5hbGxfdGFsZW5kX3BfYmFsaW9zX3JtIiwiYnMudS50YWxlbmRfdF9xdWluc2NhcGVfZGV2IiwiYnMuYS5wcm9kX3RhbGVuZF9tc19waF9pbWNtX25nc2ZfcmVhZGVyIiwiYnMuYS5xYV90YWxlbmRfbXNfcGhfaW1jbV9uZ3NmX3JlYWRlciIsImJzLmEuZGV2X3RhbGVuZF9tc19waF9pbWNtX25nc2ZfcmVhZGVyIiwiYnMudS5wcm9kX3RhbGVuZF9tc19jc190c3ZzX2V0bF9yZWFkZXIiLCJicy51LnFhX3RhbGVuZF9tc19jc190c3ZzX2V0bF9yZWFkZXIiLCJicy51LmRldl90YWxlbmRfbXNfY3NfdHN2c19ldGxfcmVhZGVyIiwiYnMudS5pbWNtX3RhbGVuZF9kZXZlbG9wZXJzIiwiYnMudS5wcm9kX3RhbGVuZF9tc19iaGNfY29yZXgtY25fcmVhZGVyIiwiYnMudS5wcm9kX3RhbGVuZF9sb2dzdGFzaF9yZWFkZXIiLCJicy51LnFhX3RhbGVuZF9sb2dzdGFzaF9yZWFkZXIiLCJicy51LmRldl90YWxlbmRfbG9nc3Rhc2hfcmVhZGVyIiwiYnMudS5wcm9kX3RhbGVuZF9raWJhbmFfZGVzaWduZXIiLCJicy51LnFhX3RhbGVuZF9raWJhbmFfZGVzaWduZXIiLCJicy51LmRldl90YWxlbmRfa2liYW5hX2Rlc2lnbmVyIiwiYnMudS5wcm9kX3RhbGVuZF9raWJhbmFfcmVhZGVyIiwiYnMudS5xYV90YWxlbmRfa2liYW5hX3JlYWRlciIsImJzLnUuZGV2X3RhbGVuZF9raWJhbmFfcmVhZGVyIl0sImlhdCI6MTU1NDk2NTQ2NX0.QklSy2MV1X69iNEtbaOrYcWksE1l54uR0kLdpqjEjyU

      */
      /*
      joinedList = [
      //   {project_code: 'MOON',
      //   project_name: 'MS_CS_MOON',
      //   environments: [{env: 'D', permission: 'rw', roles: ['rm']},
      //                   {env: 'Q', permission: 'rw', roles: ['rm']},
      //                 {env: 'P', permission: 'rw', roles: ['rm']}]
      // }
      // ,{project_code: 'NGSF',
      // project_name: 'MS_PH_IMCM_NGSF',
      // environments: [{env: 'D', permission: 'rw', roles: ['rw']}]}
      // ,
      {project_code: 'KARAPIT',
      project_name: 'RD_PH_PIT_DI',
      environments: [{env: 'D', permission: 'rw', roles: ['rw']}]}
    ];
    */
      res.send(joinedList);
    } catch (error) {
      console.error(error);
      res.status(500).send(error);
    }
  });

  router.get("/apis", async (req,res) => {
      var reqApi = req.query.name;
      var reqAction = req.query.action;
      if (!reqApi || !reqAction)
      {
        return res.status(400).send("Parameters insufficient");
      }
      authRoles = permission_configuration[reqApi][reqAction];
      res.send(authRoles ? authRoles : []);
  });

  return router;
};