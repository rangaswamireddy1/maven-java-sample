'use strict'

const request = require('request');
const _ = require('lodash');
const express = require('express');
const passport = require('passport');


/**
 * This module encapsulates all access to Gitlab
 *
 * @param {*} configuration the global system configuration
 */
module.exports = (configuration) => {
  const router = express.Router();

  const gitlabEnvironmentConfiguration = configuration[process.env.NODE_ENV || "production"].gitlab;

  router.get("/configuration.properties", passport.authenticate('jwt', {session: false}), (req,res) => {
    console.log("Get configuration.properties");
    const projectName = req.query.projectName;
   // const gitlabRequestUrl = gitlabEnvironmentConfiguration.baseUrl + gitlabEnvironmentConfiguration.talendProjectGroupPath + "/"+ projectName + "_coreconfig/raw/master/DEV/configuration.properties?private_token=" + gitlabEnvironmentConfiguration.token;
   const gitlabRequestUrl = "https://by-gitlab.de.bayer.cnb/api/v4/projects?search="+projectName//gitlabEnvironmentConfiguration.baseUrl + gitlabEnvironmentConfiguration.talendProjectGroupPath + "/"+ projectName + "_coreconfig/raw/master/DEV/configuration.properties";
   console.log(projectName + " - " + gitlabRequestUrl);
    if( !_.isEmpty(projectName) ) {
      console.log("Request from Gitlab");
         request.get(gitlabRequestUrl,{'auth': {
          'bearer':gitlabEnvironmentConfiguration.token} },(error, response, body) => {
          if( !error && response.statusCode == 200 ) {
            if(body)
            {
              var result = JSON.parse(body)
              var projectId =result[0].id
              console.log({projectId})
              var newurl= gitlabEnvironmentConfiguration.baseUrl + "/api/v4/projects/"+projectId+ "/repository/files/DEV%2fconfiguration.properties/raw?ref=master";
              console.log({newurl})
              request.get(newurl,{'auth': {
                'bearer':gitlabEnvironmentConfiguration.token} },(error, response, body) => {
              res.set("Content-Type", "text/plain");
              res.set("Content-Disposition", "attachment;filename=configuration.properties");
              res.send(body);
              res.end();
                });
            }else{
              res.set("Content-Type", "text/plain");
              res.set("Content-Disposition", "attachment;filename=configuration.properties");
              res.send(body);
              res.end();
            }
           
            }
            else{
              helpers.errorCallback(res, {"message": "Error accessing Gitlab"});
            }
        });
    } else {
      helpers.errorCallback(res, {"message": "Invalid request"});
    }
  });
  return router;
}