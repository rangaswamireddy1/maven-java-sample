'use strict'

const express = require('express');
const request = require('request');
const to_json = require('xmljson').to_json;
const _ = require('lodash');
const helpers = require('../../common/express.helpers.module');
const passport = require('passport');
const promoteEnvExp = new RegExp('^([A-Z]+)to([A-Z]+)$');

const permission_helper = require('../permission/permission_helper');
const permission_configuration = require('../permission/permissions.json').TalendConfigurationApi;
/**
 * This module encapsulates all function needed on Jenkins
 *
 * @param {*} configuration the global configuration
 */
module.exports = (configuration) => {
  const router = express.Router();

  const jenkinsEnvironmentConfiguration = configuration[process.env.NODE_ENV || "development"].jenkins;

  router.post("/configuration/promote", async (req, res) => {
    const projectCode = req.body.projectCode;
    const promotionStep = req.body.promotedEnv;
    const env = req.body.selectedEnv;
    const promotionDB = req.body.promoteDb;
    const Db = req.body.selectedDb;
    console.log("1: " + projectCode + " - " + promotionStep);
    if( !_.isEmpty(projectCode) && !_.isEmpty(promotionStep) ) {
      var promoteToEnv = promotionStep;
      var isAuthenicated = await permission_helper.isAuthenicated(projectCode, undefined, promoteToEnv, permission_configuration.promote, req.headers.authorization.substring(7));
      if (!isAuthenicated)
      {
        return res.status(401).send('Unauthorized');
      }
      console.log("requesting Jenkins");

      // performJenkinsRequest(jenkinsEnvironmentConfiguration, "/job/project_context_variable_promotion/buildWithParameters?token=s8wPVBVE7ycjQdp0QP5u", {
        
      //   parameter: [
      //     {
      //       name: "SRC_COREDB",
      //       value: Db
      //     },
      //     {
      //       name: "SRC_PRJ_CODE",
      //       value: projectCode
      //     },
      //     {
      //       name: "SRC_STAGE",
      //       value: env
      //     },
      //     {
      //       name: "TGT_COREDB",
      //       value: promotionDB
      //     },
      //     {
      //       name: "TGT_PRJ_CODE",
      //       value: projectCode
      //     },
      //     {
      //       name: "TGT_STAGE",
      //       value: promotionStep
      //     }
      //   ]
      // }, (message) => {
      //   helpers.successCallback(res, message);
      // }, (error) => {
      //   helpers.errorCallback(res, error);
      // });
      var options = {
        'method': 'GET',
        'url': `https://jenkins.talend.intranet.cnb:8483/jenkins/job/project_context_variable_promotion/buildWithParameters?token=s8wPVBVE7ycjQdp0QP5u&SRC_COREDB=${Db}&SRC_PRJ_CODE=${projectCode}&SRC_STAGE=${env}&TGT_COREDB=${promotionDB}&TGT_PRJ_CODE=${projectCode}&TGT_STAGE=${promotionStep}`
      };
      request(options, function (error, response) {
        if (error) throw new Error(error);
        if(response.statusCode=== 201){
          return res.status(201).send('success');
        }
      });
      
    } else {
      console.log("error");
      errorCallback(res, {message: "Invalid body"})
    }
  });

  router.post("/configuration/core/deploy", async (req, res) => {
    const projectCode = req.body.projectCode; //e.g. CFL
    const projectName = req.body.projectName; //e.g. MS_PH_IMCM_NGSF
    const environment = req.body.environment; //e.g. DV or Q1 or Q2 or P1 or P2
    const executionType = 'jobServer'; //e.g. jobServer or runtime
    const gitTag = req.body.gitTag;
    if(!_.isEmpty(projectCode) && !_.isEmpty(projectName) && !_.isEmpty(environment) && !_.isEmpty(executionType) && !_.isEmpty(gitTag)) {
      var isAuthenicated = await permission_helper.isAuthenicated(projectCode, projectName, environment, permission_configuration.deployBootstrapperConfig, req.headers.authorization.substring(7));
      if (!isAuthenicated)
      {
        return res.status(401).send('Unauthorized');
      }

      console.log("requesting Jenkins");
      performJenkinsRequest(jenkinsEnvironmentConfiguration, "/view/deploy/job/deploy_COREConfig_" + projectCode + "/build", {
        parameter: [
          {
            name: "projectTechnicalName",
            value: projectName
          },
          {
            name: "environement",
            value: environment
          },
          {
            name: "executionType",
            value: executionType
          },
          {
            name: "GitTag",
            value: gitTag
          }
        ]
      }, (message) => {
        helpers.successCallback(res, message);
      }, (error) => {
        helpers.errorCallback(res, error);
      });
    }
  });
  router.get("/advance", (req,res) => {
    const projectCode = req.query.projectCode;
    const jenkinsRequestUrl = jenkinsEnvironmentConfiguration.baseUrl + "/view/deploy/job/deploy_COREConfig_" + projectCode + "/build";
    console.log({jenkinsRequestUrl, projectCode})
    request.get(jenkinsRequestUrl, (error, response, body) => {
      console.log(response.statusCode)
      if( !error ) {
          res.set("Content-Type", "text/plain");
          res.send(jenkinsRequestUrl);
          res.end();
        }
        else{
            helpers.errorCallback(res, error);
        }
      });
  });
  return router;
}


/**
 * This function retrieves a CRUMB value from Jenkins in order to execute the business request
 *
 * @param {*} jenkinsEnvironmentConfiguration the Jenkins configuration
 * @param {*} successCallback callback called on successful crumb resolution
 * @param {*} errorCallback callback called on faulty crumb resolution
 */
const performJenkinsCrumbRequest = (jenkinsEnvironmentConfiguration, successCallback, errorCallback) => {
  request({
    "url": jenkinsEnvironmentConfiguration.baseUrl + "/crumbIssuer/api/xml",
    "auth": {
      "user": jenkinsEnvironmentConfiguration.user,
      "pass": jenkinsEnvironmentConfiguration.token
    }
  }, (error, response, body) => {
    console.log("request callback");
    if( error ) {
      console.log(error);
      errorCallback({"message": "Error requesting Jenkins Crumb", "details": error});
    } else {
      console.log("success");
      const json = to_json(body, function(error, data) {
        console.log("json conversion");
        if( error ) {
          console.log("json conversion error");
          errorCallback(error);
          //res.status(500).json(error);
        } else {
          console.log("json conversion success");
          if( _.get(data, 'defaultCrumbIssuer.crumb') ) {
            const crumb = data.defaultCrumbIssuer.crumb;
            successCallback(crumb);
          } else {
            errorCallback({ message: "Failed to retrieve Jenkins Crumb" })
          }
        }
      });
    }
  })
};

/**
 * This function executes a Jenkins Task
 *
 * @param {*} jenkinsEnvironmentConfiguration the Jenkins Confiugration to be used
 * @param {*} jenkinsTaskPath The path to Task to be executed
 * @param {*} jenkinsRequest The parameters to be provided
 * @param {*} successCallback callback called on successful task execution
 * @param {*} errorCallback callback called on faulty task execution
 */
const performJenkinsRequest = (jenkinsEnvironmentConfiguration, jenkinsTaskPath, jenkinsRequest, successCallback, errorCallback) => {
  //each Jenkins Request needs to be decorated with a token: The Crumb, hence we request it
  //additionally we pass the actual request as  success callback that receives the crumb
  //or an error callback that will be called in case of errors
  console.log("performJenkinsRequest");
  performJenkinsCrumbRequest(jenkinsEnvironmentConfiguration, (crumb) => {
    console.log("crumb received: " + crumb);
    const options = {
      "url": jenkinsEnvironmentConfiguration.baseUrl + jenkinsTaskPath,
      "headers": {
        "Content-Type": "application/json",
        "Jenkins-Crumb": crumb
      },
      "auth": {
        "user": jenkinsEnvironmentConfiguration.user,
        "pass": jenkinsEnvironmentConfiguration.token
      },
      "form":{
        "json": JSON.stringify(jenkinsRequest)
      }
    }
    request.post(options, (error, response, body) => {
      if (!error && response.statusCode == 201) {
        successCallback(body);
      } else {
        errorCallback(error);
      }
    });
  }, (error) => {
    errorCallback(error);
  });
};
