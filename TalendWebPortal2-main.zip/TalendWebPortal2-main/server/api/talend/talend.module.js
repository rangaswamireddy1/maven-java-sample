'use strict'

const express = require('express');
const request = require('request');
const passport = require('passport');
const axios = require('axios');

const permission_helper = require('../permission/permission_helper');
const query_configuration = require('./talend.queries');
const permission_configuration = require('../permission/permissions.json').TalendApi;
const pgHelper = require('../../postgres/pgHelper');


const helpers = require('../../common/express.helpers.module');


var filterEnvironment = (env) => {
  var ret = {}
  for (var key in env)
  {
    if (!['projectlabel', 'tasklabel'].includes(key))
    {
      ret[key] = env[key];
    }
  }
  return ret;
};

var filterEnvironment = (env) => {
  var ret = {}
  for (var key in env)
  {
    if (!['projectlabel', 'esblabel'].includes(key))
    {
      ret[key] = env[key];
    }
  }
  return ret;
};

const aggregateEnvironments = (a, b, i) => {
  var ret = a;
  if (i === 1)
  {
    var ret = {
      projectlabel: a.projectlabel,
      tasklabel: a.tasklabel,
      esblabel: a.esblabel,
      environments: []
    };
    ret.environments.push(filterEnvironment(a));
  }
  if (b) {
    ret.environments.push(filterEnvironment(b));
  }
  return ret;
};

const aggregateTaskList = (completeTaskList) => {
  var aggregatedTaskList = [];
  completeTaskList.forEach((value) => {
    var aggregatedTask = aggregatedTaskList.filter(task => task.tasklabel === value.tasklabel)[0];
    if (!aggregatedTask)
    {
      var filteredTasks = completeTaskList.filter(task => task.tasklabel === value.tasklabel);
      if (filteredTasks.length > 1)
      {
        aggregatedTaskList.push(filteredTasks.reduce(aggregateEnvironments));
      }
      else
      {
        aggregatedTaskList.push(aggregateEnvironments(filteredTasks[0], undefined, 1));
      }
    }});
  return aggregatedTaskList
};

const aggregateEsbList = (completeEsbList) => {
  var aggregatedEsbList  = [];
  completeEsbList.forEach((value) => {
    var aggregatedEsb = aggregatedEsbList.filter(esb => esb.esblabel === value.esblabel)[0];
    if (!aggregatedEsb)
    {
      var filteredEsb = completeEsbList.filter(esb => esb.esblabel === value.esblabel);
      if (filteredEsb.length > 1)
      {
        aggregatedEsbList.push(filteredEsb.reduce(aggregateEnvironments));
      }
      else
      {
        aggregatedEsbList.push(aggregateEnvironments(filteredEsb[0], undefined, 1));
      }
    }});
  return aggregatedEsbList
};

const getTaskListForEnv = async (tacInstance, projectsForFilter, taskLblFilter, taskIdFilter) => {
  var queryString = query_configuration.getTaskListQuery(projectsForFilter, taskLblFilter, taskIdFilter, tacInstance.env);
  return pgHelper.executeQuery(queryString, tacInstance.dbConfig, 'public');
};

const getEsbListForEnv = async (tacInstance,reqProjectCodes, projectsForFilter, esbLblFilter, esbIdFilter) => {
  var queryString = query_configuration.getEsbListQuery(projectsForFilter,reqProjectCodes, esbLblFilter, esbIdFilter, tacInstance.env);
  return pgHelper.executeQuery(queryString, tacInstance.dbConfig, 'public');
};

const getTacListFromDb = async (envFilter) => {
  try {
    var queryString = query_configuration.getTacListQuery(envFilter);
    var res = await pgHelper.executeQuery(queryString);
    var tacConfiguration = [];
    var dbTypeExp = new RegExp('^jdbc:([A-z]+):');
    if (res instanceof Error)
    {
      return res;
    }
    res.forEach((row) => {
      console.log(row);
      console.log(dbTypeExp.test(row.dbURL));
      if (dbTypeExp.test(row.dbURL))
      {
        var dbType = dbTypeExp.exec(row.dbURL)[1];
        console.log({dbType});
        var jdbcExp = new RegExp('');
        switch (dbType) {
          case 'postgresql':
            jdbcExp = new RegExp('^jdbc:postgresql:\/\/([A-z0-9.-]+):([0-9]+)\/([A-z0-9\?&=]+)$')
              break;
          case 'oracle':
              jdbcExp = new RegExp('');
              break;
          default:
        }
        var extrValues = jdbcExp.exec(row.dbURL);
        var indexPos = extrValues[3].trim().indexOf("?");
        var databaseName = indexPos>-1?extrValues[3].substring(0,indexPos):extrValues[3].trim();
          var tac = {
          env: row.env,
          dbConfig: {
            dbType: dbType,
            host: extrValues[1].trim(),
            port: extrValues[2].trim(),
            user: row.dbUser.trim(),
            password: row.dbPassword.trim(),
            database: databaseName
          },
          tacConfig: {
            host: row.hostDNS.trim(),
            useHttps: row.portHTTPS ? true : false,
            port: row.portHTTPS ? row.portHTTPS : row.portHTTP,
            applicationContext: row.applicationContext.trim(),
            user: row.tacUser.trim(),
            password: row.tacPassword.trim()
          }
        };
        console.log(tac.host)
      /*if(tac.env.includes("8") || tac.env.includes("Q52")){
        tac.dbConfig.ssl=true;
        tac.dbConfig.sslmode="require";}*/

        if(tac.dbConfig.host.includes("postgres.database.azure.com")){
          tac.dbConfig.ssl=true;
          tac.dbConfig.sslmode="require";
          console.log({tac});}

        tacConfiguration.push(tac);

        
      }
      else
      {
        console.error(`Unrecognized DB-URL for TAC ${row.env}. Expected jdbc-string, but was ${row.dbURL}`);
      }
    });
    return tacConfiguration;
  } catch (e) {
      console.error('Exception caught while loading TAC-list from DB', e);
      return new Error(e);
  }
};

const isAuthenicatedForTask = async (taskId, env, token, roles) => {
  try {
    var urlTaskList = `https://localhost:8682/api/talend/tasks?env=${env}&taskId=${taskId}`;
    var taskListResponse = await axios.get(urlTaskList, {headers:{'Authorization': 'bearer '+ token}});
    var taskDetails = taskListResponse.data;
    if (taskDetails.length != 1)
    {
      return false;
    }
    var isAuthenicated = await permission_helper.isAuthenicated(undefined, taskDetails[0].projectlabel, env, roles, token);
    if (!isAuthenicated)
    {
      return false;
    }
  } catch (e) {
    console.error(e);
    return false;
  }
  return true;
};

const isAuthenicatedForEsb = async (esbId, env, token, roles) => {
  try {
    var urlEsbList = `https://localhost:8682/api/talend/esb?env=${env}&esbId=${esbId}`;
    var esbListResponse = await axios.get(urlEsbList, {headers:{'Authorization': 'bearer '+ token}});
    var esbDetails = esbListResponse.data;
    if (esbDetails.length != 1)
    {
      return false;
    }
    var isAuthenicated = await permission_helper.isAuthenicated(undefined, esbDetails[0].projectlabel, env, roles, token);
    if (!isAuthenicated)
    {
      return false;
    }
  } catch (e) {
    console.error(e);
    return false;
  }
  return true;
};

/**
 * This modules encapsulates all requests for the Talend Administration Center API
 *
 * @param {*} configuration the global configuration
 */
module.exports = (configuration) => {

  const router = express.Router();

  const groupExpression = new RegExp(configuration.regExLdapGroups);


  router.post("/task/run", async (req, res) => {
    var reqEnv = req.query.env;
    var reqTaskId = req.query.taskId;
    var contextA = req.query.client.split(",");
    //var contextB = req.query.systemnumber;
    //console.log(contextB);
    console.log(contextA);
    if (!reqTaskId || !reqEnv)
    {
      return res.status(400).send('Task id or environment is missing');
    }
    try {

    } catch (e) {
      return res.status(500).send(e);
    }
    var isAuthenicated = await isAuthenicatedForTask(reqTaskId, reqEnv, req.headers.authorization.substring(7), permission_configuration.startStopTask);

    var tacList = await getTacListFromDb(reqEnv);
    if (tacList.length < 1)
    {
      console.error('Environment is not correctly configured: '+ reqEnv);
      return res.status(500).send('Environment is not correctly configured: '+ reqEnv);
    }
    performMetaservletRequest(tacList[0].tacConfig, {
        "actionName": "runTask",
        "mode": "synchronous",
        "taskId": reqTaskId,
        "context": {"PBC_Client" : contextA[0], "PBC_Host" : contextA[1],"PBC_Language": contextA[2] ,"PBC_Password": contextA[3] ,"PBC_Username": contextA[4] , "PBC_SystemNumber" : contextA[5]}
      },
      (body) => helpers.successCallback(res, body),
      (error) => helpers.errorCallback(res, error)
    );
  });

  router.post("/task/stop", async (req, res) => {
    var reqEnv = req.query.env;
    var reqTaskId = req.query.taskId;
    if (!reqTaskId || !reqEnv)
    {
      return res.status(400).send('Task id or environment is missing');
    }
    try {

    } catch (e) {
      return res.status(500).send(e);
    }
    var isAuthenicated = await isAuthenicatedForTask(reqTaskId, reqEnv, req.headers.authorization.substring(7), permission_configuration.startStopTask);

    var tacList = await getTacListFromDb(reqEnv);
    if (tacList.length < 1)
    {
      return res.status(500).send('Environment is not correctly configured: ', reqEnv);
    }

    performMetaservletRequest(tacList[0].tacConfig, {
        "actionName": "getTaskIdByName",
        "taskName": "sap connection test"
      },
      (body) => helpers.successCallback(res, body),
      (error) => helpers.errorCallback(res, error)
    );
  });

  router.post("/esb/start", async (req, res) => {
    var reqEnv = req.query.env;
    var reqEsbId = req.query.esbId;
    if (!reqEsbId || !reqEnv)
    {
      return res.status(400).send('Esb id or environment is missing');
    }
    try {

    } catch (e) {
      return res.status(500).send(e);
    }
    var isAuthenicated = await isAuthenicatedForEsb(reqEsbId, reqEnv, req.headers.authorization.substring(7), permission_configuration.startStopEsb);
    var tacList = await getTacListFromDb(reqEnv);
    if (tacList.length < 1)
    {
      console.error('Environment is not correctly configured: '+ reqEnv);
      return res.status(500).send('Environment is not correctly configured: '+ reqEnv);
    }

    performMetaservletRequest(tacList[0].tacConfig, {
        "actionName": "taskLog",
        "lastExecution": true,
        "taskId": reqEsbId
      },
      (body) => helpers.successCallback(res, body),
      (error) => helpers.errorCallback(res, error)
    );
  });

  router.post("/esb/stop", async (req, res) => {
    var reqEnv = req.query.env;
    var reqEsbId = req.query.esbId;
    if (!reqEsbId || !reqEnv)
    {
      return res.status(400).send('Esb id or environment is missing');
    }
    try {

    } catch (e) {
      return res.status(500).send(e);
    }
    var isAuthenicated = await isAuthenicatedForEsb(reqEsbId, reqEnv, req.headers.authorization.substring(7), permission_configuration.startStopEsb);

    var tacList = await getTacListFromDb(reqEnv);
    if (tacList.length < 1)
    {
      console.error('Environment is not correctly configured: '+ reqEnv);
      return res.status(500).send('Environment is not correctly configured: '+ reqEnv);
    }

    performMetaservletRequest(tacList[0].tacConfig, {
        "actionName": "stopEsbTask",
        "mode": "asynchronous",
        "taskId": reqEsbId
      },
      (body) => helpers.successCallback(res, body),
      (error) => helpers.errorCallback(res, error)
    );
  });

  router.post("/esb/deploy", async (req, res) => {
    var reqEnv = req.query.env;
    var reqEsbId = req.query.esbId;
    if (!reqEsbId || !reqEnv)
    {
      return res.status(400).send('Esb id or environment is missing');
    }
    try {

    } catch (e) {
      return res.status(500).send(e);
    }
    var isAuthenicated = await isAuthenicatedForEsb(reqEsbId, reqEnv, req.headers.authorization.substring(7), permission_configuration.deployUndeployEsb);

    var tacList = await getTacListFromDb(reqEnv);
    if (tacList.length < 1)
    {
      console.error('Environment is not correctly configured: '+ reqEnv);
      return res.status(500).send('Environment is not correctly configured: '+ reqEnv);
    }

    performMetaservletRequest(tacList[0].tacConfig, {
        "actionName": "requestDeployEsbTask",
        "mode": "asynchronous",
        "taskId": reqEsbId
      },
      (body) => helpers.successCallback(res, body),
      (error) => helpers.errorCallback(res, error)
	  );
  });

  router.post("/esb/undeploy", async (req, res) => {
  var reqEnv = req.query.env;
  var reqEsbId = req.query.esbId;
  if (!reqEsbId || !reqEnv)
  {
    return res.status(400).send('Esb id or environment is missing');
  }
  try {

  } catch (e) {
    return res.status(500).send(e);
  }
  var isAuthenicated = await isAuthenicatedForEsb(reqEsbId, reqEnv, req.headers.authorization.substring(7), permission_configuration.deployUndeployEsb);

  var tacList = await getTacListFromDb(reqEnv);
  if (tacList.length < 1)
  {
    console.error('Environment is not correctly configured: '+ reqEnv);
    return res.status(500).send('Environment is not correctly configured: '+ reqEnv);
  }

  performMetaservletRequest(tacList[0].tacConfig, {
      "actionName": "requestUndeployEsbTask",
      "mode": "asynchronous",
      "taskId": reqEsbId
    },
    (body) => helpers.successCallback(res, body),
    (error) => helpers.errorCallback(res, error)
    );
  });

  router.post("/task/pgdbrun", async (req, res) => {
    var reqEnv = req.query.env;
    var reqTaskId = req.query.taskId;
    var contextA = req.query.client.split(",");
    //var contextB = req.query.systemnumber;
    //console.log(contextB);
    console.log(contextA);
    if (!reqTaskId || !reqEnv)
    {
      return res.status(400).send('Task id or environment is missing');
    }
    try {

    } catch (e) {
      return res.status(500).send(e);
    }
    var isAuthenicated = await isAuthenicatedForTask(reqTaskId, reqEnv, req.headers.authorization.substring(7), permission_configuration.startStopTask);

    var tacList = await getTacListFromDb(reqEnv);
    if (tacList.length < 1)
    {
      console.error('Environment is not correctly configured: '+ reqEnv);
      return res.status(500).send('Environment is not correctly configured: '+ reqEnv);
    }
    performMetaservletRequest(tacList[0].tacConfig, {
        "actionName": "runTask",
        "mode": "synchronous",
        "taskId": reqTaskId,
        "context": {"conDbPGSQLTELS_Database" : contextA[0], "conDbPGSQLTELS_Server": contextA[1] , "conDbPGSQLTELS_Schema": contextA[2] , "conDbPGSQLTELS_Port": contextA[3] , "conDbPGSQLTELS_Login" : contextA[4], "conDbPGSQLTELS_Password" : contextA[5], "conDbPGSQLTELS_jdbcs" : "ssl=true&sslmode=require"}
      },
      (body) => helpers.successCallback(res, body),
      (error) => helpers.errorCallback(res, error)
    );
  });

  router.post("/task/pgdbTaskIdbyName", async (req, res) => {
    var reqEnv = req.query.env;
    var reqTaskId = req.query.taskId;
    if (!reqTaskId || !reqEnv)
    {
      return res.status(400).send('Task id or environment is missing');
    }
    try {

    } catch (e) {
      return res.status(500).send(e);
    }
    var isAuthenicated = await isAuthenicatedForTask(reqTaskId, reqEnv, req.headers.authorization.substring(7), permission_configuration.startStopTask);

    var tacList = await getTacListFromDb(reqEnv);
    if (tacList.length < 1)
    {
      return res.status(500).send('Environment is not correctly configured: ', reqEnv);
    }

    performMetaservletRequest(tacList[0].tacConfig, {
        "actionName": "getTaskIdByName",
        "taskName": "Test_PostGreDB_Connection"
      },
      (body) => helpers.successCallback(res, body),
      (error) => helpers.errorCallback(res, error)
    );
  });


  router.post("/task/mssqlrun", async (req, res) => {
    var reqEnv = req.query.env;
    var reqTaskId = req.query.taskId;
    var contextA = req.query.client.split(",");
    //var contextB = req.query.systemnumber;
    //console.log(contextB);
    console.log(contextA);
    if (!reqTaskId || !reqEnv)
    {
      return res.status(400).send('Task id or environment is missing');
    }
    try {

    } catch (e) {
      return res.status(500).send(e);
    }
    var isAuthenicated = await isAuthenicatedForTask(reqTaskId, reqEnv, req.headers.authorization.substring(7), permission_configuration.startStopTask);

    var tacList = await getTacListFromDb(reqEnv);
    if (tacList.length < 1)
    {
      console.error('Environment is not correctly configured: '+ reqEnv);
      return res.status(500).send('Environment is not correctly configured: '+ reqEnv);
    }
    performMetaservletRequest(tacList[0].tacConfig, {
        "actionName": "runTask",
        "mode": "synchronous",
        "taskId": reqTaskId,
        "context": {"MM4B_MSSQL_ODS_Database" : contextA[0], "MM4B_MSSQL_ODS_Server": contextA[1] , "MM4B_MSSQL_ODS_Schema": contextA[2] , "MM4B_MSSQL_ODS_Port": contextA[3] , "MM4B_MSSQL_ODS_Login" : contextA[4], "MM4B_MSSQL_ODS_Password" : contextA[5], "MM4B_MSSQL_ODS_AdditionalParams" : contextA[6]}
      },
      (body) => helpers.successCallback(res, body),
      (error) => helpers.errorCallback(res, error)
    );
  });

  router.post("/task/mssqlTaskIdbyName", async (req, res) => {
    var reqEnv = req.query.env;
    var reqTaskId = req.query.taskId;
    if (!reqTaskId || !reqEnv)
    {
      return res.status(400).send('Task id or environment is missing');
    }
    try {

    } catch (e) {
      return res.status(500).send(e);
    }
    var isAuthenicated = await isAuthenicatedForTask(reqTaskId, reqEnv, req.headers.authorization.substring(7), permission_configuration.startStopTask);

    var tacList = await getTacListFromDb(reqEnv);
    if (tacList.length < 1)
    {
      return res.status(500).send('Environment is not correctly configured: ', reqEnv);
    }

    performMetaservletRequest(tacList[0].tacConfig, {
        "actionName": "getTaskIdByName",
        "taskName": "Test_MSSQL_Connection"
      },
      (body) => helpers.successCallback(res, body),
      (error) => helpers.errorCallback(res, error)
    );
  });

  router.post("/task/oraclerun", async (req, res) => {
    var reqEnv = req.query.env;
    var reqTaskId = req.query.taskId;
    var contextA = req.query.client.split(",");
    //var contextB = req.query.systemnumber;
    //console.log(contextB);
    console.log(contextA);
    if (!reqTaskId || !reqEnv)
    {
      return res.status(400).send('Task id or environment is missing');
    }
    try {

    } catch (e) {
      return res.status(500).send(e);
    }
    var isAuthenicated = await isAuthenicatedForTask(reqTaskId, reqEnv, req.headers.authorization.substring(7), permission_configuration.startStopTask);

    var tacList = await getTacListFromDb(reqEnv);
    if (tacList.length < 1)
    {
      console.error('Environment is not correctly configured: '+ reqEnv);
      return res.status(500).send('Environment is not correctly configured: '+ reqEnv);
    }
    performMetaservletRequest(tacList[0].tacConfig, {
        "actionName": "runTask",
        "mode": "synchronous",
        "taskId": reqTaskId,
        "context": {"conDbORCLTAC_Server" : contextA[0], "conDbORCLTAC_Schema": contextA[1] , "conDbORCLTAC_Port": contextA[2] , "conDbORCLTAC_Login": contextA[3] , "conDbORCLTAC_Password" : contextA[4] }
      },
      (body) => helpers.successCallback(res, body),
      (error) => helpers.errorCallback(res, error)
    );
  });

  router.post("/task/oracleTaskIdbyName", async (req, res) => {
    var reqEnv = req.query.env;
    var reqTaskId = req.query.taskId;
    if (!reqTaskId || !reqEnv)
    {
      return res.status(400).send('Task id or environment is missing');
    }
    try {

    } catch (e) {
      return res.status(500).send(e);
    }
    var isAuthenicated = await isAuthenicatedForTask(reqTaskId, reqEnv, req.headers.authorization.substring(7), permission_configuration.startStopTask);

    var tacList = await getTacListFromDb(reqEnv);
    if (tacList.length < 1)
    {
      return res.status(500).send('Environment is not correctly configured: ', reqEnv);
    }

    performMetaservletRequest(tacList[0].tacConfig, {
        "actionName": "getTaskIdByName",
        "taskName": "Test_OracleDB_Connection"
      },
      (body) => helpers.successCallback(res, body),
      (error) => helpers.errorCallback(res, error)
    );
  });



  router.get('/tasks', async (req, res) => {
    var reqProjectCodes = req.query.projectCodes ? JSON.parse(req.query.projectCodes) : [];
    var reqTaskLbl = req.query.taskLbl;
    var reqEnv = req.query.env;
    var reqTaskId = req.query.taskId;

    try {
      var tacList = await getTacListFromDb(reqEnv);
      var url = 'https://localhost:8682/api/permission';
      if (reqProjectCodes.length > 0)
      {
        url = url + '?projectCodes=["'+reqProjectCodes+'"]';
      }
      var response = await axios.get(url, {headers:{'Authorization': 'bearer '+ req.headers.authorization.substring(7)}});
      var projectPermissions = response.data;
      var completeTaskList = [];
      for (const tacInstance of tacList)
      {
        var projectNamesEnv = [];
        projectNamesEnv = projectPermissions.filter((pFilter) => {
          return projectPermissions.find((pPermission) => {
            return pPermission.project_code === pFilter.project_code
              && pPermission.environments.find((env) => {
                                                        return tacInstance.env.startsWith(env.env)
                                                            && env.roles.some(role => permission_configuration.taskList.includes(role));
                                                        }
                                                        );
          });
        });
        if (projectNamesEnv && projectNamesEnv.length > 0)
        { 
          var taskList = await getTaskListForEnv(tacInstance, projectNamesEnv, reqTaskLbl, reqTaskId).catch(
            (err) => {console.error('error fetching tasks from ' + tacInstance.env,err)});
          if (taskList && taskList.length > 0)
          {
            completeTaskList = completeTaskList.concat(taskList);
          }
        }
      }
      res.send(aggregateTaskList(completeTaskList));
    } catch (e) {
      res.status(500).send(e);
      return;
    }
  });

  router.get('/esbs', async (req, res) => {
    var reqProjectCodes = req.query.projectCodes ? JSON.parse(req.query.projectCodes) : [];
    var reqEsbLbl = req.query.esbLbl;
    var reqEnv = req.query.env;
    var reqEsbId = req.query.esbId;

    try {
      
      var tacList = await getTacListFromDb(reqEnv);
      var url = 'https://localhost:8682/api/permission';
      if (reqProjectCodes.length > 0)
      {
        url = url + '?projectCodes=["'+reqProjectCodes+'"]';
      }
      var response = await axios.get(url, {headers:{'Authorization': 'bearer '+ req.headers.authorization.substring(7)}});
      var projectPermissions = response.data;
      var completeEsbList = [];
      for (const tacInstance of tacList)
      {
        var projectNamesEnv = [];
        projectNamesEnv = projectPermissions.filter((pFilter) => {
          return projectPermissions.find((pPermission) => {
            return pPermission.project_code === pFilter.project_code
              && pPermission.environments.find((env) => {
                                                        return tacInstance.env.startsWith(env.env)
                                                            && env.roles.some(role => permission_configuration.esbList.includes(role));
                                                        }
                                                        );
          });
        });
        if (projectNamesEnv && projectNamesEnv.length > 0)
        { 
          var esbList = await getEsbListForEnv(tacInstance, reqProjectCodes, projectNamesEnv, reqEsbLbl, reqEsbId).catch(
            (err) => {console.error('error fetching esbs from ' + tacInstance.env,err)});
          if (esbList && esbList.length > 0)
          {
            completeEsbList = completeEsbList.concat(esbList);

          }
        }
      }
      var result = aggregateEsbList(completeEsbList);
      res.send(result);
    } catch (e) {
      res.status(500).send(e);
      return;
    }
  });

  return router;

}


/**
 * executes a request for the Talend Administration Center Metaservlet
 *
 * @param {*} configuration the configuration to be used
 * @param {*} commandObject the command details
 * @param {*} successCallback callback called on execution success
 * @param {*} errorCallback callback called on faulty execution
 */
const performMetaservletRequest = (tacConfig, commandObject, successCallback, errorCallback) => {
  commandObject["authPass"] = tacConfig.password;
  commandObject["authUser"] = tacConfig.user;
  const base64data = new Buffer.from(JSON.stringify(commandObject)).toString('base64');
  var url = `${tacConfig.useHttps ? "https" : "http"}://${tacConfig.host}:${tacConfig.port}/${tacConfig.applicationContext}/metaServlet?${base64data}`;
  console.log(url)
  request.get(
    url,
    (error, response, body) => {
      body = JSON.parse(body)
      if( !error && body.returnCode === 0) {
        successCallback(body);
      } else {
        var body = {};
        if (error)
        {
          console.error('Error sending metaservlet request ' + error);
          body.error = error;
        }
        if (response.body)
        {
          body.metaServletResponse = response.body;
        }
        errorCallback(body);

      }
    }
  );
};
