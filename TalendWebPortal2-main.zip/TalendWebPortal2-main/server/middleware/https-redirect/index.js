'use strict';

/**
 * this module encapsulates the HTTPS redirect configuration
 * @param {*} options 
 */
module.exports = (options) => {
  const localOptions = options || {};
  var httpsPort = localOptions.httpsPort || 443;

  return (req, res, next) => {
    var localhost = 'localhost:' + httpsPort;
    var newHost;

    switch (process.env.NODE_ENV) {
        case 'staging':
            newHost = 'nzd8de.nodejs.talend.intranet.cnb:' + httpsPort;
        break;
        case 'evaluation':
            newHost = 'nze8de.nodejs.talend.intranet.cnb:' + httpsPort;
            break;
        case 'production':
            newHost = 'talend.intranet.cnb:' + httpsPort;
        break;
    }

    // If the protocol is http then redirect to https
    if (!req.secure)  {
      return res.redirect(301, 'https://' + req.get('Host') + req.originalUrl);
    }

    // if the hostname is not matching with localhost or newHost then redirect
    if((req.get('Host') !== newHost) && (req.get('Host') !== localhost)) {
      return res.redirect(301, 'https://' + newHost + req.originalUrl);
    }

    // Continue
    next();
  };
  
};
