module.exports = {
  "regExLdapGroups": "^(dynPrefixes)([A-Za-z]{2,4})_talend_p_([A-Za-z0-9]+)_([A-Za-z_]+)$", //Updated the regExLdapGroups to dynamic
  "adminGroups":  process.env.TALEND_ENTERPRISE_ADMIN_GROUPS || ["bs.u.talend_enterprise_admin_1stcwid"],
  "development": {
    "jwt": {
      "secret": process.env.JWT_SECRET || "#SuperSecretDevSecret#"
    },
    "talend": {
      "baseUrl": process.env.TALEND_TAC_URL || "http://tacd1.talend.intranet.cnb:8080/tac641/metaServlet",
      "user": process.env.TALEND_TAC_USERNAME || "mzvcm@bayer.com",
      "password": process.env.TALEND_TAC_PASSWORD || "talend"
    },
    "gitlab": {
      "baseUrl": process.env.GITLAB_URL || "https://by-gitlab.de.bayer.cnb",
      "user": process.env.GITLAB_USERNAME || "MZVCM",
      "token": process.env.GITLAB_TOKEN ||"Li5tknDauoJMs2pahysd",
      "talendProjectGroupPath": "/talend/config"
    },
    "jenkins": {
      "baseUrl": process.env.JENKINS_URL || "https://jenkins.talend.intranet.cnb:8483/jenkins",
      "user": process.env.JENKINS_USERNAME || "MZVCM",
      "token": process.env.JENKINS_TOKEN || "250fbe_67689"
    },
    "github": {
      "baseUrl": process.env.GITHUB_URL || "https://github.platforms.engineering",
      "user": process.env.GITHUB_USERNAME || "MZNPP",
      "token": process.env.GITHUB_TOKEN ||"ef39f2bff47cd66465d1904005b96c710d27879f",
      "talendProjectGroupPath": "/talend"
    }
  },
  "staging": {
    "jwt": {
      "secret": process.env.JWT_SECRET || "$%#SuperSecretStagingSecret!$$#"
    },
    "talend": {
      "baseUrl": process.env.TALEND_TAC_URL || "http://tacd1.talend.intranet.cnb:8080/tac641/metaServlet",
      "user": process.env.TALEND_TAC_USERNAME || "mzvcm@bayer.com",
      "password": process.env.TALEND_TAC_PASSWORD || "talend"
    },
    "gitlab": {
      "baseUrl": process.env.GITLAB_URL || "https://by-gitlab.de.bayer.cnb",
      "user": process.env.GITLAB_USERNAME || "MZVCM",
      "token": process.env.GITLAB_TOKEN ||"Li5tknDauoJMs2pahysd",
      "talendProjectGroupPath": "/talend/config"
    },
    "jenkins": {
      "baseUrl": process.env.JENKINS_URL || "https://jenkins.talend.intranet.cnb:8483/jenkins",
      "user": process.env.JENKINS_USERNAME || "MZVCM",
      "token": process.env.JENKINS_TOKEN || "250fbe_67689"
    },
    "github": {
      "baseUrl": process.env.GITHUB_URL || "https://github.platforms.engineering",
      "user": process.env.GITHUB_USERNAME || "MZNPP",
      "token": process.env.GITHUB_TOKEN ||"ef39f2bff47cd66465d1904005b96c710d27879f",
      "talendProjectGroupPath": "/talend"
    }
  },
  "development": {
    "jwt": {
      "secret": process.env.JWT_SECRET || "#SuperSecretDevSecret#"
    },
    "talend": {
      "baseUrl": process.env.TALEND_TAC_URL || "http://tacd1.talend.intranet.cnb:8080/tac641/metaServlet",
      "user": process.env.TALEND_TAC_USERNAME || "mzvcm@bayer.com",
      "password": process.env.TALEND_TAC_PASSWORD || "talend"
    },
    "gitlab": {
      "baseUrl": process.env.GITLAB_URL || "https://by-gitlab.de.bayer.cnb",
      "user": process.env.GITLAB_USERNAME || "MZVCM",
      "token": process.env.GITLAB_TOKEN ||"Li5tknDauoJMs2pahysd",
      "talendProjectGroupPath": "/talend/config"
    },
    "jenkins": {
      "baseUrl": process.env.JENKINS_URL || "https://jenkins.talend.intranet.cnb:8483/jenkins",
      "user": process.env.JENKINS_USERNAME || "MZVCM",
      "token": process.env.JENKINS_TOKEN || "250fbe_67689"
    },
    "github": {
      "baseUrl": process.env.GITHUB_URL || "https://github.platforms.engineering",
      "user": process.env.GITHUB_USERNAME || "MZNPP",
      "token": process.env.GITHUB_TOKEN ||"ef39f2bff47cd66465d1904005b96c710d27879f",
      "talendProjectGroupPath": "/talend"
    }
  },
  "evaluation": {
    "jwt": {
      "secret": process.env.JWT_SECRET || "$%#SuperSecretStagingSecret!$$#"
    },
    "talend": {
      "baseUrl": process.env.TALEND_TAC_URL || "http://tacd1.talend.intranet.cnb:8080/tac641/metaServlet",
      "user": process.env.TALEND_TAC_USERNAME || "mzvcm@bayer.com",
      "password": process.env.TALEND_TAC_PASSWORD || "talend"
    },
    "gitlab": {
      "baseUrl": process.env.GITLAB_URL || "https://by-gitlab.de.bayer.cnb",
      "user": process.env.GITLAB_USERNAME || "MZVCM",
      "token": process.env.GITLAB_TOKEN ||"Li5tknDauoJMs2pahysd",
      "talendProjectGroupPath": "/talend/config"
    },
    "jenkins": {
      "baseUrl": process.env.JENKINS_URL || "https://jenkins.talend.intranet.cnb:8483/jenkins",
      "user": process.env.JENKINS_USERNAME || "MZVCM",
      "token": process.env.JENKINS_TOKEN || "250fbe_67689"
    },
    "github": {
      "baseUrl": process.env.GITHUB_URL || "https://github.platforms.engineering",
      "user": process.env.GITHUB_USERNAME || "MZNPP",
      "token": process.env.GITHUB_TOKEN ||"ef39f2bff47cd66465d1904005b96c710d27879f",
      "talendProjectGroupPath": "/talend"
    }
  },
  "qa": {
    "jwt": {
      "secret": process.env.JWT_SECRET
    },
    "talend": {
      "baseUrl": process.env.TALEND_TAC_URL || "",
      "user": process.env.TALEND_TAC_USERNAME || "",
      "password": process.env.TALEND_TAC_PASSWORD || ""
    },
    "gitlab": {
      "baseUrl": process.env.GITLAB_URL || "https://by-gitlab.de.bayer.cnb",
      "user": process.env.GITLAB_USERNAME || "MZVCM",
      "token": process.env.GITLAB_TOKEN ||"Li5tknDauoJMs2pahysd",
      "talendProjectGroupPath": "/talend/config"
    },
    "jenkins": {
      "baseUrl": process.env.JENKINS_URL || "",
      "user": process.env.JENKINS_USERNAME || "",
      "token": process.env.JENKINS_TOKEN || ""
    },
    "github": {
      "baseUrl": process.env.GITHUB_URL || "https://github.platforms.engineering",
      "user": process.env.GITHUB_USERNAME || "MZNPP",
      "token": process.env.GITHUB_TOKEN ||"ef39f2bff47cd66465d1904005b96c710d27879f",
      "talendProjectGroupPath": "/talend"
    }
  },
  "production": {
    "jwt": {
      "secret": process.env.JWT_SECRET
    },
    "talend": {
      "baseUrl": process.env.TALEND_TAC_URL || "",
      "user": process.env.TALEND_TAC_USERNAME || "",
      "password": process.env.TALEND_TAC_PASSWORD || ""
    },
    "gitlab": {
      "baseUrl": process.env.GITLAB_URL || "https://by-gitlab.de.bayer.cnb",
      "user": process.env.GITLAB_USERNAME || "MZVCM",
      "token": process.env.GITLAB_TOKEN ||"Li5tknDauoJMs2pahysd",
      "talendProjectGroupPath": "/talend/config"
    },
    "jenkins": {
      "baseUrl": process.env.JENKINS_URL || "",
      "user": process.env.JENKINS_USERNAME || "",
      "token": process.env.JENKINS_TOKEN || ""
    },
    "github": {
      "baseUrl": process.env.GITHUB_URL || "https://github.platforms.engineering",
      "user": process.env.GITHUB_USERNAME || "MZNPP",
      "token": process.env.GITHUB_TOKEN ||"ef39f2bff47cd66465d1904005b96c710d27879f",
      "talendProjectGroupPath": "/talend"
    }
  },
}