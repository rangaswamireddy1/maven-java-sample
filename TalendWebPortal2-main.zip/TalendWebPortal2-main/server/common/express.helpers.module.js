'use strict'

/**
 * This module encapsulates simple helper functions
 */
module.exports = {

  /**
   * a standard success callback
   */
  "successCallback": (res, body) => res.status(200).json(body).end(),

  /**
   * a standard error callback
   */
  "errorCallback": (res, error) => res.status(500).json(error).end()
}
