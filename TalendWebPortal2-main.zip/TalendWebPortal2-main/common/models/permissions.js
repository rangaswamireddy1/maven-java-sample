'use strict';

module.exports = function(Permissions) {

};
