'use strict';

module.exports = function(Roles) {

};
