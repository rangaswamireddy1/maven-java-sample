'use strict';
const model_helper = require('./model_helper');


module.exports = function(Runtimes) {
  Runtimes.beforeRemote('**', function(ctx, user, next){
    ctx.args.filter = model_helper.applyProjectGroupFilterToQuery(ctx.args.filter, ctx.req.user.groups);
    next();
  });
};
