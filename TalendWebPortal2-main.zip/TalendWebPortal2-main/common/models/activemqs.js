'use strict';

module.exports = function(Activemqs) {

};
