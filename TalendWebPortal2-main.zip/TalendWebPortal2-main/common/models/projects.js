'use strict';
const axios = require('axios');

const model_helper = require('./model_helper');

module.exports = function(Projects) {
  Projects.beforeRemote('**', async function(ctx, user, next){
    // ctx.args.filter = model_helper.applyProjectGroupFilterToQuery(ctx.args.filter, ctx.req.user.groups);
    var url = 'https://localhost:8682/api/permission';
    var response = await axios.get(url, {headers:{'Authorization': 'bearer '+ ctx.req.headers.authorization.substring(7)}});
    var projectPermissions = response.data;

    ctx.args.filter = model_helper.applyProjectGroupFilterToQuery(ctx.args.filter, projectPermissions);
    return next;
  });
};
