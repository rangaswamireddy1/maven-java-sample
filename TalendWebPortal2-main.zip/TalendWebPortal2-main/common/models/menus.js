'use strict';

module.exports = function(Menus) {
  Menus.beforeRemote('**', function(ctx, user, next){
    console.error('TODO: Filter menues based on ldap-groups.');
    next();
  });
};
