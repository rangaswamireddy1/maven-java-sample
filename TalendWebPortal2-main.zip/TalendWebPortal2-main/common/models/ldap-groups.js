'use strict';

module.exports = function(Ldapgroups) {

};
