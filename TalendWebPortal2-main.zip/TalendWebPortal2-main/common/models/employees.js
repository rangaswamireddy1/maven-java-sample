'use strict';

module.exports = function(Employees) {

};
